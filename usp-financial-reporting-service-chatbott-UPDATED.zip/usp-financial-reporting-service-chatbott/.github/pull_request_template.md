# 📋 Description  
Please provide a concise summary of the changes included in this PR. Mention the purpose, scope, and any relevant context or background. Ensure all changes are production-ready and have passed necessary validations.

---

# 🛠️ Work Information 
_Include links to associated work items for traceability._

| Type         | Link                                        |
|--------------|---------------------------------------------|
| User Story   | Link text Here |
| Defect/Bug   | Link text Here |
| Task         | Link text Here |

---

# 🚨 Hotfix Information  
_If this PR addresses a critical issue, please specify below._

| Type       | Link                                        |
|------------|---------------------------------------------|
| Defect     | Link text Here |

---

# 🚀 Reason for Merge  
_Select all that apply based on the target branch._

## 🔁 If merging to `test_release_hse`:
- [ ] New feature  
- [ ] Parent POM Upgrade  
- [ ] CI/CD Changes (Docker, Jenkins)  
- [ ] Hotfix (critical production issue fix)  
- [ ] Security Vulnerability Fixes  
- [ ] Breaking change (requires careful deployment coordination)  

## 📦 If merging to `release_hse`:
- [ ] Hotfix (critical production issue fix)  
- [ ] Scheduled merging from `dev_integration` (production-ready functionality)  
- [ ] Breaking change (requires careful deployment coordination)  
- [ ] Exceptional Change – Approval obtained from: `______________`

---

# ✅ JUnit Test Checks  
_Select all that apply:_  
- [ ] This is only config / Parent POM / security fix and does not require additional tests  
- [ ] I have added tests to cover my changes  
- [ ] Code coverage on PR has been increased by 3–5%  
- [ ] Code coverage is already exceeding 85%  
- [ ] All new and existing tests passed  

---

# 🧪 DB Script Checks  
_Select one:_  
- [ ] DB Scripts are not required for these changes  
- [ ] DB Scripts are required and have been executed in `CPTTSTAGE` / `TEST`

---

# 🔍 Sonar Scan Results  
_Include screenshots of Sonar scan results for both source and target branches._

| Branch Name      | Screenshot          |
|------------------|---------------------|
| `<target_branch>`| !Screenshot    |
| `<source_branch>`| !Screenshot    |
