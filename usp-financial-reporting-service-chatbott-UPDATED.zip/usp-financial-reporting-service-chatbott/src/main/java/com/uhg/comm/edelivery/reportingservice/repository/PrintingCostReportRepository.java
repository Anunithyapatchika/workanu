package com.uhg.comm.edelivery.reportingservice.repository;

import com.uhg.comm.edelivery.reportingservice.model.PrintingCostReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface PrintingCostReportRepository extends JpaRepository<PrintingCostReport, Integer> {
    Optional<PrintingCostReport> findByTrailNameAndBobAndMonth(String trailName, String bob, String month);

    @Query("SELECT u FROM PrintingCostReport u WHERE u.trailName = :trailName AND u.monthYear BETWEEN :startDate AND :endDate ORDER BY u.monthYear ASC")
    List<PrintingCostReport> findByTrailNameAndDateBetween(String trailName, LocalDate startDate, LocalDate endDate);
}
