package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "totChargeAmt", "totSavedAmt", "paymentAppliedAmt", "totAllowedAmt", "totCopayAmt", "totCoInsAmt",
		"totDeductibleAmt", "totPlanPayAmt", "totOtherInsMedicareAmt", "totOtherInsPaidAmt", "totMedicarePaidAmt",
		"totYourAmtOwed", "totNotCoveredAmt", "totYouPaidOutOfPocket", "totCost", "totConsumerAccountPaid",
		"totConsumerAccountConsidered", "totConsumerAccountPended" })
@Generated("jsonschema2pojo")
public class ClaimTotAmt {

	@JsonProperty("totChargeAmt")
	private String totChargeAmt;
	@JsonProperty("totSavedAmt")
	private String totSavedAmt;
	@JsonProperty("paymentAppliedAmt")
	private String paymentAppliedAmt;
	@JsonProperty("totAllowedAmt")
	private String totAllowedAmt;
	@JsonProperty("totCopayAmt")
	private String totCopayAmt;
	@JsonProperty("totCoInsAmt")
	private String totCoInsAmt;
	@JsonProperty("totDeductibleAmt")
	private String totDeductibleAmt;
	@JsonProperty("totPlanPayAmt")
	private String totPlanPayAmt;
	@JsonProperty("totOtherInsMedicareAmt")
	private String totOtherInsMedicareAmt;
	@JsonProperty("totOtherInsPaidAmt")
	private String totOtherInsPaidAmt;
	@JsonProperty("totMedicarePaidAmt")
	private String totMedicarePaidAmt;
	@JsonProperty("totYourAmtOwed")
	private String totYourAmtOwed;
	@JsonProperty("totNotCoveredAmt")
	private String totNotCoveredAmt;
	@JsonProperty("totYouPaidOutOfPocket")
	private String totYouPaidOutOfPocket;
	@JsonProperty("totCost")
	private String totCost;
	@JsonProperty("totConsumerAccountPaid")
	private String totConsumerAccountPaid;
	@JsonProperty("totConsumerAccountConsidered")
	private String totConsumerAccountConsidered;
	@JsonProperty("totConsumerAccountPended")
	private String totConsumerAccountPended;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("totChargeAmt")
	public String getTotChargeAmt() {
		return totChargeAmt;
	}

	@JsonProperty("totChargeAmt")
	public void setTotChargeAmt(String totChargeAmt) {
		this.totChargeAmt = totChargeAmt;
	}

	@JsonProperty("totSavedAmt")
	public String getTotSavedAmt() {
		return totSavedAmt;
	}

	@JsonProperty("totSavedAmt")
	public void setTotSavedAmt(String totSavedAmt) {
		this.totSavedAmt = totSavedAmt;
	}

	@JsonProperty("paymentAppliedAmt")
	public String getPaymentAppliedAmt() {
		return paymentAppliedAmt;
	}

	@JsonProperty("paymentAppliedAmt")
	public void setPaymentAppliedAmt(String paymentAppliedAmt) {
		this.paymentAppliedAmt = paymentAppliedAmt;
	}

	@JsonProperty("totAllowedAmt")
	public String getTotAllowedAmt() {
		return totAllowedAmt;
	}

	@JsonProperty("totAllowedAmt")
	public void setTotAllowedAmt(String totAllowedAmt) {
		this.totAllowedAmt = totAllowedAmt;
	}

	@JsonProperty("totCopayAmt")
	public String getTotCopayAmt() {
		return totCopayAmt;
	}

	@JsonProperty("totCopayAmt")
	public void setTotCopayAmt(String totCopayAmt) {
		this.totCopayAmt = totCopayAmt;
	}

	@JsonProperty("totCoInsAmt")
	public String getTotCoInsAmt() {
		return totCoInsAmt;
	}

	@JsonProperty("totCoInsAmt")
	public void setTotCoInsAmt(String totCoInsAmt) {
		this.totCoInsAmt = totCoInsAmt;
	}

	@JsonProperty("totDeductibleAmt")
	public String getTotDeductibleAmt() {
		return totDeductibleAmt;
	}

	@JsonProperty("totDeductibleAmt")
	public void setTotDeductibleAmt(String totDeductibleAmt) {
		this.totDeductibleAmt = totDeductibleAmt;
	}

	@JsonProperty("totPlanPayAmt")
	public String getTotPlanPayAmt() {
		return totPlanPayAmt;
	}

	@JsonProperty("totPlanPayAmt")
	public void setTotPlanPayAmt(String totPlanPayAmt) {
		this.totPlanPayAmt = totPlanPayAmt;
	}

	@JsonProperty("totOtherInsMedicareAmt")
	public String getTotOtherInsMedicareAmt() {
		return totOtherInsMedicareAmt;
	}

	@JsonProperty("totOtherInsMedicareAmt")
	public void setTotOtherInsMedicareAmt(String totOtherInsMedicareAmt) {
		this.totOtherInsMedicareAmt = totOtherInsMedicareAmt;
	}

	@JsonProperty("totOtherInsPaidAmt")
	public String getTotOtherInsPaidAmt() {
		return totOtherInsPaidAmt;
	}

	@JsonProperty("totOtherInsPaidAmt")
	public void setTotOtherInsPaidAmt(String totOtherInsPaidAmt) {
		this.totOtherInsPaidAmt = totOtherInsPaidAmt;
	}

	@JsonProperty("totMedicarePaidAmt")
	public String getTotMedicarePaidAmt() {
		return totMedicarePaidAmt;
	}

	@JsonProperty("totMedicarePaidAmt")
	public void setTotMedicarePaidAmt(String totMedicarePaidAmt) {
		this.totMedicarePaidAmt = totMedicarePaidAmt;
	}

	@JsonProperty("totYourAmtOwed")
	public String getTotYourAmtOwed() {
		return totYourAmtOwed;
	}

	@JsonProperty("totYourAmtOwed")
	public void setTotYourAmtOwed(String totYourAmtOwed) {
		this.totYourAmtOwed = totYourAmtOwed;
	}

	@JsonProperty("totNotCoveredAmt")
	public String getTotNotCoveredAmt() {
		return totNotCoveredAmt;
	}

	@JsonProperty("totNotCoveredAmt")
	public void setTotNotCoveredAmt(String totNotCoveredAmt) {
		this.totNotCoveredAmt = totNotCoveredAmt;
	}

	@JsonProperty("totYouPaidOutOfPocket")
	public String getTotYouPaidOutOfPocket() {
		return totYouPaidOutOfPocket;
	}

	@JsonProperty("totYouPaidOutOfPocket")
	public void setTotYouPaidOutOfPocket(String totYouPaidOutOfPocket) {
		this.totYouPaidOutOfPocket = totYouPaidOutOfPocket;
	}

	@JsonProperty("totCost")
	public String getTotCost() {
		return totCost;
	}

	@JsonProperty("totCost")
	public void setTotCost(String totCost) {
		this.totCost = totCost;
	}

	@JsonProperty("totConsumerAccountPaid")
	public String getTotConsumerAccountPaid() {
		return totConsumerAccountPaid;
	}

	@JsonProperty("totConsumerAccountPaid")
	public void setTotConsumerAccountPaid(String totConsumerAccountPaid) {
		this.totConsumerAccountPaid = totConsumerAccountPaid;
	}

	@JsonProperty("totConsumerAccountConsidered")
	public String getTotConsumerAccountConsidered() {
		return totConsumerAccountConsidered;
	}

	@JsonProperty("totConsumerAccountConsidered")
	public void setTotConsumerAccountConsidered(String totConsumerAccountConsidered) {
		this.totConsumerAccountConsidered = totConsumerAccountConsidered;
	}

	@JsonProperty("totConsumerAccountPended")
	public String getTotConsumerAccountPended() {
		return totConsumerAccountPended;
	}

	@JsonProperty("totConsumerAccountPended")
	public void setTotConsumerAccountPended(String totConsumerAccountPended) {
		this.totConsumerAccountPended = totConsumerAccountPended;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(ClaimTotAmt.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this)))
				.append('[');
		sb.append("totChargeAmt");
		sb.append('=');
		sb.append(((this.totChargeAmt == null) ? "<null>" : this.totChargeAmt));
		sb.append(',');
		sb.append("totSavedAmt");
		sb.append('=');
		sb.append(((this.totSavedAmt == null) ? "<null>" : this.totSavedAmt));
		sb.append(',');
		sb.append("paymentAppliedAmt");
		sb.append('=');
		sb.append(((this.paymentAppliedAmt == null) ? "<null>" : this.paymentAppliedAmt));
		sb.append(',');
		sb.append("totAllowedAmt");
		sb.append('=');
		sb.append(((this.totAllowedAmt == null) ? "<null>" : this.totAllowedAmt));
		sb.append(',');
		sb.append("totCopayAmt");
		sb.append('=');
		sb.append(((this.totCopayAmt == null) ? "<null>" : this.totCopayAmt));
		sb.append(',');
		sb.append("totCoInsAmt");
		sb.append('=');
		sb.append(((this.totCoInsAmt == null) ? "<null>" : this.totCoInsAmt));
		sb.append(',');
		sb.append("totDeductibleAmt");
		sb.append('=');
		sb.append(((this.totDeductibleAmt == null) ? "<null>" : this.totDeductibleAmt));
		sb.append(',');
		sb.append("totPlanPayAmt");
		sb.append('=');
		sb.append(((this.totPlanPayAmt == null) ? "<null>" : this.totPlanPayAmt));
		sb.append(',');
		sb.append("totOtherInsMedicareAmt");
		sb.append('=');
		sb.append(((this.totOtherInsMedicareAmt == null) ? "<null>" : this.totOtherInsMedicareAmt));
		sb.append(',');
		sb.append("totOtherInsPaidAmt");
		sb.append('=');
		sb.append(((this.totOtherInsPaidAmt == null) ? "<null>" : this.totOtherInsPaidAmt));
		sb.append(',');
		sb.append("totMedicarePaidAmt");
		sb.append('=');
		sb.append(((this.totMedicarePaidAmt == null) ? "<null>" : this.totMedicarePaidAmt));
		sb.append(',');
		sb.append("totYourAmtOwed");
		sb.append('=');
		sb.append(((this.totYourAmtOwed == null) ? "<null>" : this.totYourAmtOwed));
		sb.append(',');
		sb.append("totNotCoveredAmt");
		sb.append('=');
		sb.append(((this.totNotCoveredAmt == null) ? "<null>" : this.totNotCoveredAmt));
		sb.append(',');
		sb.append("totYouPaidOutOfPocket");
		sb.append('=');
		sb.append(((this.totYouPaidOutOfPocket == null) ? "<null>" : this.totYouPaidOutOfPocket));
		sb.append(',');
		sb.append("totCost");
		sb.append('=');
		sb.append(((this.totCost == null) ? "<null>" : this.totCost));
		sb.append(',');
		sb.append("totConsumerAccountPaid");
		sb.append('=');
		sb.append(((this.totConsumerAccountPaid == null) ? "<null>" : this.totConsumerAccountPaid));
		sb.append(',');
		sb.append("totConsumerAccountConsidered");
		sb.append('=');
		sb.append(((this.totConsumerAccountConsidered == null) ? "<null>" : this.totConsumerAccountConsidered));
		sb.append(',');
		sb.append("totConsumerAccountPended");
		sb.append('=');
		sb.append(((this.totConsumerAccountPended == null) ? "<null>" : this.totConsumerAccountPended));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
