package com.uhg.comm.edelivery.reportingservice.dto;

import lombok.Data;

@Data
public class HSReportItemsDto {

    private String bob;
    private double totalHsGenerated;
    private double totalHsSuppressed;
    private double totalHsSuppressedSubscriberElection;
    private double totalHsSuppressedPolicySetting;
    private double totalHsPrinted;
    private double hsSuppressedPercent;
}
