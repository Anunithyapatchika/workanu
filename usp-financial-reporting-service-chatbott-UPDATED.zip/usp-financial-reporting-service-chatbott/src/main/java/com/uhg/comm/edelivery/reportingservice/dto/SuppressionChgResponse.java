package com.uhg.comm.edelivery.reportingservice.dto;

import lombok.Data;

import java.util.List;

@Data
public class SuppressionChgResponse {
    private String date;
    private String trailNumber;
    private List<SuppressionChgResponseItem> items;
}
