package com.uhg.comm.edelivery.reportingservice.bean;

import com.fasterxml.jackson.annotation.*;
import lombok.Data;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "RecordId", "Status", "TnoRecordId", "jobId" })
@Generated("jsonschema2pojo")
@Data
public class OnDemandAPIResponse {

	@JsonProperty("RecordId")
	private String recordId;

	@JsonProperty("Status")
	private String status;

	@JsonProperty("TnoRecordId")
	private String tnoRecordId;

	@JsonProperty("jobId")
	private String jobId;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("RecordId")
	public String getRecordId() {
		return recordId;
	}

	@JsonProperty("RecordId")
	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}

	@JsonProperty("Status")
	public String getStatus() {
		return status;
	}

	@JsonProperty("Status")
	public void setStatus(String status) {
		this.status = status;
	}

	@JsonProperty("TnoRecordId")
	public String getTnoRecordId() {
		return tnoRecordId;
	}

	@JsonProperty("TnoRecordId")
	public void setTnoRecordId(String tnoRecordId) {
		this.tnoRecordId = tnoRecordId;
	}

	@JsonProperty("jobId")
	public String getJobId() {
		return jobId;
	}

	@JsonProperty("jobId")
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}
