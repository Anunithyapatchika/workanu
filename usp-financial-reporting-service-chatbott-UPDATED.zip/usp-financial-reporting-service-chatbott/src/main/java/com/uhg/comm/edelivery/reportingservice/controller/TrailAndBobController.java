package com.uhg.comm.edelivery.reportingservice.controller;

import com.uhg.comm.edelivery.reportingservice.model.TrailAndBobDetails;
import com.uhg.comm.edelivery.reportingservice.service.TrailAndBobDetailsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.Set;

@RestController
@RequestMapping("trail-bob-details")
@CrossOrigin
@Slf4j
public class TrailAndBobController {

    @Autowired
    private TrailAndBobDetailsService trailAndBobDetailsService;

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Set<TrailAndBobDetails>> getTrailAndBodDetails() {
        log.info("Getting Trail Number and Bob details {}", new Date());
        Set<TrailAndBobDetails> trailAndBobDetailsList = trailAndBobDetailsService.getActiveTrailAndBobDetails();
        return ResponseEntity.ok(trailAndBobDetailsList);
    }
}