package com.uhg.comm.edelivery.reportingservice.bean;

import lombok.Data;


import java.util.List;
@Data
public class BatchFile {
	private String uniqueId;
	private String trailNumber;
	private String trailName;
	private String inputFileName;
	private int totalNoRecord;
	private String retry;
	private String startprocesstime;
	private String jobType;
	private String trailType;
	private int claimsCount;
	private List<Integer> recordIds;
}

