package com.uhg.comm.edelivery.reportingservice.dto;

import lombok.Data;

@Data
public class PrintCostResponseItems {

    private String bob;
    private double postageCost;
    private double paperLabourCost;
    private double costPerEnvelop;
    private double envelopeCount;
}
