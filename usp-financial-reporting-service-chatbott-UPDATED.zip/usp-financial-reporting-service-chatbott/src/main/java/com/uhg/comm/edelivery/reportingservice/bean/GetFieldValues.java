package com.uhg.comm.edelivery.reportingservice.bean;

import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class GetFieldValues {
    private String bob;
private int isCompleted;
private int isTxCompleted;
}
