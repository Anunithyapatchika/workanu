package com.uhg.comm.edelivery.reportingservice.repository;

import com.uhg.comm.edelivery.reportingservice.model.USPFinancialReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface USPFinancialReportRepository extends JpaRepository<USPFinancialReport, Long> {

    @Query("SELECT u FROM USPFinancialReport u WHERE u.trailName = :trailNumber AND u.monthYear BETWEEN :startDate AND :endDate ORDER BY u.monthYear ASC")
    List<USPFinancialReport> findByTrailNumberAndBetweenMonthYearStr(
            @Param("trailNumber") String trailNumber,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate
    );


    List<USPFinancialReport> findByTrailNameAndIsTxCompletedAndMonthYearStr(String pt3231Eob, int trxCompleted, String monthYearStr);


    Optional <USPFinancialReport>  findByMonthYearStrAndBobAndTrailName(String monthYearStr, String bob, String pt3231Eob);

//    @Query("SELECT u.trailName,u.bob,u.monthYearStr,u.isCompleted , u.isTxCompleted" +
//            " FROM USPFinancialReport u WHERE u.trailName = :trailName AND u.bob = :bob AND" +
//            " u.monthYear BETWEEN :startDate AND :endDate ORDER BY u.monthYear ASC")
//        List<Object[]> findByTrailNameAndBobAndBetweenMonthYearStr(
//            @Param("trailName") String trailName,
//            @Param("startDate") LocalDate startDate,
//            @Param("endDate") LocalDate endDate
//    );

    @Query(value = "SELECT u.bob, u.month_year_str, u.is_completed, u.is_tx_completed " +
            "FROM edelivery.usp_eob_hs_financial_report u WHERE u.trail_name = :trailName AND (u.is_completed = 0 OR u.is_tx_completed = 0) " +
            "AND u.month_year BETWEEN :startDate AND :endDate ORDER BY u.month_year ASC", nativeQuery = true)
    List<Object[]> getDetailsFromDB(@Param("trailName") String trailName, @Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
}