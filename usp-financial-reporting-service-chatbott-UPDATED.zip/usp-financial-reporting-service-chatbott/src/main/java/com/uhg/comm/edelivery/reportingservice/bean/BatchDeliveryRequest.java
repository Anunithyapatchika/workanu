package com.uhg.comm.edelivery.reportingservice.bean;


import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BatchDeliveryRequest {
	private String uniqueId;
	private String trailNumber;
	private String trailType;
	private String inputFileName;
	private String totalNoRecord;
	private String inboundStatus;
}
