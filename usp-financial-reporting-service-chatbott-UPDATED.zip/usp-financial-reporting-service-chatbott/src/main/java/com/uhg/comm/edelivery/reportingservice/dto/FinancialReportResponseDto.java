package com.uhg.comm.edelivery.reportingservice.dto;

import lombok.Data;
import java.util.List;

@Data
public class FinancialReportResponseDto {
    private List<EobReportDto> eobPrintSuppressCountReport;
    private List<HSReportDto> hsPrintSuppressCountReport;
    private List<CaeReportDto> caePrintSuppressCountReport;
    private List<PrintCostResponse> printCostReport;
    private List<SuppressionChgResponse> suppressionChangesReport;
}