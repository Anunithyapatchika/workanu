package com.uhg.comm.edelivery.reportingservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class GlobalExceptionHandler extends Throwable {

    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> handleException(Exception ex, WebRequest request) {
        ErrorDetails errorDetails = new ErrorDetails(-1, ex.getMessage(), request.getContextPath());
        return new ResponseEntity<>(errorDetails.jsonString(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
