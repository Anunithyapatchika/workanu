package com.uhg.comm.edelivery.reportingservice.service;

import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;

public interface MgmtUIService {
    ResponseEntity<Resource> downloadPdf(String fileName, String inputFileName);

    ResponseEntity<Resource> downloadzips(String fileName, String inputFilePath);
}
