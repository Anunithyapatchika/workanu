package com.uhg.comm.edelivery.reportingservice.config;
import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SecretClientConfiguration {

    @Value("${KEY_VAULT_URL}")
    private String keyVaultConnectionString;

    @Value("${USER_ASSIGNED_MANAGED_IDENTITY_CLIENT_ID}")
    private String managedIdentityClientId;

    @Bean
    public SecretClient createSecretClient() {
        return new SecretClientBuilder()
                .vaultUrl(keyVaultConnectionString)
                .credential(new DefaultAzureCredentialBuilder().managedIdentityClientId(managedIdentityClientId).build())
                .buildClient();
    }


}