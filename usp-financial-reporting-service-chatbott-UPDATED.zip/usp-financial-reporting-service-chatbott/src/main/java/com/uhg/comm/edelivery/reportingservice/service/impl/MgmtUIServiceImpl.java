package com.uhg.comm.edelivery.reportingservice.service.impl;

import com.azure.storage.blob.BlobClient;
import com.uhg.comm.edelivery.reportingservice.service.MgmtUIService;
import com.uhg.comm.edelivery.reportingservice.util.BlobUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import static com.uhg.comm.edelivery.reportingservice.constants.Constants.UCSFile;

@Service
public class MgmtUIServiceImpl implements MgmtUIService {

    private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(MgmtUIServiceImpl.class);

    @Value("${filePath.ucsFilePath}")
    String ucsPath;

    @Autowired
    private BlobUtils blobUtils;

    @Override
    public ResponseEntity<Resource> downloadPdf(String fileName, String inputFilePath) {
        try {
            BlobClient blobClient = null;
            // Create a BlobClient
            if (inputFilePath.contains(ucsPath)) {
                if (inputFilePath.matches("^[a-zA-Z0-9._/-]+$") && fileName.matches("^[a-zA-Z0-9._-]+$")) {
                    LOGGER.info("Downloading file from  path: {}, -- {} ::",
                            fileName, inputFilePath);
                }
                blobClient = blobUtils.getPdfBlobClient(inputFilePath + fileName, UCSFile);
            } else {
                if (inputFilePath.matches("^[a-zA-Z0-9._/-]+$") && fileName.matches("^[a-zA-Z0-9._-]+$")) {
                    LOGGER.info("Downloading file from  path: {}, -- {} ::",
                            fileName, inputFilePath);
                }
                blobClient = blobUtils.getPdfBlobClient(inputFilePath + fileName, "");
            }
            // Download the file content
            byte[] fileContent = blobClient.downloadContent().toBytes();
            Resource resource = new ByteArrayResource(fileContent);

            return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                    .body(resource);

        } catch (Exception e) {
            LOGGER.error("Error downloading file: {} ", e.getMessage());
        }
        return null;
    }

    @Override
    public ResponseEntity<Resource> downloadzips(String fileName, String inputFilePath) {
        try {
            BlobClient blobClient = null;
            if (inputFilePath.matches("^[a-zA-Z0-9._/-]+$") && fileName.matches("^[a-zA-Z0-9._-]+$")) {
                LOGGER.info("Downloading zip file from  path: {}, -- {} ::",
                        fileName, inputFilePath);
            }
            blobClient = blobUtils.getBlobClient(inputFilePath + fileName);
            byte[] fileContent = blobClient.downloadContent().toBytes();
            Resource resource = new ByteArrayResource(fileContent);

            return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                    .body(resource);

        } catch (Exception e) {
            LOGGER.error("Error downloading file: {} ", e.getMessage());
        }
        return null;
    }
}
