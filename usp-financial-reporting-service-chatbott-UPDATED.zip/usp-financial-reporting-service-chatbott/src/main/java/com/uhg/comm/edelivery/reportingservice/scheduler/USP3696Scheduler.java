package com.uhg.comm.edelivery.reportingservice.scheduler;


import com.uhg.comm.edelivery.reportingservice.service.USP3696DataService;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class USP3696Scheduler {

    private static final Logger LOGGER = LoggerFactory.getLogger(USP3696Scheduler.class);

    @Autowired
    private USP3696DataService usp3696DataService;

    @Scheduled(cron = "${scheduler.poll.fetchUSP3696Data}")
    @SchedulerLock(name = "FetchUSP3696Data", lockAtMostFor = "6m", lockAtLeastFor = "230s")
    public void updateTotalRecordCount() {
        LOGGER.info("USP3696 Scheduler started..!!");
        usp3696DataService.process();
        LOGGER.info("USP3696 Scheduler completed..!!");
    }
}
