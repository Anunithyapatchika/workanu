package com.uhg.comm.edelivery.reportingservice.bean;

import lombok.Data;

@Data
public class QuadientData {
	
	private String uniqueId;
	private String status;
	private int recordsCountE;
	private int recordsCountP;
	private int recordsTotalCount;
	private int ClaimsCount;

}
