package com.uhg.comm.edelivery.reportingservice.auth;

import com.azure.security.keyvault.secrets.SecretClient;
import com.uhg.comm.edelivery.reportingservice.bean.ApiResponse;
import com.uhg.comm.edelivery.reportingservice.model.OAuthResponseObj;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.util.Optional;

import static com.uhg.comm.edelivery.reportingservice.constants.AzureVaultKey.EDEL_API_CLIENTID;
import static com.uhg.comm.edelivery.reportingservice.constants.AzureVaultKey.EDEL_API_CLIENTSECRET;


@Component
public class OauthTokenUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(OauthTokenUtil.class);

    @Value("${oAuth.uri}")
    private String authUrl;

    private final SecretClient secretClient;

    @Autowired
    public WebClient webClient;

    private static final String ID = "1";

    public OauthTokenUtil(SecretClient secretClient) {
        this.secretClient = secretClient;
    }

    public String callSecurityToken() {
        String oauthToken = "";
        String endPointURL = authUrl;
        LOGGER.info("Oauth endpoint is:: {}", endPointURL);
        int retryCount = 3;
        int attempt = 0;
            try {
                MultiValueMap<String, String> secTokenMap = getSecTknFormParams();
                ResponseEntity<OAuthResponseObj> response = webClient.post()
                        .uri(endPointURL)
                        .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE)
                        .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
                        .bodyValue(secTokenMap)
                        .retrieve()
                        .toEntity(OAuthResponseObj.class)
                        .retryWhen(Retry.fixedDelay(3, Duration.ofSeconds(2)))
                        .timeout(Duration.ofSeconds(30))
                        .block();

                OAuthResponseObj oauthResp = Optional.ofNullable(response.getBody()).orElseThrow();
                LOGGER.info("token api response code {}", response.getStatusCode());
                oauthToken = Optional.ofNullable(oauthResp.getAccess_token()).orElseThrow();
            } catch (Exception e) {
                LOGGER.error("Error while calling oauth token api:{}", e.getMessage());
            }
        return oauthToken;
    }

    private MultiValueMap<String, String> getSecTknFormParams() {
        String client_credentials = "client_credentials";
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("grant_type", client_credentials);
        map.add("client_id", secretClient.getSecret(EDEL_API_CLIENTID).getValue());
        map.add("client_secret", secretClient.getSecret(EDEL_API_CLIENTSECRET).getValue());
        return map;
    }


}