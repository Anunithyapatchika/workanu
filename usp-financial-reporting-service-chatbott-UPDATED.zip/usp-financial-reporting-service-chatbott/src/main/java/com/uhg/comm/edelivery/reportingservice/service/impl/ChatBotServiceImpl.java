package com.uhg.comm.edelivery.reportingservice.service.impl;

import com.azure.storage.blob.BlobClient;
import com.uhg.comm.edelivery.reportingservice.service.ChatBotService;
import com.uhg.comm.edelivery.reportingservice.util.BlobUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class ChatBotServiceImpl implements ChatBotService {

    @Value("${filePath.chatBotJsonPath}")
    private String chatBotJsonPath;


    @Autowired
    private BlobUtils blobUtils;

    @Override
    public String readInputJsonFile() {
        try {
            log.info("Reading JSON from Azure Blob Storage");
            BlobClient blobClient = blobUtils.getBlobClient(chatBotJsonPath);
            try (java.io.InputStream inputStream = blobClient.openInputStream()) {
                log.info("Successfully read JSON from Azure Blob Storage");
                return new String(inputStream.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            log.error("Exception occurred while reading JSON from Azure Blob Storage: {}", e.getMessage(), e);
            return "";
        }
    }

}
