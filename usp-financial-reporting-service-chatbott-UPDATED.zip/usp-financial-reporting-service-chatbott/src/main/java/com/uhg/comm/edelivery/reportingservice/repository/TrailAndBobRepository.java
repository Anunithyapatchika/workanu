package com.uhg.comm.edelivery.reportingservice.repository;

import com.uhg.comm.edelivery.reportingservice.model.TrailAndBobDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Set;

@Repository
public interface TrailAndBobRepository extends JpaRepository<TrailAndBobDetails, Long> {
    Set<TrailAndBobDetails> findByIsActive(int active);

    Set<TrailAndBobDetails> findByTrailNumber(String trailNumber);
}
