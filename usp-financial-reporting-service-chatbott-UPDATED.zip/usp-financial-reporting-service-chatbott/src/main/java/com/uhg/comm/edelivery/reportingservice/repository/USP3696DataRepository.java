package com.uhg.comm.edelivery.reportingservice.repository;

import com.uhg.comm.edelivery.processLog.Processlog;
import com.uhg.comm.edelivery.reportingservice.model.USP3696Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

@Repository
public class USP3696DataRepository {

    @Autowired
    JdbcTemplate jdbcTemplate;

    public List<USP3696Data> getUSP3696Data(String dateFilter, Processlog processlog) {
        try {
            String dateFilter1 = LocalDate.now().minusDays(2).toString();
            String query = "with bt as( \n" +
                    "select min(rs.id)as id, count(*)as count, aij.created_timestamp::date as created_date,air.print_trail, \n" +
                    "aij.input_file_name as filename,sum(air.claim_cnt)as claim_count,rs.supress_indicator,rs.member_choice, \n" +
                    "jsonb(rs.metadata)->'eventData'->'recordsData'->'recordsDataList'->0->'dbMetadata'->'map'->'bookOfBusiness'->> 0 as book_of_business \n" +
                    "from edelivery.api_intake_record air \n" +
                    "join edelivery.record_state rs on air.id = rs.id \n" +
                    "join edelivery.api_intake_job aij on air.job_id = aij.job_id \n" +
                    "left join edelivery.archival_job aj on air.job_id = aj.job_id \n" +
                    "where aij.created_timestamp::date = ? \n" +
                    "and \n" +
                    "((aj.p_event_status = 2 and aj.e_event_status =2) OR EXTRACT(DOW FROM air.created_timestamp::date) = 5 ) \n" +
                    "and \n" +
                    "aij.batch_completion_record_count > 2 \n" +
                    "group by aij.created_timestamp::date,air.print_trail,rs.supress_indicator,rs.member_choice, aij.input_file_name, \n" +
                    "jsonb(rs.metadata)->'eventData'->'recordsData'->'recordsDataList'->0->'dbMetadata'->'map'->'bookOfBusiness'->> 0 \n" +
                    ") \n" +
                    "select \n" +
                    "min(b.id) as id ,\n" +
                    "b.created_date, \n" +
                    "b.filename, \n" +
                    "b.book_of_business, \n" +
                    "(select sum(count) from bt where bt.filename = b.filename and bt.book_of_business = b.book_of_business and bt.created_date=b.created_date) as total, \n" +
                    "(select sum(claim_count) from bt where bt.filename = b.filename and bt.book_of_business = b.book_of_business and bt.created_date=b.created_date) as claim_count, \n" +
                    "(select sum(count) from bt where bt.filename = b.filename and bt.book_of_business = b.book_of_business and bt.created_date=b.created_date and bt.supress_indicator = 'P') as print_count, \n" +
                    "(select sum(count) from bt where bt.filename = b.filename and bt.book_of_business = b.book_of_business and bt.created_date=b.created_date and bt.supress_indicator = 'E' and bt.member_choice = 'M') as mem_supp, \n" +
                    "(select sum(count) from bt where bt.filename = b.filename and bt.book_of_business = b.book_of_business and bt.created_date=b.created_date and bt.supress_indicator = 'E' and bt.member_choice = 'P') as policy_supp, \n" +
                    "(select sum(count) from bt where bt.filename = b.filename and bt.book_of_business = b.book_of_business and bt.created_date=b.created_date and bt.supress_indicator = 'E') as suppress, \n" +
                    "(select sum(count) from bt where bt.filename = b.filename and bt.book_of_business = b.book_of_business and bt.created_date=b.created_date and bt.supress_indicator = 'P' and bt.member_choice = 'M') as mem_print \n" +
                    "from bt as b \n" +
                    "group by b.book_of_business , b.created_date , b.filename \n" +
                    "order by 1 desc ";
            return jdbcTemplate.query(query, new Object[]{dateFilter1}, new USP3696DataRowMapper());
        } catch (Exception e) {
            processlog.setErrorMessage("Error while fetching USP3696 data");
            throw e;
        }
    }

    public static class USP3696DataRowMapper implements RowMapper<USP3696Data> {
        @Override
        public USP3696Data mapRow(ResultSet rs, int rowNum) throws SQLException {
            USP3696Data usp3696Data = new USP3696Data();
            usp3696Data.setId(rs.getInt("id"));
            usp3696Data.setCreatedDate(rs.getDate("created_date"));
            usp3696Data.setClaimCount(rs.getInt("claim_count"));
            usp3696Data.setMemSupp(rs.getInt("mem_supp"));
            usp3696Data.setPolicySupp(rs.getInt("policy_supp"));
            usp3696Data.setPrintCount(rs.getInt("print_count"));
            usp3696Data.setSuppress(rs.getInt("suppress"));
            usp3696Data.setTotal(rs.getInt("total"));
            usp3696Data.setBookOfBusiness(rs.getString("book_of_business"));
            usp3696Data.setFilename(rs.getString("filename"));
            usp3696Data.setMemPrint(rs.getObject("mem_print")==null?0:rs.getInt("mem_print"));
            return usp3696Data;
        }
    }

}
