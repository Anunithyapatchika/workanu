package com.uhg.comm.edelivery.reportingservice.config;

import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

@Configuration
public class WebClientConfig {

	@Value("${webclient.timeout.connect}")
	private int connectTimeout;

	@Value("${webclient.timeout.response}")
	private int responseTimeout;

	@Value("${webclient.timeout.read}")
	private int readTimeout;

	@Value("${webclient.timeout.write}")
	private int writeTimeout;

	@Bean
	public WebClient getWebClient() {

		HttpClient httpClient = HttpClient.create().option(ChannelOption.CONNECT_TIMEOUT_MILLIS, connectTimeout)
				.responseTimeout(Duration.ofMillis(responseTimeout))
				.doOnConnected(conn -> conn.addHandlerLast(new ReadTimeoutHandler(readTimeout, TimeUnit.MILLISECONDS))
						.addHandlerLast(new WriteTimeoutHandler(writeTimeout, TimeUnit.MILLISECONDS)));

		return WebClient.builder().clientConnector(new ReactorClientHttpConnector(httpClient)).build();
	}

}
