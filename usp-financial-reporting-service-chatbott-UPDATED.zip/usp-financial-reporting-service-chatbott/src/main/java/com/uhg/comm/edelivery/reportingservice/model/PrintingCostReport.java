package com.uhg.comm.edelivery.reportingservice.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * This Model class represents the Printing Cost Report.
 *
 * @author Madhav Kulkarni.
 */
@Entity
@Table(name = "usp_printing_cost_report", schema = "edelivery")
@Data
@EqualsAndHashCode
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PrintingCostReport {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "printing_cost_report_id_seq")
    @SequenceGenerator(name = "printing_cost_report_id_seq", sequenceName = "printing_cost_report_id_seq", schema = "edelivery", allocationSize = 1)
    @Column(name = "id", updatable = false, nullable = false)
    private Integer id;

    @Column(name = "trail_name")
    private String trailName;

    @Column(name = "month_year")
    private LocalDate monthYear;

    @Column(name = "month_year_str")
    private String month;

    @Column(name = "bob")
    private String bob;

    @Column(name = "image_count")
    private double imageCount;

    @Column(name = "envelop_count")
    private double envelopCount;

    @Column(name = "paper_count")
    private double paperCount;

    @Column(name = "print_expense_cost")
    private double printExpenseCost;

    @Column(name = "postage_cost")
    private double postageCost;

    @Column(name = "total_expense")
    private double totalExpense;

    @Column(name = "image_per_envelop")
    private double imagePerEnvelop;

    @Column(name = "print_exp_per_image")
    private double printExpPerImage;

    @Column(name = "print_exp_per_envelop")
    private double printExpPerEnvelop;

    @Column(name = "postage_exp_per_envelop")
    private double postageExpPerEnvelop;

    @Column(name = "total_exp_envelop")
    private double totalExpPerEnvelop;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "modified_by")
    private String modifiedBy;

    @Column(name = "modified_date")
    private LocalDateTime modifiedDate;


}
