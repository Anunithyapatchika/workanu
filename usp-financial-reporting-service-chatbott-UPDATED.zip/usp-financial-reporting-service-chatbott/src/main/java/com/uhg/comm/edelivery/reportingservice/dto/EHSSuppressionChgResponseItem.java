package com.uhg.comm.edelivery.reportingservice.dto;

import lombok.Data;

@Data
public class EHSSuppressionChgResponseItem {
    private String bob;
    private double oldStmtSuppress;
    private double oldStmtPrint;
    private double StmtAffected;
}
