package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "consumerAccountTyp", "consumerAccountTotPaid", "consumerAccountPaidToMember",
		"consumerAccountPaidToProvider", "consumerAccountConsidered", "consumerAccountPended", "orderOfAccounts" })
@Generated("jsonschema2pojo")
public class ConsumerAccountPaid {

	@JsonProperty("consumerAccountTyp")
	private String consumerAccountTyp;
	@JsonProperty("consumerAccountTotPaid")
	private String consumerAccountTotPaid;
	@JsonProperty("consumerAccountPaidToMember")
	private String consumerAccountPaidToMember;
	@JsonProperty("consumerAccountPaidToProvider")
	private String consumerAccountPaidToProvider;
	@JsonProperty("consumerAccountConsidered")
	private String consumerAccountConsidered;
	@JsonProperty("consumerAccountPended")
	private String consumerAccountPended;
	@JsonProperty("orderOfAccounts")
	private String orderOfAccounts;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("consumerAccountTyp")
	public String getConsumerAccountTyp() {
		return consumerAccountTyp;
	}

	@JsonProperty("consumerAccountTyp")
	public void setConsumerAccountTyp(String consumerAccountTyp) {
		this.consumerAccountTyp = consumerAccountTyp;
	}

	@JsonProperty("consumerAccountTotPaid")
	public String getConsumerAccountTotPaid() {
		return consumerAccountTotPaid;
	}

	@JsonProperty("consumerAccountTotPaid")
	public void setConsumerAccountTotPaid(String consumerAccountTotPaid) {
		this.consumerAccountTotPaid = consumerAccountTotPaid;
	}

	@JsonProperty("consumerAccountPaidToMember")
	public String getConsumerAccountPaidToMember() {
		return consumerAccountPaidToMember;
	}

	@JsonProperty("consumerAccountPaidToMember")
	public void setConsumerAccountPaidToMember(String consumerAccountPaidToMember) {
		this.consumerAccountPaidToMember = consumerAccountPaidToMember;
	}

	@JsonProperty("consumerAccountPaidToProvider")
	public String getConsumerAccountPaidToProvider() {
		return consumerAccountPaidToProvider;
	}

	@JsonProperty("consumerAccountPaidToProvider")
	public void setConsumerAccountPaidToProvider(String consumerAccountPaidToProvider) {
		this.consumerAccountPaidToProvider = consumerAccountPaidToProvider;
	}

	@JsonProperty("consumerAccountConsidered")
	public String getConsumerAccountConsidered() {
		return consumerAccountConsidered;
	}

	@JsonProperty("consumerAccountConsidered")
	public void setConsumerAccountConsidered(String consumerAccountConsidered) {
		this.consumerAccountConsidered = consumerAccountConsidered;
	}

	@JsonProperty("consumerAccountPended")
	public String getConsumerAccountPended() {
		return consumerAccountPended;
	}

	@JsonProperty("consumerAccountPended")
	public void setConsumerAccountPended(String consumerAccountPended) {
		this.consumerAccountPended = consumerAccountPended;
	}

	@JsonProperty("orderOfAccounts")
	public String getOrderOfAccounts() {
		return orderOfAccounts;
	}

	@JsonProperty("orderOfAccounts")
	public void setOrderOfAccounts(String orderOfAccounts) {
		this.orderOfAccounts = orderOfAccounts;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(ConsumerAccountPaid.class.getName()).append('@')
				.append(Integer.toHexString(System.identityHashCode(this))).append('[');
		sb.append("consumerAccountTyp");
		sb.append('=');
		sb.append(((this.consumerAccountTyp == null) ? "<null>" : this.consumerAccountTyp));
		sb.append(',');
		sb.append("consumerAccountTotPaid");
		sb.append('=');
		sb.append(((this.consumerAccountTotPaid == null) ? "<null>" : this.consumerAccountTotPaid));
		sb.append(',');
		sb.append("consumerAccountPaidToMember");
		sb.append('=');
		sb.append(((this.consumerAccountPaidToMember == null) ? "<null>" : this.consumerAccountPaidToMember));
		sb.append(',');
		sb.append("consumerAccountPaidToProvider");
		sb.append('=');
		sb.append(((this.consumerAccountPaidToProvider == null) ? "<null>" : this.consumerAccountPaidToProvider));
		sb.append(',');
		sb.append("consumerAccountConsidered");
		sb.append('=');
		sb.append(((this.consumerAccountConsidered == null) ? "<null>" : this.consumerAccountConsidered));
		sb.append(',');
		sb.append("consumerAccountPended");
		sb.append('=');
		sb.append(((this.consumerAccountPended == null) ? "<null>" : this.consumerAccountPended));
		sb.append(',');
		sb.append("orderOfAccounts");
		sb.append('=');
		sb.append(((this.orderOfAccounts == null) ? "<null>" : this.orderOfAccounts));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
