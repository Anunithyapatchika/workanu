package com.uhg.comm.edelivery.reportingservice.nesslogger;

import com.optum.eis.kraken.core.constants.RequiredFieldsConstants;
import com.optum.eis.kraken.core.util.IpAddressUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Properties;

@Configuration
public class NessLoggerConfig {

	@Value("${ness.logger.askID}")
	private String applicationAskId;

	@Value("${ness.logger.applicationName}")
	private String applicationName;

	@Value("${ness.logger.deviceVendor}")
	private String deviceVendor;

	@Value("${ness.logger.deviceProduct}")
	private String deviceProduct;

	@Value("${WEBSITE_HOSTNAME}")
	private String hostName;

	public Properties loadRequiredFields(Properties properties) throws UnknownHostException {

		properties.put(RequiredFieldsConstants.APPLICATION_ASK_ID, applicationAskId);
		properties.put(RequiredFieldsConstants.APPLICATION_NAME, applicationName); // TPP
		properties.put(RequiredFieldsConstants.DEVICE_VENDOR, deviceVendor);
		properties.put(RequiredFieldsConstants.DEVICE_PRODUCT, deviceProduct);
		properties.put(RequiredFieldsConstants.DEVICE_HOSTNAME, hostName); // pl0sdlwk0007XM
		properties.put(RequiredFieldsConstants.RECEIVED_TIME, Long.toString(System.currentTimeMillis()));
		properties.put(RequiredFieldsConstants.DEVICE_IP4, Long.toString(IpAddressUtil.convert(getDeviceIp4())));
		return properties;
	}

	public String getDeviceIp4() throws UnknownHostException {
		InetAddress ip = InetAddress.getLocalHost();
		return ip.getHostAddress();
	}

}