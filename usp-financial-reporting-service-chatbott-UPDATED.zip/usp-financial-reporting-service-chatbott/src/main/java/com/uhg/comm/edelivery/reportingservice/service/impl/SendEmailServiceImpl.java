package com.uhg.comm.edelivery.reportingservice.service.impl;

import com.uhg.comm.edelivery.avrobean.Environments;
import com.uhg.comm.edelivery.emailservice.EmailService;
import com.uhg.comm.edelivery.processLog.Processlog;
import com.uhg.comm.edelivery.reportingservice.service.SendEmailService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;

import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SendEmailServiceImpl implements SendEmailService {

    @Autowired
    private EmailService emailService;

    @Value("${edelivery.configproperties.properties.edeliveryEmail.distributionEmails}")
    private String distributionEmails;

    @Value("${edelivery.configproperties.properties.edeliveryEmail.alertDistributionEmails}")
    private String alertDistributionEmails;

    @Value("${edelivery.configproperties.properties.edeliveryEmail.environment}")
    private String environment;


    public boolean sendEmail(Processlog processlog) {
        String subjectEnd = processlog.getTrailNumber();
        Context context = new Context();
        try {
            createContextForMail(context, processlog);
            String template = "success-mail-template";
            String to = distributionEmails;
            if (processlog.getStatus().equals("FAILED")) {
                template = "failed-mail-template";
                to = distributionEmails;
            } else if (processlog.getStatus().contains("SUCCESS")) {
                template = "success-mail-template";
                to = distributionEmails;
            } else if (processlog.getStatus().contains("NEW BOB DETECTED")) {
                template = "alert-mail-template";
                to = alertDistributionEmails;
            }



            emailService.sendMessageUsingThymeleafTemplate(to, context, template, subjectEnd, new ArrayList<>());
            return true;
        } catch (Exception e) {
            log.error("Error while sending email :: ",e);
            return false;
        }
    }

    public void createContextForMail(Context context, Processlog processlog) {

        Timestamp eventTimestamp = new Timestamp(System.currentTimeMillis());
        context.setVariable("status", processlog.getStatus());
        context.setVariable("environment", Environments.valueOf(environment.toUpperCase()).name());
        context.setVariable("source", processlog.getServiceName()+" - "+processlog.getApiName());
        context.setVariable("trailnum", processlog.getTrailNumber());
        context.setVariable("data", (null != processlog.getAdditionalProperties() && processlog.getAdditionalProperties().containsKey("list")) ? processlog.getAdditionalProperties().get("list") : "NO DATA");
        if (null != processlog.getAdditionalProperties() && processlog.getAdditionalProperties().containsKey("list")){
            List reports = (List) processlog.getAdditionalProperties().get("list");
            if (!reports.isEmpty()) {
                // Get field names dynamically from the first object
                List<String> fields = Arrays.stream(reports.get(0).getClass().getDeclaredFields())
                        .map(field -> {
                            field.setAccessible(true);
                            return field.getName();
                        })
                        .collect(Collectors.toList());

                // Get field values dynamically
                List<Map<String, Object>> reportData = (List<Map<String, Object>>) reports.stream()
                        .map(report -> {
                            Map<String, Object> fieldMap = new HashMap<>();
                            for (Field field : report.getClass().getDeclaredFields()) {
                                field.setAccessible(true);
                                try {
                                    fieldMap.put(field.getName(), field.get(report));
                                } catch (IllegalAccessException e) {
                                    log.error("Error accessing field {}: {}", field.getName(), e.getMessage());
                                }
                            }
                            return fieldMap;
                        })
                        .collect(Collectors.toList());
                log.info("class: {}", reports.get(0).getClass().getName());
                log.info("Report Data: {}", reportData);
                context.setVariable("class", reports.get(0).getClass().getName());
                context.setVariable("reportData", reportData);
            }
        }
        context.setVariable("fetchedDate", (null != processlog.getAdditionalProperties() && processlog.getAdditionalProperties().containsKey("fetchedDate")) ? processlog.getAdditionalProperties().get("fetchedDate").toString() : "");
        context.setVariable("newBob", (null != processlog.getAdditionalProperties() && processlog.getAdditionalProperties().containsKey("newBob")) ? processlog.getAdditionalProperties().get("newBob") : "");
        context.setVariable("newBobDate", (null != processlog.getAdditionalProperties() && processlog.getAdditionalProperties().containsKey("newBobDate")) ? processlog.getAdditionalProperties().get("newBobDate").toString() : "");
        if (StringUtils.isNotBlank(processlog.getReqEntryTimestamp())) {
            Timestamp startTime = Timestamp.valueOf(processlog.getReqEntryTimestamp());
            context.setVariable("startTime", startTime);
            context.setVariable("elapsedTime", emailService.calculateTimestampDifference(startTime, eventTimestamp));
        }
        context.setVariable("finishTime", eventTimestamp);

        if (processlog.getStatus().equals("FAILED")) {
            context.setVariable("errorMessage", processlog.getErrorMessage());
        }
    }
}
