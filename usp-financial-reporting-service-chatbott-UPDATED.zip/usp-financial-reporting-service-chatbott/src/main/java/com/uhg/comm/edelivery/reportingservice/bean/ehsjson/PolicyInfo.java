package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "parentPolNbr", "polQualifier", "polNbr", "polHldrNm", "polSitusState", "erisaInd", "planProdTyp",
		"fundArrngCd" })
@Generated("jsonschema2pojo")
public class PolicyInfo {

	@JsonProperty("parentPolNbr")
	private String parentPolNbr;
	@JsonProperty("polQualifier")
	private String polQualifier;
	@JsonProperty("polNbr")
	private String polNbr;
	@JsonProperty("polHldrNm")
	private String polHldrNm;
	@JsonProperty("polSitusState")
	private String polSitusState;
	@JsonProperty("erisaInd")
	private String erisaInd;
	@JsonProperty("planProdTyp")
	private String planProdTyp;
	@JsonProperty("fundArrngCd")
	private String fundArrngCd;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("parentPolNbr")
	public String getParentPolNbr() {
		return parentPolNbr;
	}

	@JsonProperty("parentPolNbr")
	public void setParentPolNbr(String parentPolNbr) {
		this.parentPolNbr = parentPolNbr;
	}

	@JsonProperty("polQualifier")
	public String getPolQualifier() {
		return polQualifier;
	}

	@JsonProperty("polQualifier")
	public void setPolQualifier(String polQualifier) {
		this.polQualifier = polQualifier;
	}

	@JsonProperty("polNbr")
	public String getPolNbr() {
		return polNbr;
	}

	@JsonProperty("polNbr")
	public void setPolNbr(String polNbr) {
		this.polNbr = polNbr;
	}

	@JsonProperty("polHldrNm")
	public String getPolHldrNm() {
		return polHldrNm;
	}

	@JsonProperty("polHldrNm")
	public void setPolHldrNm(String polHldrNm) {
		this.polHldrNm = polHldrNm;
	}

	@JsonProperty("polSitusState")
	public String getPolSitusState() {
		return polSitusState;
	}

	@JsonProperty("polSitusState")
	public void setPolSitusState(String polSitusState) {
		this.polSitusState = polSitusState;
	}

	@JsonProperty("erisaInd")
	public String getErisaInd() {
		return erisaInd;
	}

	@JsonProperty("erisaInd")
	public void setErisaInd(String erisaInd) {
		this.erisaInd = erisaInd;
	}

	@JsonProperty("planProdTyp")
	public String getPlanProdTyp() {
		return planProdTyp;
	}

	@JsonProperty("planProdTyp")
	public void setPlanProdTyp(String planProdTyp) {
		this.planProdTyp = planProdTyp;
	}

	@JsonProperty("fundArrngCd")
	public String getFundArrngCd() {
		return fundArrngCd;
	}

	@JsonProperty("fundArrngCd")
	public void setFundArrngCd(String fundArrngCd) {
		this.fundArrngCd = fundArrngCd;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(PolicyInfo.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this)))
				.append('[');
		sb.append("parentPolNbr");
		sb.append('=');
		sb.append(((this.parentPolNbr == null) ? "<null>" : this.parentPolNbr));
		sb.append(',');
		sb.append("polQualifier");
		sb.append('=');
		sb.append(((this.polQualifier == null) ? "<null>" : this.polQualifier));
		sb.append(',');
		sb.append("polNbr");
		sb.append('=');
		sb.append(((this.polNbr == null) ? "<null>" : this.polNbr));
		sb.append(',');
		sb.append("polHldrNm");
		sb.append('=');
		sb.append(((this.polHldrNm == null) ? "<null>" : this.polHldrNm));
		sb.append(',');
		sb.append("polSitusState");
		sb.append('=');
		sb.append(((this.polSitusState == null) ? "<null>" : this.polSitusState));
		sb.append(',');
		sb.append("erisaInd");
		sb.append('=');
		sb.append(((this.erisaInd == null) ? "<null>" : this.erisaInd));
		sb.append(',');
		sb.append("planProdTyp");
		sb.append('=');
		sb.append(((this.planProdTyp == null) ? "<null>" : this.planProdTyp));
		sb.append(',');
		sb.append("fundArrngCd");
		sb.append('=');
		sb.append(((this.fundArrngCd == null) ? "<null>" : this.fundArrngCd));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
