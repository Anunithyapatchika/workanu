package com.uhg.comm.edelivery.reportingservice.config;

import com.uhg.comm.edelivery.reportingservice.util.OpenAIPropertiesUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration class for OpenAI integration
 * This wraps OpenAIPropertiesUtil and provides access to Azure Key Vault secrets
 */
@Configuration
public class OpenAIConfig {
    
    @Autowired
    private OpenAIPropertiesUtil openAIProperties;
    
    @Value("${openai-api-key:}")
    private String apiKey;
    
    public String getUrl() {
        return openAIProperties.getUrl();
    }
    
    public String getEndpoint() {
        return openAIProperties.getEndpoint();
    }
    
    public String getApiKey() {
        return apiKey;
    }
    
    public OpenAIPropertiesUtil.SearchConfig getKnowledgeSearch() {
        return openAIProperties.getKnowledgeSearch();
    }
    
    public OpenAIPropertiesUtil.SearchConfig getMonitoringSearch() {
        return openAIProperties.getMonitoringSearch();
    }
    
    public OpenAIPropertiesUtil.SearchConfig getRcaSearch() {
        return openAIProperties.getRcaSearch();
    }
}
