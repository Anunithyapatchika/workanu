package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "marriedClaimInd", "adverseClaimInd", "overrideCd" })
@Generated("jsonschema2pojo")
public class OtherClaimAttributes {

	@JsonProperty("marriedClaimInd")
	private String marriedClaimInd;
	@JsonProperty("adverseClaimInd")
	private String adverseClaimInd;
	@JsonProperty("overrideCd")
	private String overrideCd;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("marriedClaimInd")
	public String getMarriedClaimInd() {
		return marriedClaimInd;
	}

	@JsonProperty("marriedClaimInd")
	public void setMarriedClaimInd(String marriedClaimInd) {
		this.marriedClaimInd = marriedClaimInd;
	}

	@JsonProperty("adverseClaimInd")
	public String getAdverseClaimInd() {
		return adverseClaimInd;
	}

	@JsonProperty("adverseClaimInd")
	public void setAdverseClaimInd(String adverseClaimInd) {
		this.adverseClaimInd = adverseClaimInd;
	}

	@JsonProperty("overrideCd")
	public String getOverrideCd() {
		return overrideCd;
	}

	@JsonProperty("overrideCd")
	public void setOverrideCd(String overrideCd) {
		this.overrideCd = overrideCd;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(OtherClaimAttributes.class.getName()).append('@')
				.append(Integer.toHexString(System.identityHashCode(this))).append('[');
		sb.append("marriedClaimInd");
		sb.append('=');
		sb.append(((this.marriedClaimInd == null) ? "<null>" : this.marriedClaimInd));
		sb.append(',');
		sb.append("adverseClaimInd");
		sb.append('=');
		sb.append(((this.adverseClaimInd == null) ? "<null>" : this.adverseClaimInd));
		sb.append(',');
		sb.append("overrideCd");
		sb.append('=');
		sb.append(((this.overrideCd == null) ? "<null>" : this.overrideCd));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
