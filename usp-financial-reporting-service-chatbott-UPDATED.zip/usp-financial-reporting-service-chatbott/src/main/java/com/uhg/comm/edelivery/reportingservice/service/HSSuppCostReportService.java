package com.uhg.comm.edelivery.reportingservice.service;

import com.uhg.comm.edelivery.reportingservice.bean.GetFieldValues;
import com.uhg.comm.edelivery.reportingservice.constants.Constants;
import com.uhg.comm.edelivery.reportingservice.dto.*;
import com.uhg.comm.edelivery.reportingservice.exception.USPException;
import com.uhg.comm.edelivery.reportingservice.model.HSSuppCostReport;
import com.uhg.comm.edelivery.reportingservice.model.PrintingCostReport;
import com.uhg.comm.edelivery.reportingservice.repository.HSSuppCostReportRepository;
import com.uhg.comm.edelivery.reportingservice.util.CalculationUtils;
import com.uhg.comm.edelivery.reportingservice.util.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class HSSuppCostReportService {

    @Autowired
    private HSSuppCostReportRepository hsSuppCostReportRepository;

    /**
     * Method to get HS Suppression Cost Report.
     *
     * @param trailNumber the trail number.
     * @param startDate   the start date.
     * @param endDate     the end date.
     * @return the list of HS Suppression Cost DTOs.
     */
    public EHSFinancialReportResponseDto getHSSuppCostReport(String trailNumber, String startDate, String endDate) {
        LocalDate start = DateUtil.getLocalDate(startDate, Constants.MONTH_YEAR_FORMAT);
        LocalDate end = DateUtil.getLocalDate(endDate, Constants.MONTH_YEAR_FORMAT);
        EHSFinancialReportResponseDto ehsFinancialReportResponseDto = new EHSFinancialReportResponseDto();
        LocalDate endDateWithMonth = end.withDayOfMonth(end.getMonth().length(end.isLeapYear()));
        if (trailNumber.matches("^[a-zA-Z0-9._-]+$")) {
            log.info("Fetching HSSuppCostReport for trailNumber: {}, monthYear: {}, bob: {}",
                    trailNumber, start, endDateWithMonth);
        }
        List<HSSuppCostReport> reportList =
                hsSuppCostReportRepository.findByTrailNumberAndBetweenMonthYearStr(trailNumber, start, endDateWithMonth);
        if (CollectionUtils.isEmpty(reportList)) {
            ehsFinancialReportResponseDto.setHsSuppCostReport(Collections.emptyList());
            return ehsFinancialReportResponseDto;
        }
        Map<String, List<HSSuppCostReport>> groupedByMonthYear = reportList.stream()
                .collect(Collectors.groupingBy(HSSuppCostReport::getMonth, LinkedHashMap::new, Collectors.toList()));

        List<HsSuppCostDto> hsSuppCostDtoList = new ArrayList<>();
        groupedByMonthYear.forEach((monthYear, reports) -> {
            HsSuppCostDto hsSuppCostDto = new HsSuppCostDto(); // Creates a new EOB report DTO.
            hsSuppCostDto.setDate(monthYear); // Sets the date for the EOB report.
            hsSuppCostDto.setTrailName(trailNumber); // Sets the trail number for the EOB report.
            List<HsSuppCostItemsDto> itemsDtos = reports.stream()
                    .map(HSSuppCostReportService::getHsSuppCostReportItems).collect(Collectors.toList()); // Maps the reports to EOB report items
            // Calculate Monthly Total
            HsSuppCostItemsDto monthlyTotal = getTotalOfHsSuppItems(Constants.MONTHLY_TOTAL, itemsDtos);
            itemsDtos.add(monthlyTotal); // Adds the monthly total to the HS Supp Cost report.
            hsSuppCostDto.setItems(itemsDtos); // Sets the items for the HS Supp Cost report.
            hsSuppCostDtoList.add(hsSuppCostDto); // Adds the HS Supp Cost report to the list of HS Supp Cost reports.
        });

        if (hsSuppCostDtoList.size() > 1) {
            getPeriodTotal(startDate, endDate, trailNumber, hsSuppCostDtoList);
        }

        List<EHSSuppressionChgResponse> hsSuppressionChgResponseList = new ArrayList<>();
        groupedByMonthYear.forEach((monthYear, reports) -> {
            EHSSuppressionChgResponse ehsSuppressionChgResponse = new EHSSuppressionChgResponse();
            ehsSuppressionChgResponse.setDate(monthYear);
            ehsSuppressionChgResponse.setTrailName(trailNumber);
            List<EHSSuppressionChgResponseItem> itemsDtos = reports.stream()
                    .map(HSSuppCostReportService::getEHSSuppressionChgResponseItem).collect(Collectors.toList()); // Maps the reports to EOB report items
            // Calculate Monthly Total
            EHSSuppressionChgResponseItem monthlyTotal = getTotalOfEHSSuppressionChgResponseItems(Constants.MONTHLY_TOTAL, itemsDtos);
            itemsDtos.add(monthlyTotal); // Adds the monthly total to the HS Supp Cost report.
            ehsSuppressionChgResponse.setItems(itemsDtos); // Sets the items for the HS Supp Cost report.
            hsSuppressionChgResponseList.add(ehsSuppressionChgResponse); // Adds the HS Supp Cost report to the list of HS Supp Cost reports.
        });

        if (hsSuppressionChgResponseList.size() > 1) {
            getPeriodTotal1(startDate, endDate, trailNumber, hsSuppressionChgResponseList);
        }


        ehsFinancialReportResponseDto.setHsSuppCostReport(hsSuppCostDtoList);
        ehsFinancialReportResponseDto.setEhsSuppressionChgResponses(hsSuppressionChgResponseList);

        return ehsFinancialReportResponseDto;
    }

    /**
     * Method to get Period Total.
     *
     * @param startDate         the start date.
     * @param endDate           the end date.
     * @param trailName         the trail name.
     * @param hsSuppCostDtoList the list of HS Supp Cost DTOs.
     */
    private void getPeriodTotal(String startDate, String endDate,
                                String trailName, List<HsSuppCostDto> hsSuppCostDtoList) {
        if (StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate) && !startDate.equals(endDate)) {
            HsSuppCostDto periodTotal = new HsSuppCostDto();
            periodTotal.setDate(Constants.PERIOD_TOTAL);
            periodTotal.setTrailName(trailName);

            List<HsSuppCostItemsDto> itemsDtos = hsSuppCostDtoList.stream()
                    .flatMap(hsSuppCostDto -> hsSuppCostDto.getItems().stream())
                    .filter(Objects::nonNull)
                    .collect(Collectors.groupingBy(HsSuppCostItemsDto::getBob))
                    .entrySet().stream().map(entry -> {
                        String bob = entry.getKey();
                        if (Constants.MONTHLY_TOTAL.equalsIgnoreCase(bob)) {
                           bob = Constants.TOTAL;
                        }
                        List<HsSuppCostItemsDto> items = entry.getValue();
                        return getTotalOfHsSuppItems(bob, items);
                    }).collect(Collectors.toList());

            List<HsSuppCostItemsDto> otherDtos = itemsDtos.stream().filter(p -> !Constants.TOTAL.equalsIgnoreCase(p.getBob())).collect(Collectors.toList());
            List<HsSuppCostItemsDto> totalDtos = itemsDtos.stream().filter(p -> Constants.TOTAL.equalsIgnoreCase(p.getBob())).collect(Collectors.toList());
            itemsDtos.clear();
            itemsDtos.addAll(otherDtos);
            itemsDtos.addAll(totalDtos);
            periodTotal.setItems(itemsDtos);
            hsSuppCostDtoList.add(periodTotal);
        }
    }

    private static HsSuppCostItemsDto getHsSuppCostReportItems(HSSuppCostReport report) {
        HsSuppCostItemsDto item = new HsSuppCostItemsDto();
        item.setBob(report.getBob());
        item.setPostageCost(report.getPostageCost());
        item.setPrintCost(report.getPrintingCost());
        item.setStmtPrinted(report.getStatementPrinted());
        item.setHsSuppMemberElection(report.getMemberElectionHSSupp());
        item.setHsSuppPolicySetting(report.getPolicySettingHSSupp());
        item.setTotalStmtSupp(report.getTotalStmtSuppressed());
        item.setTotalStmtGenerated(report.getTotalStmtGenerated());
        item.setTotalPrintPostCost(report.getTotalPrintPostageCost());
        item.setHsSuppressedPercent(report.getHsSuppressPercent());
        item.setCostPerPrintedStmt(report.getCostPerStmt());
        item.setTotalSheets(report.getTotalSheets());
        item.setSheetsPerPrintedStmt(report.getSheetsPerPrintedStmt());
        item.setNumberOfClaims(report.getTotalClaims());
        return item;
    }

    private static HsSuppCostItemsDto getTotalOfHsSuppItems(String bob, List<HsSuppCostItemsDto> items) {
        HsSuppCostItemsDto itemsDto = new HsSuppCostItemsDto();
        itemsDto.setBob(bob);

        BigDecimal totalPostage =  BigDecimal.valueOf(items.stream().mapToDouble(HsSuppCostItemsDto::getPostageCost).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalPrintCost = BigDecimal.valueOf(items.stream().mapToDouble(HsSuppCostItemsDto::getPrintCost).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalStmtPrinted = BigDecimal.valueOf(items.stream().mapToDouble(HsSuppCostItemsDto::getStmtPrinted).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalHsSuppMemberElection = BigDecimal.valueOf(items.stream().mapToDouble(HsSuppCostItemsDto::getHsSuppMemberElection).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalHsSuppPolicySetting =BigDecimal.valueOf( items.stream().mapToDouble(HsSuppCostItemsDto::getHsSuppPolicySetting).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalStmtSupp = BigDecimal.valueOf(items.stream().mapToDouble(HsSuppCostItemsDto::getTotalStmtSupp).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalStmtGenerated = BigDecimal.valueOf(items.stream().mapToDouble(HsSuppCostItemsDto::getTotalStmtGenerated).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal hsSuppressedPercent = BigDecimal.valueOf(items.stream().mapToDouble(HsSuppCostItemsDto::getHsSuppressedPercent).average().orElse(0)).setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalPrintPostCost = BigDecimal.valueOf(items.stream().mapToDouble(HsSuppCostItemsDto::getTotalPrintPostCost).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalSheets = BigDecimal.valueOf(items.stream().mapToDouble(HsSuppCostItemsDto::getTotalSheets).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal costPerPrintStmt = BigDecimal.valueOf(items.stream().mapToDouble(HsSuppCostItemsDto::getCostPerPrintedStmt).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalClaims = BigDecimal.valueOf(items.stream().mapToDouble(HsSuppCostItemsDto::getNumberOfClaims).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal sheetsPerPrintedStmt = BigDecimal.valueOf(items.stream().mapToDouble(HsSuppCostItemsDto::getSheetsPerPrintedStmt).sum()).setScale(2, RoundingMode.HALF_UP);

        itemsDto.setPostageCost(totalPostage.doubleValue());
        itemsDto.setPrintCost(totalPrintCost.doubleValue());
        itemsDto.setStmtPrinted(totalStmtPrinted.doubleValue());
        itemsDto.setHsSuppMemberElection(totalHsSuppMemberElection.doubleValue());
        itemsDto.setHsSuppPolicySetting(totalHsSuppPolicySetting.doubleValue());
        itemsDto.setTotalStmtSupp(totalStmtSupp.doubleValue());
        itemsDto.setTotalStmtGenerated(totalStmtGenerated.doubleValue());
        itemsDto.setHsSuppressedPercent(CalculationUtils.roundOf((itemsDto.getTotalStmtSupp()/itemsDto.getTotalStmtGenerated())*100));
        itemsDto.setTotalPrintPostCost(totalPrintPostCost.doubleValue());
        itemsDto.setCostPerPrintedStmt(costPerPrintStmt.doubleValue());
        itemsDto.setTotalSheets(totalSheets.doubleValue());
        itemsDto.setSheetsPerPrintedStmt(sheetsPerPrintedStmt.doubleValue());
        itemsDto.setNumberOfClaims(totalClaims.doubleValue());

        return itemsDto;
    }

    public void saveHsSuppDataFromPrintCostReport(PrintingCostReport printingCostReport) {
        log.info("Getting HS Suppression Cost report from  Printing Cost Report: {}", printingCostReport);
        String trailName = printingCostReport.getTrailName();
        String month = printingCostReport.getMonth();
        String bob = printingCostReport.getBob();
        Optional<HSSuppCostReport> optional = hsSuppCostReportRepository.findByTrailNameBobAndMonth(trailName, bob, month);
        if (optional.isPresent()) {
            HSSuppCostReport hsSuppCostReport = optional.get();
            if (hsSuppCostReport.getIsCompleted() == 1) {
                if (trailName.matches("^[a-zA-Z0-9._-]+$") && month.matches("^[a-zA-Z0-9._-]+$") && bob.matches("^[a-zA-Z0-9._-]+$")) {
                    log.info("HS Suppression Cost Report is already completed for trailName: {}, month: {}, bob: {} . Still updating...", trailName, month, bob);
                }
            }
            hsSuppCostReport.setPostageCost(printingCostReport.getPostageCost());
            hsSuppCostReport.setPrintingCost(printingCostReport.getPrintExpenseCost());
            hsSuppCostReport.setTotalSheets(printingCostReport.getPaperCount());
            double statementPrinted = hsSuppCostReport.getStatementPrinted();
            double totalStmtSuppressed = hsSuppCostReport.getTotalStmtSuppressed();
            hsSuppCostReport.setTotalPrintPostageCost(hsSuppCostReport.getPostageCost() + hsSuppCostReport.getPrintingCost());
            if (statementPrinted == 0 || totalStmtSuppressed == 0) {
                if (trailName.matches("^[a-zA-Z0-9._-]+$") && month.matches("^[a-zA-Z0-9._-]+$") && bob.matches("^[a-zA-Z0-9._-]+$")) {
                    log.info("Cannot update entire object. Statement Printed and Total Statement Suppressed is 0 for trailName: {}, month: {}, bob: {}",
                            trailName, month, bob);
                }
                log.info("Cannot update the calculations in the HS Suppression Cost Report.");
                hsSuppCostReport.setIsCompleted(0);
                save(hsSuppCostReport);
            } else {     // if (hsSuppCostReport.getIsTxCompleted() == 1){
                if (trailName.matches("^[a-zA-Z0-9._-]+$") && month.matches("^[a-zA-Z0-9._-]+$") && bob.matches("^[a-zA-Z0-9._-]+$")) {
                    log.info("Updating calculations in HS Suppression Cost Report for trailName: {}, month: {}, bob: {}",
                            trailName, month, bob);
                }
                double costPerPrintedStmt = hsSuppCostReport.getTotalPrintPostageCost() / statementPrinted;
                costPerPrintedStmt = CalculationUtils.roundOf(costPerPrintedStmt);
                hsSuppCostReport.setCostPerStmt(costPerPrintedStmt);
                double sheetsPerPrintedStmt = hsSuppCostReport.getTotalSheets() / statementPrinted;
                sheetsPerPrintedStmt = CalculationUtils.roundOf(sheetsPerPrintedStmt);
                hsSuppCostReport.setSheetsPerPrintedStmt(sheetsPerPrintedStmt);
                double hsSuppPercent = (hsSuppCostReport.getTotalStmtSuppressed() / hsSuppCostReport.getTotalStmtGenerated()) * 100;
                hsSuppPercent = CalculationUtils.roundOf(hsSuppPercent);
                hsSuppCostReport.setHsSuppressPercent(hsSuppPercent);
                hsSuppCostReport.setIsCompleted(1);
                hsSuppCostReport.setModifiedBy(Constants.USP_REPORTING_UI_SERVICE);
                hsSuppCostReport.setModifiedDate(LocalDateTime.now());
                save(hsSuppCostReport);
            } // else {
//                log.info("Nothing changed in HS Suppression Cost Report for trailName: {}, month: {}, bob: {}", trailName, month, bob);
//            }
        } else {
            if (trailName.matches("^[a-zA-Z0-9._-]+$") && month.matches("^[a-zA-Z0-9._-]+$") && bob.matches("^[a-zA-Z0-9._-]+$")) {
                log.info("Updating calculations in HS Suppression Cost Report for trailName: {}, month: {}, bob: {}",
                        trailName, month, bob);
            }
            LocalDate monthYear;
            try {
                monthYear = DateUtil.getLocalDate(month, Constants.MONTH_YEAR_FORMAT);
            } catch (Exception e) {
                log.error("Error while parsing date", e);
                throw new USPException("Error while parsing date", e);
            }

            HSSuppCostReport costReport = HSSuppCostReport.builder()
                    .trailName(trailName)
                    .bob(bob)
                    .month(month)
                    .monthYear(monthYear)
                    .postageCost(printingCostReport.getPostageCost())
                    .printingCost(printingCostReport.getPrintExpenseCost())
                    .totalSheets(printingCostReport.getPaperCount())
                    .isCompleted(0)
                    .isTxCompleted(0)
                    .createdBy(Constants.USP_REPORTING_UI_SERVICE)
                    .createdDate(LocalDateTime.now())
                    .modifiedDate(LocalDateTime.now())
                    .modifiedBy(Constants.USP_REPORTING_UI_SERVICE)
                    .build();

            log.info("Saving brand new HS Suppression Cost Report entry : {}", costReport);
            save(costReport);
        }
    }

    public void save(HSSuppCostReport hsSuppCostReport) {
        log.info("Saving HS Suppression Cost Report: {}", hsSuppCostReport);
        hsSuppCostReportRepository.save(hsSuppCostReport);
    }

    public HashMap<String, List<GetFieldValues>> fetchIsCompletedValues(String trailName, String startDate, String endDate) {
        LocalDate start = DateUtil.getLocalDate(startDate, Constants.MONTH_YEAR_FORMAT);
        LocalDate end = DateUtil.getLocalDate(endDate, Constants.MONTH_YEAR_FORMAT);
        LocalDate endDateWithMonth = end.withDayOfMonth(end.getMonth().length(end.isLeapYear()));
        if (trailName.matches("^[a-zA-Z0-9._-]+$")){
            log.info("Fetching HS Suppression Cost Report for trailName: {}, monthYear: {}, bob: {}",
                    trailName, start, endDateWithMonth);

        }
        List<Object[]> reports  = hsSuppCostReportRepository.getDetailsFromDB(trailName, start, endDateWithMonth);
        log.info("Reports size: {}", reports.size());
        if(reports.isEmpty()){
            if (trailName.matches("^[a-zA-Z0-9._-]+$") && startDate.matches("^[a-zA-Z0-9._-]+$") && endDate.matches("^[a-zA-Z0-9._-]+$")) {
                log.info("No records found for trailName: {}, startDate: {}, endDate: {}",
                        trailName, startDate, endDate);
            }
            return new HashMap<>();
        }

        Map<String, List<GetFieldValues>> fieldMap = reports.stream().collect(
                Collectors.groupingBy(
                        report -> (String) report[1],
                        Collectors.mapping(report -> {
                            log.info("Report: {}", Arrays.toString(report));
                            GetFieldValues getFieldValues = new GetFieldValues();
                            getFieldValues.setBob((String) report[0]);
                            getFieldValues.setIsCompleted((Integer) report[2]);
                            getFieldValues.setIsTxCompleted((Integer) report[3]);
                            return getFieldValues;
                        }, Collectors.toList())
                )
        );

        return new HashMap<>(fieldMap);
    }

    private static EHSSuppressionChgResponseItem getEHSSuppressionChgResponseItem(HSSuppCostReport report) {

        EHSSuppressionChgResponseItem item = new EHSSuppressionChgResponseItem();
        item.setBob(report.getBob());
        item.setOldStmtSuppress(report.getTotalStmtSuppressed()+report.getMemPrint());
        item.setOldStmtPrint(report.getStatementPrinted()-report.getMemPrint());
        item.setStmtAffected(report.getMemPrint());

        return item;
    }

    private static EHSSuppressionChgResponseItem getTotalOfEHSSuppressionChgResponseItems(String bob, List<EHSSuppressionChgResponseItem> items) {

        EHSSuppressionChgResponseItem itemsDto = new EHSSuppressionChgResponseItem();
        itemsDto.setBob(bob);

        BigDecimal totalOldStmtSuppress =  BigDecimal.valueOf(items.stream().mapToDouble(EHSSuppressionChgResponseItem::getOldStmtSuppress).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalOldStmtPrint = BigDecimal.valueOf(items.stream().mapToDouble(EHSSuppressionChgResponseItem::getOldStmtPrint).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalStmtPrinted = BigDecimal.valueOf(items.stream().mapToDouble(EHSSuppressionChgResponseItem::getStmtAffected).sum()).setScale(2, RoundingMode.HALF_UP);

        itemsDto.setOldStmtSuppress(totalOldStmtSuppress.doubleValue());
        itemsDto.setOldStmtPrint(totalOldStmtPrint.doubleValue());
        itemsDto.setStmtAffected(totalStmtPrinted.doubleValue());

        return itemsDto;
    }

    private void getPeriodTotal1(String startDate, String endDate,
                                String trailName, List<EHSSuppressionChgResponse> ehsSuppressionChgResponseList) {
        if (StringUtils.isNotBlank(startDate) && StringUtils.isNotBlank(endDate) && !startDate.equals(endDate)) {
            EHSSuppressionChgResponse periodTotal = new EHSSuppressionChgResponse();
            periodTotal.setDate(Constants.PERIOD_TOTAL);
            periodTotal.setTrailName(trailName);

            List<EHSSuppressionChgResponseItem> itemsDtos = ehsSuppressionChgResponseList.stream()
                    .flatMap(ehsSuppressionChgResponse -> ehsSuppressionChgResponse.getItems().stream())
                    .filter(Objects::nonNull)
                    .collect(Collectors.groupingBy(EHSSuppressionChgResponseItem::getBob))
                    .entrySet().stream().map(entry -> {
                        String bob = entry.getKey();
                        if (Constants.MONTHLY_TOTAL.equalsIgnoreCase(bob)) {
                            bob = Constants.TOTAL;
                        }
                        List<EHSSuppressionChgResponseItem> items = entry.getValue();
                        return getTotalOfEHSSuppressionChgResponseItems(bob, items);
                    }).collect(Collectors.toList());

            List<EHSSuppressionChgResponseItem> otherDtos = itemsDtos.stream().filter(p -> !Constants.TOTAL.equalsIgnoreCase(p.getBob())).collect(Collectors.toList());
            List<EHSSuppressionChgResponseItem> totalDtos = itemsDtos.stream().filter(p -> Constants.TOTAL.equalsIgnoreCase(p.getBob())).collect(Collectors.toList());
            itemsDtos.clear();
            itemsDtos.addAll(otherDtos);
            itemsDtos.addAll(totalDtos);
            periodTotal.setItems(itemsDtos);
            ehsSuppressionChgResponseList.add(periodTotal);
        }
    }

}
