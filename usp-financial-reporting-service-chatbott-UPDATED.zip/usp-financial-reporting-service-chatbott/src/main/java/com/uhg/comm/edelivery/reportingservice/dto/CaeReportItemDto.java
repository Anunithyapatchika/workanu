package com.uhg.comm.edelivery.reportingservice.dto;

import lombok.Data;

@Data
public class CaeReportItemDto {
    private String bob;
    private double totalCaeSuppressionEobsGenerated;
    private double caeSuppressionEobsWithEmail;
    private double caeSuppressionEobsNoEmail;
}