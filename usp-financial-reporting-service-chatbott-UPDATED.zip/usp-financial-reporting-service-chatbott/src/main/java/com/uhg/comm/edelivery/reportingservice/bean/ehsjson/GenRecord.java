package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "stmtBeginDt", "stmtEndDt", "stmtOvrCd", "subscriberInfo", "policyInfo", "mailingAddrInfo",
		"returnAddrInfo", "brandingInfo" })
@Generated("jsonschema2pojo")
public class GenRecord {

	@JsonProperty("stmtBeginDt")
	private String stmtBeginDt;
	@JsonProperty("stmtEndDt")
	private String stmtEndDt;
	@JsonProperty("stmtOvrCd")
	private String stmtOvrCd;
	@JsonProperty("subscriberInfo")
	private SubscriberInfo subscriberInfo;
	@JsonProperty("policyInfo")
	private PolicyInfo policyInfo;
	@JsonProperty("mailingAddrInfo")
	private MailingAddrInfo mailingAddrInfo;
	@JsonProperty("returnAddrInfo")
	private ReturnAddrInfo returnAddrInfo;
	@JsonProperty("brandingInfo")
	private BrandingInfo brandingInfo;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("stmtBeginDt")
	public String getStmtBeginDt() {
		return stmtBeginDt;
	}

	@JsonProperty("stmtBeginDt")
	public void setStmtBeginDt(String stmtBeginDt) {
		this.stmtBeginDt = stmtBeginDt;
	}

	@JsonProperty("stmtEndDt")
	public String getStmtEndDt() {
		return stmtEndDt;
	}

	@JsonProperty("stmtEndDt")
	public void setStmtEndDt(String stmtEndDt) {
		this.stmtEndDt = stmtEndDt;
	}

	@JsonProperty("stmtOvrCd")
	public String getStmtOvrCd() {
		return stmtOvrCd;
	}

	@JsonProperty("stmtOvrCd")
	public void setStmtOvrCd(String stmtOvrCd) {
		this.stmtOvrCd = stmtOvrCd;
	}

	@JsonProperty("subscriberInfo")
	public SubscriberInfo getSubscriberInfo() {
		return subscriberInfo;
	}

	@JsonProperty("subscriberInfo")
	public void setSubscriberInfo(SubscriberInfo subscriberInfo) {
		this.subscriberInfo = subscriberInfo;
	}

	@JsonProperty("policyInfo")
	public PolicyInfo getPolicyInfo() {
		return policyInfo;
	}

	@JsonProperty("policyInfo")
	public void setPolicyInfo(PolicyInfo policyInfo) {
		this.policyInfo = policyInfo;
	}

	@JsonProperty("mailingAddrInfo")
	public MailingAddrInfo getMailingAddrInfo() {
		return mailingAddrInfo;
	}

	@JsonProperty("mailingAddrInfo")
	public void setMailingAddrInfo(MailingAddrInfo mailingAddrInfo) {
		this.mailingAddrInfo = mailingAddrInfo;
	}

	@JsonProperty("returnAddrInfo")
	public ReturnAddrInfo getReturnAddrInfo() {
		return returnAddrInfo;
	}

	@JsonProperty("returnAddrInfo")
	public void setReturnAddrInfo(ReturnAddrInfo returnAddrInfo) {
		this.returnAddrInfo = returnAddrInfo;
	}

	@JsonProperty("brandingInfo")
	public BrandingInfo getBrandingInfo() {
		return brandingInfo;
	}

	@JsonProperty("brandingInfo")
	public void setBrandingInfo(BrandingInfo brandingInfo) {
		this.brandingInfo = brandingInfo;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(GenRecord.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this)))
				.append('[');
		sb.append("stmtBeginDt");
		sb.append('=');
		sb.append(((this.stmtBeginDt == null) ? "<null>" : this.stmtBeginDt));
		sb.append(',');
		sb.append("stmtEndDt");
		sb.append('=');
		sb.append(((this.stmtEndDt == null) ? "<null>" : this.stmtEndDt));
		sb.append(',');
		sb.append("stmtOvrCd");
		sb.append('=');
		sb.append(((this.stmtOvrCd == null) ? "<null>" : this.stmtOvrCd));
		sb.append(',');
		sb.append("subscriberInfo");
		sb.append('=');
		sb.append(((this.subscriberInfo == null) ? "<null>" : this.subscriberInfo));
		sb.append(',');
		sb.append("policyInfo");
		sb.append('=');
		sb.append(((this.policyInfo == null) ? "<null>" : this.policyInfo));
		sb.append(',');
		sb.append("mailingAddrInfo");
		sb.append('=');
		sb.append(((this.mailingAddrInfo == null) ? "<null>" : this.mailingAddrInfo));
		sb.append(',');
		sb.append("returnAddrInfo");
		sb.append('=');
		sb.append(((this.returnAddrInfo == null) ? "<null>" : this.returnAddrInfo));
		sb.append(',');
		sb.append("brandingInfo");
		sb.append('=');
		sb.append(((this.brandingInfo == null) ? "<null>" : this.brandingInfo));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
