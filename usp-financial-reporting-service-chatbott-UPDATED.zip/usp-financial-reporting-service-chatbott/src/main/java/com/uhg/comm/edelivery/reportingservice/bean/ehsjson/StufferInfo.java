package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "stufferID", "stufferElecDocExcludeInd", "lstPageOfDocInd" })
@Generated("jsonschema2pojo")
public class StufferInfo {

	@JsonProperty("stufferID")
	private String stufferID;
	@JsonProperty("stufferElecDocExcludeInd")
	private String stufferElecDocExcludeInd;
	@JsonProperty("lstPageOfDocInd")
	private String lstPageOfDocInd;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("stufferID")
	public String getStufferID() {
		return stufferID;
	}

	@JsonProperty("stufferID")
	public void setStufferID(String stufferID) {
		this.stufferID = stufferID;
	}

	@JsonProperty("stufferElecDocExcludeInd")
	public String getStufferElecDocExcludeInd() {
		return stufferElecDocExcludeInd;
	}

	@JsonProperty("stufferElecDocExcludeInd")
	public void setStufferElecDocExcludeInd(String stufferElecDocExcludeInd) {
		this.stufferElecDocExcludeInd = stufferElecDocExcludeInd;
	}

	@JsonProperty("lstPageOfDocInd")
	public String getLstPageOfDocInd() {
		return lstPageOfDocInd;
	}

	@JsonProperty("lstPageOfDocInd")
	public void setLstPageOfDocInd(String lstPageOfDocInd) {
		this.lstPageOfDocInd = lstPageOfDocInd;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(StufferInfo.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this)))
				.append('[');
		sb.append("stufferID");
		sb.append('=');
		sb.append(((this.stufferID == null) ? "<null>" : this.stufferID));
		sb.append(',');
		sb.append("stufferElecDocExcludeInd");
		sb.append('=');
		sb.append(((this.stufferElecDocExcludeInd == null) ? "<null>" : this.stufferElecDocExcludeInd));
		sb.append(',');
		sb.append("lstPageOfDocInd");
		sb.append('=');
		sb.append(((this.lstPageOfDocInd == null) ? "<null>" : this.lstPageOfDocInd));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
