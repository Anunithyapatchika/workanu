package com.uhg.comm.edelivery.reportingservice.controller;

import com.uhg.comm.edelivery.reportingservice.bean.GetFieldValues;
import com.uhg.comm.edelivery.reportingservice.service.HSSuppCostReportService;
import com.uhg.comm.edelivery.reportingservice.service.USPFinancialReportService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("status")
@CrossOrigin
public class StatusController {

    @Autowired
    private USPFinancialReportService uspFinancialReportService;

    @Autowired
    private HSSuppCostReportService hsSuppCostReportService;

    @GetMapping(value = "/getValuesForEOB", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<HashMap<String, List<GetFieldValues>>> fetchFieldValuesForEOB(@RequestParam String trailName,
                                                                                  @RequestParam String startDate,
                                                                                  @RequestParam String endDate) {
        //Calls the service method to get the financial report.
        if (StringUtils.isBlank(trailName) || StringUtils.isBlank(startDate) || StringUtils.isBlank(endDate)) {
            throw new IllegalArgumentException("Trail Name, Start Date and End Date are mandatory fields. Please provide valid values.");
        }
        HashMap<String, List<GetFieldValues>> fieldMap = uspFinancialReportService.fetchIsCompletedValues(trailName, startDate, endDate);
        //Returns the response wrapped in a ResponseEntity.
        return ResponseEntity.ok(fieldMap);
    }

    @GetMapping(value = "/getValuesForHS", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<HashMap<String, List<GetFieldValues>>> fetchFieldValuesForHS(
            @RequestParam String trailName,
            @RequestParam String startDate,
            @RequestParam String endDate) {
        if (StringUtils.isBlank(trailName) || StringUtils.isBlank(startDate) || StringUtils.isBlank(endDate)) {
            throw new IllegalArgumentException("Trail Name, Start Date and End Date are mandatory fields. Please provide valid values.");
        }
        HashMap<String, List<GetFieldValues>> fieldMap = hsSuppCostReportService.fetchIsCompletedValues(trailName, startDate, endDate);
        return ResponseEntity.ok(fieldMap);
    }
}
