package com.uhg.comm.edelivery.reportingservice.model;

import jakarta.persistence.Column;
//import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;
import org.springframework.stereotype.Component;

import java.sql.Date;

@Component
@Data
//@Entity
public class USP3696Data {

    @Id
    @Column(name = "id")
    private Integer id;

    @Column(name = "created_date")
    private Date createdDate;

    @Column(name = "filename")
    private String filename;

    @Column(name = "book_of_business")
    private String bookOfBusiness;

    @Column(name = "total")
    private Integer total;

    @Column(name = "claim_count")
    private Integer claimCount;

    @Column(name = "print_count")
    private Integer printCount;

    @Column(name = "suppress")
    private Integer suppress;

    @Column(name = "mem_supp")
    private Integer memSupp;

    @Column(name = "policy_supp")
    private Integer policySupp;

    @Column(name = "mem_print")
    private Integer memPrint;
}
