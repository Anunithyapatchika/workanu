package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "displSbscrId", "adjdSbscrId", "sbscrDob", "sbscrFstNm", "sbscrLstNm" })
@Generated("jsonschema2pojo")
public class SubscriberInfo {

	@JsonProperty("displSbscrId")
	private String displSbscrId;
	@JsonProperty("adjdSbscrId")
	private String adjdSbscrId;
	@JsonProperty("sbscrDob")
	private String sbscrDob;
	@JsonProperty("sbscrFstNm")
	private String sbscrFstNm;
	@JsonProperty("sbscrLstNm")
	private String sbscrLstNm;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("displSbscrId")
	public String getDisplSbscrId() {
		return displSbscrId;
	}

	@JsonProperty("displSbscrId")
	public void setDisplSbscrId(String displSbscrId) {
		this.displSbscrId = displSbscrId;
	}

	@JsonProperty("adjdSbscrId")
	public String getAdjdSbscrId() {
		return adjdSbscrId;
	}

	@JsonProperty("adjdSbscrId")
	public void setAdjdSbscrId(String adjdSbscrId) {
		this.adjdSbscrId = adjdSbscrId;
	}

	@JsonProperty("sbscrDob")
	public String getSbscrDob() {
		return sbscrDob;
	}

	@JsonProperty("sbscrDob")
	public void setSbscrDob(String sbscrDob) {
		this.sbscrDob = sbscrDob;
	}

	@JsonProperty("sbscrFstNm")
	public String getSbscrFstNm() {
		return sbscrFstNm;
	}

	@JsonProperty("sbscrFstNm")
	public void setSbscrFstNm(String sbscrFstNm) {
		this.sbscrFstNm = sbscrFstNm;
	}

	@JsonProperty("sbscrLstNm")
	public String getSbscrLstNm() {
		return sbscrLstNm;
	}

	@JsonProperty("sbscrLstNm")
	public void setSbscrLstNm(String sbscrLstNm) {
		this.sbscrLstNm = sbscrLstNm;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(SubscriberInfo.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this)))
				.append('[');
		sb.append("displSbscrId");
		sb.append('=');
		sb.append(((this.displSbscrId == null) ? "<null>" : this.displSbscrId));
		sb.append(',');
		sb.append("adjdSbscrId");
		sb.append('=');
		sb.append(((this.adjdSbscrId == null) ? "<null>" : this.adjdSbscrId));
		sb.append(',');
		sb.append("sbscrDob");
		sb.append('=');
		sb.append(((this.sbscrDob == null) ? "<null>" : this.sbscrDob));
		sb.append(',');
		sb.append("sbscrFstNm");
		sb.append('=');
		sb.append(((this.sbscrFstNm == null) ? "<null>" : this.sbscrFstNm));
		sb.append(',');
		sb.append("sbscrLstNm");
		sb.append('=');
		sb.append(((this.sbscrLstNm == null) ? "<null>" : this.sbscrLstNm));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
