package com.uhg.comm.edelivery.reportingservice.model;

import lombok.Data;


@Data
public class Authentication {
    private String type;
}