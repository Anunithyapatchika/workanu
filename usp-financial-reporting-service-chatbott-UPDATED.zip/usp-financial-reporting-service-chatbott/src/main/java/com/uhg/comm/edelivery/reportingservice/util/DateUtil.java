package com.uhg.comm.edelivery.reportingservice.util;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoField;
import java.time.temporal.TemporalAccessor;
import java.util.Calendar;

import static com.uhg.comm.edelivery.reportingservice.constants.Constants.MONTH_YEAR_FORMAT;

public class DateUtil {

    public static LocalDate getLocalDate(String date, String format) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        TemporalAccessor parsed = formatter.parse(date);
        int month = parsed.get(ChronoField.MONTH_OF_YEAR);
        int year = parsed.get(ChronoField.YEAR);
        return LocalDate.of(year, month, 1);
    }


    public static String getLocalDateToString(LocalDate date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(MONTH_YEAR_FORMAT);
        return date.format(formatter);
    }

    public static int getDayOfMonth(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.DAY_OF_MONTH);
    }
}
