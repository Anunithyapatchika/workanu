package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

/**
 * DOC360_DATA
 * <p>
 * Doc360 Data
 * 
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "DOC_CLASS" })
@Generated("jsonschema2pojo")
public class Doc360Data {

	/**
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("DOC_CLASS")
	private String docClass;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	/**
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("DOC_CLASS")
	public String getDocClass() {
		return docClass;
	}

	/**
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("DOC_CLASS")
	public void setDocClass(String docClass) {
		this.docClass = docClass;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	public Doc360Data() {
		this.docClass = " ";
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(Doc360Data.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this)))
				.append('[');
		sb.append("docClass");
		sb.append('=');
		sb.append(((this.docClass == null) ? "<null>" : this.docClass));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

	@Override
	public int hashCode() {
		int result = 1;
		result = ((result * 31) + ((this.docClass == null) ? 0 : this.docClass.hashCode()));
		result = ((result * 31) + ((this.additionalProperties == null) ? 0 : this.additionalProperties.hashCode()));
		return result;
	}

	@Override
	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if ((other instanceof Doc360Data) == false) {
			return false;
		}
		Doc360Data rhs = ((Doc360Data) other);
		return (((this.docClass == rhs.docClass) || ((this.docClass != null) && this.docClass.equals(rhs.docClass)))
				&& ((this.additionalProperties == rhs.additionalProperties) || ((this.additionalProperties != null)
						&& this.additionalProperties.equals(rhs.additionalProperties))));
	}

}
