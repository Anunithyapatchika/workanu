package com.uhg.comm.edelivery.reportingservice.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
@RefreshScope
@Scope
@ConfigurationProperties(prefix = "edelivery.configproperties")
public class ConfigWebserviceProperties {
	private Map<String, Map<String, String>> properties;

	public Map<String, Map<String, String>> getProperties() {
		return properties;
	}

	public void setProperties(Map<String, Map<String, String>> properties) {
		this.properties = properties;
	}

}
