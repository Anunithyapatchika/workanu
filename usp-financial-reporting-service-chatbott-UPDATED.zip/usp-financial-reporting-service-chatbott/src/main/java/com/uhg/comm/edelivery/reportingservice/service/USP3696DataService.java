package com.uhg.comm.edelivery.reportingservice.service;

import com.uhg.comm.edelivery.processLog.Processlog;
import com.uhg.comm.edelivery.reportingservice.model.HSSuppCostReport;
import com.uhg.comm.edelivery.reportingservice.model.TrailAndBobDetails;
import com.uhg.comm.edelivery.reportingservice.model.USP3696Data;
import com.uhg.comm.edelivery.reportingservice.nesslogger.NessLoggerService;
import com.uhg.comm.edelivery.reportingservice.repository.HSSuppCostReportRepository;
import com.uhg.comm.edelivery.reportingservice.repository.TrailAndBobRepository;
import com.uhg.comm.edelivery.reportingservice.repository.USP3696DataRepository;
import com.uhg.comm.edelivery.reportingservice.repository.USPFinancialReportRepository;
import com.uhg.comm.edelivery.reportingservice.util.CalculationUtils;
import com.uhg.comm.edelivery.reportingservice.util.DateUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static com.uhg.comm.edelivery.reportingservice.constants.Constants.*;

@Service
public class USP3696DataService {

    private static final Logger LOGGER = LoggerFactory.getLogger(USP3696DataService.class);

    @Value("${edelivery.configproperties.properties.TxStatusUpdate.DayUpdateTxStatus}")
    private int DayUpdateTxStatus;

    @Value("${edelivery.configproperties.properties.USP3696.DateFilter}")
    private String dateFilter;

    @Value("${edelivery.configproperties.properties.USP3696.minusDays}")
    private Long minusDays;

    @Autowired
    private USP3696DataRepository usp3696DataRepo;

    @Autowired
    private HSSuppCostReportRepository hsSuppCostReportRepo;

    @Autowired
    private NessLoggerService nessLoggerService;

    @Autowired
    private SendEmailService sendEmailService;

    @Autowired
    private USPFinancialReportRepository uspFinancialReportRepository;

    @Autowired
    private TrailAndBobRepository trailAndBobRepo;

    public void process(){
        Processlog processlog = new Processlog();
        try {
            LOGGER.info("Fetching USP3696 Data");
            processlog.setApiName("USP3696_scheduler");
            processlog.setTrailNumber(PT3696_USP);
            processlog.setReqEntryTimestamp(new Timestamp(System.currentTimeMillis()).toString());
            processlog.setServiceName(USP_FIN_REPORTING_SERVICE);

            List<USP3696Data> usp3696DataList = usp3696DataRepo.getUSP3696Data(dateFilter, processlog);
            LOGGER.info("USP3696 Data fetched :: {}", usp3696DataList);
            if (!CollectionUtils.isEmpty(usp3696DataList)&& !CollectionUtils.isEmpty(usp3696DataList.stream().filter(usp3696Data -> StringUtils.isNotBlank(usp3696Data.getBookOfBusiness())).collect(Collectors.toList()))) {
                processUSP3696Data(usp3696DataList,processlog);
                LOGGER.info("Processed USP3696");
                processlog.setStatus("SUCCESS");
            } else {
                LOGGER.info("No USP3696 Data found in the DataBase");
                processlog.setErrorMessage("No USP3696 Data found in the DataBase");
                processlog.setAdditionalProperty("fetchedDate", Date.valueOf(new Date(System.currentTimeMillis()).toLocalDate().minusDays(minusDays)).toString());
                processlog.setStatus("NO_DATA_FOUND");
            }
            processlog.setReqFinishTimestamp(new Date(System.currentTimeMillis()).toString());
            nessLoggerService.publishNesslogsToSplunk(processlog.toString());
            sendEmailService.sendEmail(processlog);
            updateNewBoB(usp3696DataList, processlog);
            markTxComlpletedforlPrevMonth(processlog);
        } catch (Exception e) {
            LOGGER.error("Exception occurred while processing scheduler :{}", e.getLocalizedMessage());
            processlog.setStatus("FAILED");
            if (StringUtils.isBlank(processlog.getErrorMessage())) {
                processlog.setErrorMessage(e.getLocalizedMessage());
            }
            processlog.setAdditionalProperty("fetchedDate", Date.valueOf(new Date(System.currentTimeMillis()).toLocalDate().minusDays(minusDays)).toString());
            processlog.setReqFinishTimestamp(new Date(System.currentTimeMillis()).toString());
            nessLoggerService.publishNesslogsToSplunk(processlog.toString());
            sendEmailService.sendEmail(processlog);
        }
    }

    public void processUSP3696Data(List<USP3696Data> usp3696DataList, Processlog processlog) {
        try {
            List<USP3696Data> usp3696DataArrayList = new ArrayList<>();
            LOGGER.info("USP3696 Data Consolidated :: {}", usp3696DataList);
            for (USP3696Data usp3696Data : usp3696DataList) {
                String trailNumber = PT3696_USP;
                if(StringUtils.isBlank(usp3696Data.getBookOfBusiness()) || usp3696Data.getCreatedDate() == null) {
                    LOGGER.error("Book of Business is empty of date is null for USP3696Data :: {}", usp3696Data);
                    continue;
                }
                LocalDate createdDate = usp3696Data.getCreatedDate().toLocalDate();
                String monthYearStr = DateUtil.getLocalDateToString(createdDate);
                LocalDate monthYear = DateUtil.getLocalDate(monthYearStr,MONTH_YEAR_FORMAT);
                String bob = usp3696Data.getBookOfBusiness().replace("\"","");
                LOGGER.info("Trail Number :: {}, Month Year :: {}, BOB :: {}", trailNumber, monthYear, bob);
                Optional<HSSuppCostReport> optional = hsSuppCostReportRepo.findByTrailNameBobAndMonthAndNotCompleted(trailNumber, bob, monthYearStr);
                int isLastDayOfMonth = isLastDateOfMonth(createdDate);
                if (optional.isPresent()) {
                    HSSuppCostReport hsSuppCostReport1 = optional.get();
                    hsSuppCostReport1.setModifiedBy(SERVICE_NAME);
                    hsSuppCostReport1.setStatementPrinted(hsSuppCostReport1.getStatementPrinted() + usp3696Data.getPrintCount());
                    hsSuppCostReport1.setMemberElectionHSSupp(hsSuppCostReport1.getMemberElectionHSSupp() + usp3696Data.getMemSupp());
                    hsSuppCostReport1.setPolicySettingHSSupp(hsSuppCostReport1.getPolicySettingHSSupp() + usp3696Data.getPolicySupp());
                    hsSuppCostReport1.setTotalStmtGenerated(hsSuppCostReport1.getTotalStmtGenerated() + usp3696Data.getTotal());
                    hsSuppCostReport1.setTotalStmtSuppressed(hsSuppCostReport1.getTotalStmtSuppressed() + usp3696Data.getSuppress());
                    hsSuppCostReport1.setMemPrint(hsSuppCostReport1.getMemPrint() + usp3696Data.getMemPrint());
                    hsSuppCostReport1.setTotalClaims(hsSuppCostReport1.getTotalClaims() + usp3696Data.getClaimCount());
                    double suppressPercent = 0;
                    try{
                        suppressPercent = (hsSuppCostReport1.getTotalStmtSuppressed() / hsSuppCostReport1.getTotalStmtGenerated()) * 100;
                        suppressPercent = CalculationUtils.roundOf(suppressPercent);
                    } catch (Exception e) {
                        LOGGER.error("Error while calculating suppress percent :: {}",e.getMessage());
                    }
                    hsSuppCostReport1.setHsSuppressPercent(suppressPercent);
                    if (isLastDayOfMonth == 1) {
                        hsSuppCostReport1.setIsTxCompleted(isLastDayOfMonth);
                    }
                    if (hsSuppCostReport1.getPrintingCost() != 0 || hsSuppCostReport1.getPostageCost() != 0 || isLastDayOfMonth == 1){
                        calculateFinancialData(hsSuppCostReport1);
                    }
                    hsSuppCostReportRepo.save(hsSuppCostReport1);
//                    nessLoggerService.publishNesslogsToSplunk(hsSuppCostReport1.toString());
                } else {
                    HSSuppCostReport hsSuppCostReport = new HSSuppCostReport();
                    hsSuppCostReport.setTrailName(trailNumber);
                    hsSuppCostReport.setMonthYear(monthYear);
                    hsSuppCostReport.setMonth(monthYearStr);
                    hsSuppCostReport.setBob(bob);
                    hsSuppCostReport.setCreatedBy(SERVICE_NAME);
                    hsSuppCostReport.setStatementPrinted(usp3696Data.getPrintCount());
                    hsSuppCostReport.setMemberElectionHSSupp(usp3696Data.getMemSupp());
                    hsSuppCostReport.setPolicySettingHSSupp(usp3696Data.getPolicySupp());
                    hsSuppCostReport.setTotalStmtGenerated(usp3696Data.getTotal());
                    hsSuppCostReport.setTotalStmtSuppressed(usp3696Data.getSuppress());
                    hsSuppCostReport.setMemPrint(usp3696Data.getMemPrint());
                    hsSuppCostReport.setTotalClaims(usp3696Data.getClaimCount());
                    double suppressPercent = 0;
                    try{
                        suppressPercent = (hsSuppCostReport.getTotalStmtSuppressed() / hsSuppCostReport.getTotalStmtGenerated()) * 100;
                        suppressPercent = CalculationUtils.roundOf(suppressPercent);
                    } catch (Exception e) {
                        LOGGER.error("Error while calculating suppress percent :: {}",e.getMessage());
                    }
                    hsSuppCostReport.setHsSuppressPercent(suppressPercent);
                    if (isLastDayOfMonth == 1){
                        hsSuppCostReport.setIsTxCompleted(isLastDayOfMonth);
                    }
                    hsSuppCostReportRepo.save(hsSuppCostReport);
//                    nessLoggerService.publishNesslogsToSplunk(hsSuppCostReport.toString());
                }
                usp3696DataArrayList.add(usp3696Data);
//                    JSONObject jsonObject = new JSONObject();
//                    jsonObject.put("data", uspFinancialReport);
                processlog.setAdditionalProperty("record", usp3696Data);
                processlog.setStatus("RECORD_SUCCESS");
                processlog.setReqFinishTimestamp(new Date(System.currentTimeMillis()).toString());
                nessLoggerService.publishNesslogsToSplunk(processlog.toString());
            }
            processlog.setAdditionalProperty("list", usp3696DataArrayList);

        } catch (Exception e) {
            LOGGER.error("Exception occurred while processing scheduler ::",e);
            if (StringUtils.isBlank(processlog.getErrorMessage())) {
                processlog.setErrorMessage("Error while processing USP3696 Transaction Data");
            }
            throw e;
        }
    }

    private void calculateFinancialData(HSSuppCostReport hsSuppCostReport) {
        LOGGER.info("### Unexpected scenario:: Intake data already present before Transaction data update completed. Calculating Financial Data");
        double totalPrintPostageCost = CalculationUtils.roundOf(hsSuppCostReport.getPostageCost() + hsSuppCostReport.getPrintingCost());
        double costPerPrintedStmt = CalculationUtils.roundOf(totalPrintPostageCost / hsSuppCostReport.getStatementPrinted());
        double sheetsPerPrintedStmt = CalculationUtils.roundOf(hsSuppCostReport.getTotalSheets() / hsSuppCostReport.getStatementPrinted());
        double hsSuppPercent = (hsSuppCostReport.getTotalStmtSuppressed() / hsSuppCostReport.getTotalStmtGenerated()) * 100;
        hsSuppPercent = CalculationUtils.roundOf(hsSuppPercent);

        hsSuppCostReport.setTotalPrintPostageCost(totalPrintPostageCost);
        hsSuppCostReport.setCostPerStmt(costPerPrintedStmt);
        hsSuppCostReport.setSheetsPerPrintedStmt(sheetsPerPrintedStmt);
        hsSuppCostReport.setHsSuppressPercent(hsSuppPercent);
        if ( hsSuppCostReport.getPrintingCost() != 0 || hsSuppCostReport.getPostageCost() != 0 ){
            hsSuppCostReport.setIsCompleted(1);
        }

        LOGGER.info("### Financial Data Calculated :: {}", hsSuppCostReport);
    }

    private int isLastDateOfMonth(LocalDate createdDate){
        if (createdDate.getDayOfMonth() == createdDate.lengthOfMonth()) {
            LOGGER.info("Last day of the month");
            return 1;
        }
        return 0;
    }

    public void markTxComlpletedforlPrevMonth(Processlog processlog){
        try {
            Date currentDate = new Date(System.currentTimeMillis());
            LOGGER.info("checking for last month transaction completion :: {}, DayUpdateTxStatus :: {}", currentDate, DayUpdateTxStatus);
            if (DateUtil.getDayOfMonth(currentDate) == DayUpdateTxStatus) {
                LocalDate datee = currentDate.toLocalDate().minusMonths(1).withDayOfMonth(1);
                String monthYearStr = DateUtil.getLocalDateToString(datee);
                LOGGER.info("Checking for last month transaction completion for trail :: {} , monthYearStr :: {}", PT3696_USP, monthYearStr);
                List<HSSuppCostReport> hsSuppCostReportList = hsSuppCostReportRepo.findByTrailNameAndMonthAndNotTxCompleted(PT3696_USP, 0, monthYearStr);
                LOGGER.info("Transaction completion for last month :: {}", hsSuppCostReportList);
                for (HSSuppCostReport hsSuppCostReport : hsSuppCostReportList) {
                    hsSuppCostReport.setIsTxCompleted(1);
                    hsSuppCostReportRepo.save(hsSuppCostReport);
                    LOGGER.info("Transaction completed for last month :: {}", hsSuppCostReport);
//                    nessLoggerService.publishNesslogsToSplunk(hsSuppCostReport.toString());
                }
            } else {
                LOGGER.info("Current date is not equal to configured date");
            }
        } catch (Exception e) {
            LOGGER.error("Error while marking transaction completed for last month :: {}", e.getMessage());
            processlog.setErrorMessage("Error while marking transaction completed for last month");
            throw e;
        }
    }

    public void updateNewBoB(List<USP3696Data> usp3696DataList, Processlog processlog){
        try {
            Set<TrailAndBobDetails> trailAndBobDetailsList = trailAndBobRepo.findByTrailNumber(PT3696_USP);
            if (!CollectionUtils.isEmpty(trailAndBobDetailsList) && !CollectionUtils.isEmpty(usp3696DataList)) {

                Map<String, List<USP3696Data>> groupedByBob = usp3696DataList.stream().filter(usp3696Data -> StringUtils.isNotBlank((usp3696Data.getBookOfBusiness())))
                        .collect(Collectors.groupingBy(USP3696Data::getBookOfBusiness));

                List<String> bobNames = trailAndBobDetailsList.stream().map(TrailAndBobDetails::getBobName).collect(Collectors.toList());

                List<String> newBobList = groupedByBob.keySet().stream().filter(bob -> !bobNames.contains(bob)).collect(Collectors.toList());
                if (!CollectionUtils.isEmpty(newBobList)) {
                    newBobList.forEach(newBob -> {
                        TrailAndBobDetails trailAndBobDetails = new TrailAndBobDetails();
                        trailAndBobDetails.setTrailNumber(PT3696_USP);
                        trailAndBobDetails.setBobName(newBob);
                        trailAndBobDetails.setIsActive(1);
                        trailAndBobRepo.save(trailAndBobDetails);
                        processlog.setStatus("NEW BOB DETECTED");
                        processlog.setAdditionalProperty("newBob", newBob);
                        processlog.setAdditionalProperty("newBobDate", groupedByBob.get(newBob).stream().map(USP3696Data::getCreatedDate).min(Date::compareTo).get());
                        sendEmailService.sendEmail(processlog);
                    });
                }
            }
        }catch (Exception e){
            LOGGER.error("Error while updating new BOB for USP3696 :: ",e);
            processlog.setErrorMessage("Error while updating new BOB for USP3696");
            throw e;
        }
    }


}
