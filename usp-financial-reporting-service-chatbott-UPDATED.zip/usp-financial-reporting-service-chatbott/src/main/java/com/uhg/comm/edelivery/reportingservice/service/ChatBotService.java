package com.uhg.comm.edelivery.reportingservice.service;

public interface ChatBotService {
    String readInputJsonFile();
}
