package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import lombok.Data;

@Data
public class MemberPref {

	private String statementNum;

	private String pref;

	private String emailId;

	private String memberChoice;

	public MemberPref(String statementNum, String deliveryPref, String memberEmailId, String memberChoice) {
		this.statementNum = statementNum;
		this.pref = deliveryPref;
		this.emailId = memberEmailId;
		this.memberChoice = memberChoice;
	}
}
