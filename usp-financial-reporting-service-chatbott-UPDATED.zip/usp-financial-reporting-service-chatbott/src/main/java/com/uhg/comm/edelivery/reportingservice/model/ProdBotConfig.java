package com.uhg.comm.edelivery.reportingservice.model;

import lombok.Data;

import java.util.List;

@Data
public class ProdBotConfig {
    private double temperature;
    private double top_p;
    private int frequency_penalty;
    private int presence_penalty;
    private int max_tokens;
    private List<DataSource> data_sources;
    private List<Message> messages;

}