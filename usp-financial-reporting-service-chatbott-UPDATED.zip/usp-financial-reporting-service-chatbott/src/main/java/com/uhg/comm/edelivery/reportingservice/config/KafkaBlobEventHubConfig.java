package com.uhg.comm.edelivery.reportingservice.config;

import com.azure.security.keyvault.secrets.SecretClient;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

import static com.uhg.comm.edelivery.reportingservice.constants.AzureVaultKey.KAFKA_JAAS_CONFIG_EH2;

@Configuration
@Component
@Lazy
public class KafkaBlobEventHubConfig<T> {

    @Value("${blobconsumer.config.bootstrapconfig}")
    private String bootstrapconfig;

    @Value("${blobconsumer.config.groupid}")
    private String groupid;

    private final SecretClient secretClient;

    public KafkaBlobEventHubConfig(SecretClient secretClient) {
        this.secretClient = secretClient;
    }

    @Bean
    public ConsumerFactory<String, Object> consumerFactoryeventgrid() {
        Map<String, Object> propconfig = new HashMap<>();

        propconfig.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapconfig);
        propconfig.put(ConsumerConfig.GROUP_ID_CONFIG, groupid);
        propconfig.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        propconfig.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        propconfig.put("security.protocol", "SASL_SSL");
        propconfig.put("sasl.mechanism", "PLAIN");
        propconfig.put("sasl.jaas.config",secretClient.getSecret(KAFKA_JAAS_CONFIG_EH2).getValue() );
        propconfig.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        propconfig.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
        propconfig.put(ConsumerConfig.ALLOW_AUTO_CREATE_TOPICS_CONFIG,false);
        return getKafkaConsumerFactory(propconfig);
    }

    public DefaultKafkaConsumerFactory<String, Object> getKafkaConsumerFactory(Map<String, Object> propconfig) {
        return new DefaultKafkaConsumerFactory<>(propconfig);
    }

    @Bean(name = "kafkaListenerContainerFactoryEventGrid")
    public ConcurrentKafkaListenerContainerFactory<String, Object> kafkaListenerContainerFactoryEventGrid() {
        ConcurrentKafkaListenerContainerFactory<String, Object> factory = getContainerFactory();
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL_IMMEDIATE);
        factory.setConsumerFactory(consumerFactoryeventgrid());
        return factory;
    }

    public ConcurrentKafkaListenerContainerFactory<String, Object> getContainerFactory() {
        return new ConcurrentKafkaListenerContainerFactory<>();
    }

}