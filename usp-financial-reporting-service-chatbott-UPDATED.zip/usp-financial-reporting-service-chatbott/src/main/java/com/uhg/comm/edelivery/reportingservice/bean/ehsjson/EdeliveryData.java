package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

/**
 * EDELIVERY_DATA
 * <p>
 * eDelivery Data
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "PRINT_FLAG", "EMAIL" })
@Generated("jsonschema2pojo")
public class EdeliveryData {

	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("PRINT_FLAG")
	private String printFlag;
	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("EMAIL")
	private String email;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("PRINT_FLAG")
	public String getPrintFlag() {
		return printFlag;
	}

	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("PRINT_FLAG")
	public void setPrintFlag(String printFlag) {
		this.printFlag = printFlag;
	}

	public EdeliveryData() {
		this.printFlag = " ";
		this.email = " ";
	}

	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("EMAIL")
	public String getEmail() {
		return email;
	}

	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("EMAIL")
	public void setEmail(String email) {
		this.email = email;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(EdeliveryData.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this)))
				.append('[');
		sb.append("printFlag");
		sb.append('=');
		sb.append(((this.printFlag == null) ? "<null>" : this.printFlag));
		sb.append(',');
		sb.append("email");
		sb.append('=');
		sb.append(((this.email == null) ? "<null>" : this.email));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

	@Override
	public int hashCode() {
		int result = 1;
		result = ((result * 31) + ((this.additionalProperties == null) ? 0 : this.additionalProperties.hashCode()));
		result = ((result * 31) + ((this.email == null) ? 0 : this.email.hashCode()));
		result = ((result * 31) + ((this.printFlag == null) ? 0 : this.printFlag.hashCode()));
		return result;
	}

	@Override
	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if ((other instanceof EdeliveryData) == false) {
			return false;
		}
		EdeliveryData rhs = ((EdeliveryData) other);
		return ((((this.additionalProperties == rhs.additionalProperties)
				|| ((this.additionalProperties != null) && this.additionalProperties.equals(rhs.additionalProperties)))
				&& ((this.email == rhs.email) || ((this.email != null) && this.email.equals(rhs.email))))
				&& ((this.printFlag == rhs.printFlag)
						|| ((this.printFlag != null) && this.printFlag.equals(rhs.printFlag))));
	}

}
