package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "documentSetId", "documentSetInfo" })
@Generated("jsonschema2pojo")
public class DocumentInformation {

	@JsonProperty("documentSetId")
	private String documentSetId;
	@JsonProperty("documentSetInfo")
	private List<DocumentSetInfo> documentSetInfo = null;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("documentSetId")
	public String getDocumentSetId() {
		return documentSetId;
	}

	@JsonProperty("documentSetId")
	public void setDocumentSetId(String documentSetId) {
		this.documentSetId = documentSetId;
	}

	@JsonProperty("documentSetInfo")
	public List<DocumentSetInfo> getDocumentSetInfo() {
		return documentSetInfo;
	}

	@JsonProperty("documentSetInfo")
	public void setDocumentSetInfo(List<DocumentSetInfo> documentSetInfo) {
		this.documentSetInfo = documentSetInfo;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(DocumentInformation.class.getName()).append('@')
				.append(Integer.toHexString(System.identityHashCode(this))).append('[');
		sb.append("documentSetId");
		sb.append('=');
		sb.append(((this.documentSetId == null) ? "<null>" : this.documentSetId));
		sb.append(',');
		sb.append("documentSetInfo");
		sb.append('=');
		sb.append(((this.documentSetInfo == null) ? "<null>" : this.documentSetInfo));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
