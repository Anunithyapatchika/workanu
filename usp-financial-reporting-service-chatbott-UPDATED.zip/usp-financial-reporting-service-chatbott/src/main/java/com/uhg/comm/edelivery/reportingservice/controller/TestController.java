package com.uhg.comm.edelivery.reportingservice.controller;

import com.uhg.comm.edelivery.reportingservice.auth.OauthTokenUtil;
import com.uhg.comm.edelivery.reportingservice.bean.*;
import com.uhg.comm.edelivery.reportingservice.service.PzipUtilityService;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;


@RestController
public class TestController {

    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(TestController.class);

    @Autowired
    private OauthTokenUtil oauthTokenUtil;

    @Autowired
    private PzipUtilityService pzipUtilityService;

    @GetMapping("/getName")
    public String getName() {
        return "Hello World";
    }

    @PostMapping(value = "/stsapi")
    @ResponseBody
    public ApiResponse callOndemandApi(@RequestParam String jobId,
                                                   @RequestBody OnDemandApiRequest onDemandBody,
                                                   @RequestParam String supressIndictor,
                                                   @RequestParam String trailType,
                                                   @RequestParam String tnoId) throws IOException {
        return pzipUtilityService.callOnDemandApi(onDemandBody, jobId, supressIndictor, trailType, tnoId);
    }

    @PostMapping("/batchconsolidationapi")
    public ApiResponse callBatchConsolidationApi(@RequestParam String jobId,
                                                             @RequestBody BatchFile batchConsolidationBody,
                                                             @RequestParam String trailType,
                                                             @RequestParam String tnoId){
        return pzipUtilityService.callBatchConsolidationApi(jobId, batchConsolidationBody, trailType, tnoId);
    }

    @PostMapping("/batchdeliveryapi")
    public ApiResponse callBatchDeliveryApi(@RequestParam String jobId,
                                                        @RequestParam String inputFileName,
                                                        @RequestParam String trailType,
                                                        @RequestBody BatchDeliveryRequest batchDeliveryBody) {
        return pzipUtilityService.callBatchDeliveryApi(jobId,trailType,inputFileName,batchDeliveryBody);

    }

    @GetMapping("/getFileslist")
    public List<String> fetcFileList(@RequestParam String inputFileName) {
        if (inputFileName.matches("^[a-zA-Z0-9._/-]+$")) {
            LOGGER.info("Received request to fetch file list for inputFileName: {}", inputFileName);
        }
        List<String> listOfFilesFromBlob = pzipUtilityService.getListOfFilesFromBlob(inputFileName);
        if(!CollectionUtils.isEmpty(listOfFilesFromBlob)) {
            LOGGER.info("Files found in blob storage : {}", listOfFilesFromBlob.size());
            return listOfFilesFromBlob;
        } else {
               LOGGER.info("No files found in blob storage");return null;
        }
    }
}