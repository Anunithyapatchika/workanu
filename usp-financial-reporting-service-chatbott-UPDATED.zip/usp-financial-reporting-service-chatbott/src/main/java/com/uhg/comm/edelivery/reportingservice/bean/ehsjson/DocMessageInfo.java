package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "docMsgId", "docMsgTxt", "docMsgCat", "docMsgDispNewPageInd", "docMsgDispNewSheetInd" })
@Generated("jsonschema2pojo")
public class DocMessageInfo {

	@JsonProperty("docMsgId")
	private String docMsgId;
	@JsonProperty("docMsgTxt")
	private String docMsgTxt;
	@JsonProperty("docMsgCat")
	private String docMsgCat;
	@JsonProperty("docMsgDispNewPageInd")
	private String docMsgDispNewPageInd;
	@JsonProperty("docMsgDispNewSheetInd")
	private String docMsgDispNewSheetInd;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("docMsgId")
	public String getDocMsgId() {
		return docMsgId;
	}

	@JsonProperty("docMsgId")
	public void setDocMsgId(String docMsgId) {
		this.docMsgId = docMsgId;
	}

	@JsonProperty("docMsgTxt")
	public String getDocMsgTxt() {
		return docMsgTxt;
	}

	@JsonProperty("docMsgTxt")
	public void setDocMsgTxt(String docMsgTxt) {
		this.docMsgTxt = docMsgTxt;
	}

	@JsonProperty("docMsgCat")
	public String getDocMsgCat() {
		return docMsgCat;
	}

	@JsonProperty("docMsgCat")
	public void setDocMsgCat(String docMsgCat) {
		this.docMsgCat = docMsgCat;
	}

	@JsonProperty("docMsgDispNewPageInd")
	public String getDocMsgDispNewPageInd() {
		return docMsgDispNewPageInd;
	}

	@JsonProperty("docMsgDispNewPageInd")
	public void setDocMsgDispNewPageInd(String docMsgDispNewPageInd) {
		this.docMsgDispNewPageInd = docMsgDispNewPageInd;
	}

	@JsonProperty("docMsgDispNewSheetInd")
	public String getDocMsgDispNewSheetInd() {
		return docMsgDispNewSheetInd;
	}

	@JsonProperty("docMsgDispNewSheetInd")
	public void setDocMsgDispNewSheetInd(String docMsgDispNewSheetInd) {
		this.docMsgDispNewSheetInd = docMsgDispNewSheetInd;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(DocMessageInfo.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this)))
				.append('[');
		sb.append("docMsgId");
		sb.append('=');
		sb.append(((this.docMsgId == null) ? "<null>" : this.docMsgId));
		sb.append(',');
		sb.append("docMsgTxt");
		sb.append('=');
		sb.append(((this.docMsgTxt == null) ? "<null>" : this.docMsgTxt));
		sb.append(',');
		sb.append("docMsgCat");
		sb.append('=');
		sb.append(((this.docMsgCat == null) ? "<null>" : this.docMsgCat));
		sb.append(',');
		sb.append("docMsgDispNewPageInd");
		sb.append('=');
		sb.append(((this.docMsgDispNewPageInd == null) ? "<null>" : this.docMsgDispNewPageInd));
		sb.append(',');
		sb.append("docMsgDispNewSheetInd");
		sb.append('=');
		sb.append(((this.docMsgDispNewSheetInd == null) ? "<null>" : this.docMsgDispNewSheetInd));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
