package com.uhg.comm.edelivery.reportingservice.dto;

import lombok.Data;

import java.util.List;
@Data
public class EHSSuppressionChgResponse {
    private String date;
    private String trailName;
    private List<EHSSuppressionChgResponseItem> items;
}
