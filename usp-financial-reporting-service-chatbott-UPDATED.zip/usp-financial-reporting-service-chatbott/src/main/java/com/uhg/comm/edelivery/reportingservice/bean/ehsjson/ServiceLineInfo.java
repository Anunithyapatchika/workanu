package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "seqNbr", "chargeAmt", "savedAmt", "allowedAmt", "otherInsMedicareAmt", "otherInsPaidAmt",
		"medicarePaidAmt", "planPaysAmt", "deductibleAmt", "copayAmt", "coInsAmt", "notCoveredAmt", "yourAmtOwed",
		"amtPaid1", "amtPaid2", "amtPaid3", "serviceDesc", "slRemarkCdInfo" })
@Generated("jsonschema2pojo")
public class ServiceLineInfo {

	@JsonProperty("seqNbr")
	private String seqNbr;
	@JsonProperty("chargeAmt")
	private String chargeAmt;
	@JsonProperty("savedAmt")
	private String savedAmt;
	@JsonProperty("allowedAmt")
	private String allowedAmt;
	@JsonProperty("otherInsMedicareAmt")
	private String otherInsMedicareAmt;
	@JsonProperty("otherInsPaidAmt")
	private String otherInsPaidAmt;
	@JsonProperty("medicarePaidAmt")
	private String medicarePaidAmt;
	@JsonProperty("planPaysAmt")
	private String planPaysAmt;
	@JsonProperty("deductibleAmt")
	private String deductibleAmt;
	@JsonProperty("copayAmt")
	private String copayAmt;
	@JsonProperty("coInsAmt")
	private String coInsAmt;
	@JsonProperty("notCoveredAmt")
	private String notCoveredAmt;
	@JsonProperty("yourAmtOwed")
	private String yourAmtOwed;
	@JsonProperty("amtPaid1")
	private String amtPaid1;
	@JsonProperty("amtPaid2")
	private String amtPaid2;
	@JsonProperty("amtPaid3")
	private String amtPaid3;
	@JsonProperty("serviceDesc")
	private String serviceDesc;
	@JsonProperty("slRemarkCdInfo")
	private SlRemarkCdInfo slRemarkCdInfo;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("seqNbr")
	public String getSeqNbr() {
		return seqNbr;
	}

	@JsonProperty("seqNbr")
	public void setSeqNbr(String seqNbr) {
		this.seqNbr = seqNbr;
	}

	@JsonProperty("chargeAmt")
	public String getChargeAmt() {
		return chargeAmt;
	}

	@JsonProperty("chargeAmt")
	public void setChargeAmt(String chargeAmt) {
		this.chargeAmt = chargeAmt;
	}

	@JsonProperty("savedAmt")
	public String getSavedAmt() {
		return savedAmt;
	}

	@JsonProperty("savedAmt")
	public void setSavedAmt(String savedAmt) {
		this.savedAmt = savedAmt;
	}

	@JsonProperty("allowedAmt")
	public String getAllowedAmt() {
		return allowedAmt;
	}

	@JsonProperty("allowedAmt")
	public void setAllowedAmt(String allowedAmt) {
		this.allowedAmt = allowedAmt;
	}

	@JsonProperty("otherInsMedicareAmt")
	public String getOtherInsMedicareAmt() {
		return otherInsMedicareAmt;
	}

	@JsonProperty("otherInsMedicareAmt")
	public void setOtherInsMedicareAmt(String otherInsMedicareAmt) {
		this.otherInsMedicareAmt = otherInsMedicareAmt;
	}

	@JsonProperty("otherInsPaidAmt")
	public String getOtherInsPaidAmt() {
		return otherInsPaidAmt;
	}

	@JsonProperty("otherInsPaidAmt")
	public void setOtherInsPaidAmt(String otherInsPaidAmt) {
		this.otherInsPaidAmt = otherInsPaidAmt;
	}

	@JsonProperty("medicarePaidAmt")
	public String getMedicarePaidAmt() {
		return medicarePaidAmt;
	}

	@JsonProperty("medicarePaidAmt")
	public void setMedicarePaidAmt(String medicarePaidAmt) {
		this.medicarePaidAmt = medicarePaidAmt;
	}

	@JsonProperty("planPaysAmt")
	public String getPlanPaysAmt() {
		return planPaysAmt;
	}

	@JsonProperty("planPaysAmt")
	public void setPlanPaysAmt(String planPaysAmt) {
		this.planPaysAmt = planPaysAmt;
	}

	@JsonProperty("deductibleAmt")
	public String getDeductibleAmt() {
		return deductibleAmt;
	}

	@JsonProperty("deductibleAmt")
	public void setDeductibleAmt(String deductibleAmt) {
		this.deductibleAmt = deductibleAmt;
	}

	@JsonProperty("copayAmt")
	public String getCopayAmt() {
		return copayAmt;
	}

	@JsonProperty("copayAmt")
	public void setCopayAmt(String copayAmt) {
		this.copayAmt = copayAmt;
	}

	@JsonProperty("coInsAmt")
	public String getCoInsAmt() {
		return coInsAmt;
	}

	@JsonProperty("coInsAmt")
	public void setCoInsAmt(String coInsAmt) {
		this.coInsAmt = coInsAmt;
	}

	@JsonProperty("notCoveredAmt")
	public String getNotCoveredAmt() {
		return notCoveredAmt;
	}

	@JsonProperty("notCoveredAmt")
	public void setNotCoveredAmt(String notCoveredAmt) {
		this.notCoveredAmt = notCoveredAmt;
	}

	@JsonProperty("yourAmtOwed")
	public String getYourAmtOwed() {
		return yourAmtOwed;
	}

	@JsonProperty("yourAmtOwed")
	public void setYourAmtOwed(String yourAmtOwed) {
		this.yourAmtOwed = yourAmtOwed;
	}

	@JsonProperty("amtPaid1")
	public String getAmtPaid1() {
		return amtPaid1;
	}

	@JsonProperty("amtPaid1")
	public void setAmtPaid1(String amtPaid1) {
		this.amtPaid1 = amtPaid1;
	}

	@JsonProperty("amtPaid2")
	public String getAmtPaid2() {
		return amtPaid2;
	}

	@JsonProperty("amtPaid2")
	public void setAmtPaid2(String amtPaid2) {
		this.amtPaid2 = amtPaid2;
	}

	@JsonProperty("amtPaid3")
	public String getAmtPaid3() {
		return amtPaid3;
	}

	@JsonProperty("amtPaid3")
	public void setAmtPaid3(String amtPaid3) {
		this.amtPaid3 = amtPaid3;
	}

	@JsonProperty("serviceDesc")
	public String getServiceDesc() {
		return serviceDesc;
	}

	@JsonProperty("serviceDesc")
	public void setServiceDesc(String serviceDesc) {
		this.serviceDesc = serviceDesc;
	}

	@JsonProperty("slRemarkCdInfo")
	public SlRemarkCdInfo getSlRemarkCdInfo() {
		return slRemarkCdInfo;
	}

	@JsonProperty("slRemarkCdInfo")
	public void setSlRemarkCdInfo(SlRemarkCdInfo slRemarkCdInfo) {
		this.slRemarkCdInfo = slRemarkCdInfo;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(ServiceLineInfo.class.getName()).append('@')
				.append(Integer.toHexString(System.identityHashCode(this))).append('[');
		sb.append("seqNbr");
		sb.append('=');
		sb.append(((this.seqNbr == null) ? "<null>" : this.seqNbr));
		sb.append(',');
		sb.append("chargeAmt");
		sb.append('=');
		sb.append(((this.chargeAmt == null) ? "<null>" : this.chargeAmt));
		sb.append(',');
		sb.append("savedAmt");
		sb.append('=');
		sb.append(((this.savedAmt == null) ? "<null>" : this.savedAmt));
		sb.append(',');
		sb.append("allowedAmt");
		sb.append('=');
		sb.append(((this.allowedAmt == null) ? "<null>" : this.allowedAmt));
		sb.append(',');
		sb.append("otherInsMedicareAmt");
		sb.append('=');
		sb.append(((this.otherInsMedicareAmt == null) ? "<null>" : this.otherInsMedicareAmt));
		sb.append(',');
		sb.append("otherInsPaidAmt");
		sb.append('=');
		sb.append(((this.otherInsPaidAmt == null) ? "<null>" : this.otherInsPaidAmt));
		sb.append(',');
		sb.append("medicarePaidAmt");
		sb.append('=');
		sb.append(((this.medicarePaidAmt == null) ? "<null>" : this.medicarePaidAmt));
		sb.append(',');
		sb.append("planPaysAmt");
		sb.append('=');
		sb.append(((this.planPaysAmt == null) ? "<null>" : this.planPaysAmt));
		sb.append(',');
		sb.append("deductibleAmt");
		sb.append('=');
		sb.append(((this.deductibleAmt == null) ? "<null>" : this.deductibleAmt));
		sb.append(',');
		sb.append("copayAmt");
		sb.append('=');
		sb.append(((this.copayAmt == null) ? "<null>" : this.copayAmt));
		sb.append(',');
		sb.append("coInsAmt");
		sb.append('=');
		sb.append(((this.coInsAmt == null) ? "<null>" : this.coInsAmt));
		sb.append(',');
		sb.append("notCoveredAmt");
		sb.append('=');
		sb.append(((this.notCoveredAmt == null) ? "<null>" : this.notCoveredAmt));
		sb.append(',');
		sb.append("yourAmtOwed");
		sb.append('=');
		sb.append(((this.yourAmtOwed == null) ? "<null>" : this.yourAmtOwed));
		sb.append(',');
		sb.append("amtPaid1");
		sb.append('=');
		sb.append(((this.amtPaid1 == null) ? "<null>" : this.amtPaid1));
		sb.append(',');
		sb.append("amtPaid2");
		sb.append('=');
		sb.append(((this.amtPaid2 == null) ? "<null>" : this.amtPaid2));
		sb.append(',');
		sb.append("amtPaid3");
		sb.append('=');
		sb.append(((this.amtPaid3 == null) ? "<null>" : this.amtPaid3));
		sb.append(',');
		sb.append("serviceDesc");
		sb.append('=');
		sb.append(((this.serviceDesc == null) ? "<null>" : this.serviceDesc));
		sb.append(',');
		sb.append("slRemarkCdInfo");
		sb.append('=');
		sb.append(((this.slRemarkCdInfo == null) ? "<null>" : this.slRemarkCdInfo));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
