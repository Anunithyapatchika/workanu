package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "networkTyp", "presentationSeqOrder", "annualAmt", "yearToDateAmt", "remainingAmt", "accumLblTxt",
		"accumLevelCd", "accumNm" })
@Generated("jsonschema2pojo")
public class AccumDetail {

	@JsonProperty("networkTyp")
	private String networkTyp;
	@JsonProperty("presentationSeqOrder")
	private String presentationSeqOrder;
	@JsonProperty("annualAmt")
	private String annualAmt;
	@JsonProperty("yearToDateAmt")
	private String yearToDateAmt;
	@JsonProperty("remainingAmt")
	private String remainingAmt;
	@JsonProperty("accumLblTxt")
	private String accumLblTxt;
	@JsonProperty("accumLevelCd")
	private String accumLevelCd;
	@JsonProperty("accumNm")
	private String accumNm;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("networkTyp")
	public String getNetworkTyp() {
		return networkTyp;
	}

	@JsonProperty("networkTyp")
	public void setNetworkTyp(String networkTyp) {
		this.networkTyp = networkTyp;
	}

	@JsonProperty("presentationSeqOrder")
	public String getPresentationSeqOrder() {
		return presentationSeqOrder;
	}

	@JsonProperty("presentationSeqOrder")
	public void setPresentationSeqOrder(String presentationSeqOrder) {
		this.presentationSeqOrder = presentationSeqOrder;
	}

	@JsonProperty("annualAmt")
	public String getAnnualAmt() {
		return annualAmt;
	}

	@JsonProperty("annualAmt")
	public void setAnnualAmt(String annualAmt) {
		this.annualAmt = annualAmt;
	}

	@JsonProperty("yearToDateAmt")
	public String getYearToDateAmt() {
		return yearToDateAmt;
	}

	@JsonProperty("yearToDateAmt")
	public void setYearToDateAmt(String yearToDateAmt) {
		this.yearToDateAmt = yearToDateAmt;
	}

	@JsonProperty("remainingAmt")
	public String getRemainingAmt() {
		return remainingAmt;
	}

	@JsonProperty("remainingAmt")
	public void setRemainingAmt(String remainingAmt) {
		this.remainingAmt = remainingAmt;
	}

	@JsonProperty("accumLblTxt")
	public String getAccumLblTxt() {
		return accumLblTxt;
	}

	@JsonProperty("accumLblTxt")
	public void setAccumLblTxt(String accumLblTxt) {
		this.accumLblTxt = accumLblTxt;
	}

	@JsonProperty("accumLevelCd")
	public String getAccumLevelCd() {
		return accumLevelCd;
	}

	@JsonProperty("accumLevelCd")
	public void setAccumLevelCd(String accumLevelCd) {
		this.accumLevelCd = accumLevelCd;
	}

	@JsonProperty("accumNm")
	public String getAccumNm() {
		return accumNm;
	}

	@JsonProperty("accumNm")
	public void setAccumNm(String accumNm) {
		this.accumNm = accumNm;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(AccumDetail.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this)))
				.append('[');
		sb.append("networkTyp");
		sb.append('=');
		sb.append(((this.networkTyp == null) ? "<null>" : this.networkTyp));
		sb.append(',');
		sb.append("presentationSeqOrder");
		sb.append('=');
		sb.append(((this.presentationSeqOrder == null) ? "<null>" : this.presentationSeqOrder));
		sb.append(',');
		sb.append("annualAmt");
		sb.append('=');
		sb.append(((this.annualAmt == null) ? "<null>" : this.annualAmt));
		sb.append(',');
		sb.append("yearToDateAmt");
		sb.append('=');
		sb.append(((this.yearToDateAmt == null) ? "<null>" : this.yearToDateAmt));
		sb.append(',');
		sb.append("remainingAmt");
		sb.append('=');
		sb.append(((this.remainingAmt == null) ? "<null>" : this.remainingAmt));
		sb.append(',');
		sb.append("accumLblTxt");
		sb.append('=');
		sb.append(((this.accumLblTxt == null) ? "<null>" : this.accumLblTxt));
		sb.append(',');
		sb.append("accumLevelCd");
		sb.append('=');
		sb.append(((this.accumLevelCd == null) ? "<null>" : this.accumLevelCd));
		sb.append(',');
		sb.append("accumNm");
		sb.append('=');
		sb.append(((this.accumNm == null) ? "<null>" : this.accumNm));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
