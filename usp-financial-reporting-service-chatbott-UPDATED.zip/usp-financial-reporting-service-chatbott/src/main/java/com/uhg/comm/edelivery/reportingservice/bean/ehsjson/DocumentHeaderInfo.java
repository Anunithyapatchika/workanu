package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "sourceSystem", "docTyp", "partnerProcGrpId", "partnerId", "docNbr", "docCreationReqDt",
		"docCreationReqTime", "docRecipientTyp","lineOfBusiness","bookOfBusiness" })
@Generated("jsonschema2pojo")
public class DocumentHeaderInfo {

	@JsonProperty("sourceSystem")
	private String sourceSystem;
	@JsonProperty("docTyp")
	private String docTyp;
	@JsonProperty("partnerProcGrpId")
	private String partnerProcGrpId;
	@JsonProperty("partnerId")
	private String partnerId;
	@JsonProperty("docNbr")
	private String docNbr;
	@JsonProperty("docCreationReqDt")
	private String docCreationReqDt;
	@JsonProperty("docCreationReqTime")
	private String docCreationReqTime;
	@JsonProperty("docRecipientTyp")
	private String docRecipientTyp;
	@JsonProperty("lineOfBusiness")
	private String lineOfBusiness;
	@JsonProperty("bookOfBusiness")
	private String bookOfBusiness;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("sourceSystem")
	public String getSourceSystem() {
		return sourceSystem;
	}

	@JsonProperty("sourceSystem")
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	@JsonProperty("docTyp")
	public String getDocTyp() {
		return docTyp;
	}

	@JsonProperty("docTyp")
	public void setDocTyp(String docTyp) {
		this.docTyp = docTyp;
	}

	@JsonProperty("partnerProcGrpId")
	public String getPartnerProcGrpId() {
		return partnerProcGrpId;
	}

	@JsonProperty("partnerProcGrpId")
	public void setPartnerProcGrpId(String partnerProcGrpId) {
		this.partnerProcGrpId = partnerProcGrpId;
	}

	@JsonProperty("partnerId")
	public String getPartnerId() {
		return partnerId;
	}

	@JsonProperty("partnerId")
	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	@JsonProperty("docNbr")
	public String getDocNbr() {
		return docNbr;
	}

	@JsonProperty("docNbr")
	public void setDocNbr(String docNbr) {
		this.docNbr = docNbr;
	}

	@JsonProperty("docCreationReqDt")
	public String getDocCreationReqDt() {
		return docCreationReqDt;
	}

	@JsonProperty("docCreationReqDt")
	public void setDocCreationReqDt(String docCreationReqDt) {
		this.docCreationReqDt = docCreationReqDt;
	}

	@JsonProperty("docCreationReqTime")
	public String getDocCreationReqTime() {
		return docCreationReqTime;
	}

	@JsonProperty("docCreationReqTime")
	public void setDocCreationReqTime(String docCreationReqTime) {
		this.docCreationReqTime = docCreationReqTime;
	}

	@JsonProperty("docRecipientTyp")
	public String getDocRecipientTyp() {
		return docRecipientTyp;
	}

	@JsonProperty("docRecipientTyp")
	public void setDocRecipientTyp(String docRecipientTyp) {
		this.docRecipientTyp = docRecipientTyp;
	}

	@JsonProperty("lineOfBusiness")
	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	@JsonProperty("lineOfBusiness")
	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	@JsonProperty("bookOfBusiness")
	public String getBookOfBusiness() {
		return bookOfBusiness;
	}

	@JsonProperty("bookOfBusiness")
	public void setBookOfBusiness(String bookOfBusiness) {
		this.bookOfBusiness = bookOfBusiness;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(DocumentHeaderInfo.class.getName()).append('@')
				.append(Integer.toHexString(System.identityHashCode(this))).append('[');
		sb.append("sourceSystem");
		sb.append('=');
		sb.append(((this.sourceSystem == null) ? "<null>" : this.sourceSystem));
		sb.append(',');
		sb.append("docTyp");
		sb.append('=');
		sb.append(((this.docTyp == null) ? "<null>" : this.docTyp));
		sb.append(',');
		sb.append("partnerProcGrpId");
		sb.append('=');
		sb.append(((this.partnerProcGrpId == null) ? "<null>" : this.partnerProcGrpId));
		sb.append(',');
		sb.append("partnerId");
		sb.append('=');
		sb.append(((this.partnerId == null) ? "<null>" : this.partnerId));
		sb.append(',');
		sb.append("docNbr");
		sb.append('=');
		sb.append(((this.docNbr == null) ? "<null>" : this.docNbr));
		sb.append(',');
		sb.append("docCreationReqDt");
		sb.append('=');
		sb.append(((this.docCreationReqDt == null) ? "<null>" : this.docCreationReqDt));
		sb.append(',');
		sb.append("docCreationReqTime");
		sb.append('=');
		sb.append(((this.docCreationReqTime == null) ? "<null>" : this.docCreationReqTime));
		sb.append(',');
		sb.append("docRecipientTyp");
		sb.append('=');
		sb.append(((this.docRecipientTyp == null) ? "<null>" : this.docRecipientTyp));
		sb.append(',');
		sb.append("lineOfBusiness");
		sb.append('=');
		sb.append(((this.lineOfBusiness == null) ? "<null>" : this.lineOfBusiness));
		sb.append(',');
		sb.append("bookOfBusiness");
		sb.append('=');
		sb.append(((this.bookOfBusiness == null) ? "<null>" : this.bookOfBusiness));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
