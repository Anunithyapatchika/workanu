package com.uhg.comm.edelivery.reportingservice.controller;

import com.uhg.comm.edelivery.reportingservice.bean.GetFieldValues;
import com.uhg.comm.edelivery.reportingservice.dto.FinancialReportResponseDto;
import com.uhg.comm.edelivery.reportingservice.service.USPFinancialReportService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("financial-report")
@CrossOrigin
public class USPFinancialReportController {

    @Autowired
    private USPFinancialReportService uspFinancialReportService;

    @GetMapping(value = "/getReport", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<FinancialReportResponseDto> getAllFinancialReports(
            @RequestParam String trailName,
            @RequestParam String startDate,
            @RequestParam String endDate) {
        //Calls the service method to get the financial report.
        if (StringUtils.isBlank(trailName) || StringUtils.isBlank(startDate) || StringUtils.isBlank(endDate)) {
            throw new IllegalArgumentException("Trail Name, Start Date and End Date are mandatory fields. Please provide valid values.");
        }
        FinancialReportResponseDto response = uspFinancialReportService.getFinancialReport(trailName, startDate, endDate);
        //Returns the response wrapped in a ResponseEntity.
        return ResponseEntity.ok(response);
    }

}