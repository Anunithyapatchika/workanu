package com.uhg.comm.edelivery.reportingservice.exception;

import com.fasterxml.jackson.annotation.JsonRawValue;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.*;
import net.minidev.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.Map;

@Data
@NoArgsConstructor
@EqualsAndHashCode
@ToString
public class ErrorDetails {
    private int code;
    private String message;
    private String details;

    public ErrorDetails(int code, String message, String details) {
        this.code = code;
        this.message = message;
        this.details = details;
    }

    ObjectMapper om = new ObjectMapper();

    public ObjectNode toJsonString() {
        ObjectNode objectNode = om.createObjectNode();
        objectNode.put("code", code);
        objectNode.put("message", message);
        objectNode.put("details", details);

        return objectNode;
    }

    @JsonRawValue
    public String jsonString() {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", code);
        jsonObject.put("message", message);

        return jsonObject.toString();
    }

}
