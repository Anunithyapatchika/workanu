package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "summaryDispLocation", "detailInd", "claimTyp", "claimIdDisplay", "internalClaimId", "adjdDt",
		"patientFstNm", "patientLstNm", "claimSortOrderNbr", "patientSortRelCd", "patientPrivacyInd", "fstSrvcDt",
		"lstSrvcDt", "claimSrvcDesc", "provNm", "provNetworkStatus", "provRenderingNpi", "provBillingNpi",
		"claimTotAmt", "consumerAccountPaid", "otherClaimAttributes", "claimRemarkInfo", "claimMsg",
		"serviceLineInfo" })
@Generated("jsonschema2pojo")
public class ClaimInfo {

	@JsonProperty("summaryDispLocation")
	private String summaryDispLocation;
	@JsonProperty("detailInd")
	private String detailInd;
	@JsonProperty("claimTyp")
	private String claimTyp;
	@JsonProperty("claimIdDisplay")
	private String claimIdDisplay;
	@JsonProperty("internalClaimId")
	private String internalClaimId;
	@JsonProperty("adjdDt")
	private String adjdDt;
	@JsonProperty("patientFstNm")
	private String patientFstNm;
	@JsonProperty("patientLstNm")
	private String patientLstNm;
	@JsonProperty("claimSortOrderNbr")
	private String claimSortOrderNbr;
	@JsonProperty("patientSortRelCd")
	private String patientSortRelCd;
	@JsonProperty("patientPrivacyInd")
	private String patientPrivacyInd;
	@JsonProperty("fstSrvcDt")
	private String fstSrvcDt;
	@JsonProperty("lstSrvcDt")
	private String lstSrvcDt;
	@JsonProperty("claimSrvcDesc")
	private String claimSrvcDesc;
	@JsonProperty("provNm")
	private String provNm;
	@JsonProperty("provNetworkStatus")
	private String provNetworkStatus;
	@JsonProperty("provRenderingNpi")
	private String provRenderingNpi;
	@JsonProperty("provBillingNpi")
	private String provBillingNpi;
	@JsonProperty("claimTotAmt")
	private ClaimTotAmt claimTotAmt;
	@JsonProperty("consumerAccountPaid")
	private List<ConsumerAccountPaid> consumerAccountPaid = null;
	@JsonProperty("otherClaimAttributes")
	private OtherClaimAttributes otherClaimAttributes;
	@JsonProperty("claimRemarkInfo")
	private ClaimRemarkInfo claimRemarkInfo;
	@JsonProperty("claimMsg")
	private List<ClaimMsg> claimMsg = null;
	@JsonProperty("serviceLineInfo")
	private List<ServiceLineInfo> serviceLineInfo = null;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("summaryDispLocation")
	public String getSummaryDispLocation() {
		return summaryDispLocation;
	}

	@JsonProperty("summaryDispLocation")
	public void setSummaryDispLocation(String summaryDispLocation) {
		this.summaryDispLocation = summaryDispLocation;
	}

	@JsonProperty("detailInd")
	public String getDetailInd() {
		return detailInd;
	}

	@JsonProperty("detailInd")
	public void setDetailInd(String detailInd) {
		this.detailInd = detailInd;
	}

	@JsonProperty("claimTyp")
	public String getClaimTyp() {
		return claimTyp;
	}

	@JsonProperty("claimTyp")
	public void setClaimTyp(String claimTyp) {
		this.claimTyp = claimTyp;
	}

	@JsonProperty("claimIdDisplay")
	public String getClaimIdDisplay() {
		return claimIdDisplay;
	}

	@JsonProperty("claimIdDisplay")
	public void setClaimIdDisplay(String claimIdDisplay) {
		this.claimIdDisplay = claimIdDisplay;
	}

	@JsonProperty("internalClaimId")
	public String getInternalClaimId() {
		return internalClaimId;
	}

	@JsonProperty("internalClaimId")
	public void setInternalClaimId(String internalClaimId) {
		this.internalClaimId = internalClaimId;
	}

	@JsonProperty("adjdDt")
	public String getAdjdDt() {
		return adjdDt;
	}

	@JsonProperty("adjdDt")
	public void setAdjdDt(String adjdDt) {
		this.adjdDt = adjdDt;
	}

	@JsonProperty("patientFstNm")
	public String getPatientFstNm() {
		return patientFstNm;
	}

	@JsonProperty("patientFstNm")
	public void setPatientFstNm(String patientFstNm) {
		this.patientFstNm = patientFstNm;
	}

	@JsonProperty("patientLstNm")
	public String getPatientLstNm() {
		return patientLstNm;
	}

	@JsonProperty("patientLstNm")
	public void setPatientLstNm(String patientLstNm) {
		this.patientLstNm = patientLstNm;
	}

	@JsonProperty("claimSortOrderNbr")
	public String getClaimSortOrderNbr() {
		return claimSortOrderNbr;
	}

	@JsonProperty("claimSortOrderNbr")
	public void setClaimSortOrderNbr(String claimSortOrderNbr) {
		this.claimSortOrderNbr = claimSortOrderNbr;
	}

	@JsonProperty("patientSortRelCd")
	public String getPatientSortRelCd() {
		return patientSortRelCd;
	}

	@JsonProperty("patientSortRelCd")
	public void setPatientSortRelCd(String patientSortRelCd) {
		this.patientSortRelCd = patientSortRelCd;
	}

	@JsonProperty("patientPrivacyInd")
	public String getPatientPrivacyInd() {
		return patientPrivacyInd;
	}

	@JsonProperty("patientPrivacyInd")
	public void setPatientPrivacyInd(String patientPrivacyInd) {
		this.patientPrivacyInd = patientPrivacyInd;
	}

	@JsonProperty("fstSrvcDt")
	public String getFstSrvcDt() {
		return fstSrvcDt;
	}

	@JsonProperty("fstSrvcDt")
	public void setFstSrvcDt(String fstSrvcDt) {
		this.fstSrvcDt = fstSrvcDt;
	}

	@JsonProperty("lstSrvcDt")
	public String getLstSrvcDt() {
		return lstSrvcDt;
	}

	@JsonProperty("lstSrvcDt")
	public void setLstSrvcDt(String lstSrvcDt) {
		this.lstSrvcDt = lstSrvcDt;
	}

	@JsonProperty("claimSrvcDesc")
	public String getClaimSrvcDesc() {
		return claimSrvcDesc;
	}

	@JsonProperty("claimSrvcDesc")
	public void setClaimSrvcDesc(String claimSrvcDesc) {
		this.claimSrvcDesc = claimSrvcDesc;
	}

	@JsonProperty("provNm")
	public String getProvNm() {
		return provNm;
	}

	@JsonProperty("provNm")
	public void setProvNm(String provNm) {
		this.provNm = provNm;
	}

	@JsonProperty("provNetworkStatus")
	public String getProvNetworkStatus() {
		return provNetworkStatus;
	}

	@JsonProperty("provNetworkStatus")
	public void setProvNetworkStatus(String provNetworkStatus) {
		this.provNetworkStatus = provNetworkStatus;
	}

	@JsonProperty("provRenderingNpi")
	public String getProvRenderingNpi() {
		return provRenderingNpi;
	}

	@JsonProperty("provRenderingNpi")
	public void setProvRenderingNpi(String provRenderingNpi) {
		this.provRenderingNpi = provRenderingNpi;
	}

	@JsonProperty("provBillingNpi")
	public String getProvBillingNpi() {
		return provBillingNpi;
	}

	@JsonProperty("provBillingNpi")
	public void setProvBillingNpi(String provBillingNpi) {
		this.provBillingNpi = provBillingNpi;
	}

	@JsonProperty("claimTotAmt")
	public ClaimTotAmt getClaimTotAmt() {
		return claimTotAmt;
	}

	@JsonProperty("claimTotAmt")
	public void setClaimTotAmt(ClaimTotAmt claimTotAmt) {
		this.claimTotAmt = claimTotAmt;
	}

	@JsonProperty("consumerAccountPaid")
	public List<ConsumerAccountPaid> getConsumerAccountPaid() {
		return consumerAccountPaid;
	}

	@JsonProperty("consumerAccountPaid")
	public void setConsumerAccountPaid(List<ConsumerAccountPaid> consumerAccountPaid) {
		this.consumerAccountPaid = consumerAccountPaid;
	}

	@JsonProperty("otherClaimAttributes")
	public OtherClaimAttributes getOtherClaimAttributes() {
		return otherClaimAttributes;
	}

	@JsonProperty("otherClaimAttributes")
	public void setOtherClaimAttributes(OtherClaimAttributes otherClaimAttributes) {
		this.otherClaimAttributes = otherClaimAttributes;
	}

	@JsonProperty("claimRemarkInfo")
	public ClaimRemarkInfo getClaimRemarkInfo() {
		return claimRemarkInfo;
	}

	@JsonProperty("claimRemarkInfo")
	public void setClaimRemarkInfo(ClaimRemarkInfo claimRemarkInfo) {
		this.claimRemarkInfo = claimRemarkInfo;
	}

	@JsonProperty("claimMsg")
	public List<ClaimMsg> getClaimMsg() {
		return claimMsg;
	}

	@JsonProperty("claimMsg")
	public void setClaimMsg(List<ClaimMsg> claimMsg) {
		this.claimMsg = claimMsg;
	}

	@JsonProperty("serviceLineInfo")
	public List<ServiceLineInfo> getServiceLineInfo() {
		return serviceLineInfo;
	}

	@JsonProperty("serviceLineInfo")
	public void setServiceLineInfo(List<ServiceLineInfo> serviceLineInfo) {
		this.serviceLineInfo = serviceLineInfo;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(ClaimInfo.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this)))
				.append('[');
		sb.append("summaryDispLocation");
		sb.append('=');
		sb.append(((this.summaryDispLocation == null) ? "<null>" : this.summaryDispLocation));
		sb.append(',');
		sb.append("detailInd");
		sb.append('=');
		sb.append(((this.detailInd == null) ? "<null>" : this.detailInd));
		sb.append(',');
		sb.append("claimTyp");
		sb.append('=');
		sb.append(((this.claimTyp == null) ? "<null>" : this.claimTyp));
		sb.append(',');
		sb.append("claimIdDisplay");
		sb.append('=');
		sb.append(((this.claimIdDisplay == null) ? "<null>" : this.claimIdDisplay));
		sb.append(',');
		sb.append("internalClaimId");
		sb.append('=');
		sb.append(((this.internalClaimId == null) ? "<null>" : this.internalClaimId));
		sb.append(',');
		sb.append("adjdDt");
		sb.append('=');
		sb.append(((this.adjdDt == null) ? "<null>" : this.adjdDt));
		sb.append(',');
		sb.append("patientFstNm");
		sb.append('=');
		sb.append(((this.patientFstNm == null) ? "<null>" : this.patientFstNm));
		sb.append(',');
		sb.append("patientLstNm");
		sb.append('=');
		sb.append(((this.patientLstNm == null) ? "<null>" : this.patientLstNm));
		sb.append(',');
		sb.append("claimSortOrderNbr");
		sb.append('=');
		sb.append(((this.claimSortOrderNbr == null) ? "<null>" : this.claimSortOrderNbr));
		sb.append(',');
		sb.append("patientSortRelCd");
		sb.append('=');
		sb.append(((this.patientSortRelCd == null) ? "<null>" : this.patientSortRelCd));
		sb.append(',');
		sb.append("patientPrivacyInd");
		sb.append('=');
		sb.append(((this.patientPrivacyInd == null) ? "<null>" : this.patientPrivacyInd));
		sb.append(',');
		sb.append("fstSrvcDt");
		sb.append('=');
		sb.append(((this.fstSrvcDt == null) ? "<null>" : this.fstSrvcDt));
		sb.append(',');
		sb.append("lstSrvcDt");
		sb.append('=');
		sb.append(((this.lstSrvcDt == null) ? "<null>" : this.lstSrvcDt));
		sb.append(',');
		sb.append("claimSrvcDesc");
		sb.append('=');
		sb.append(((this.claimSrvcDesc == null) ? "<null>" : this.claimSrvcDesc));
		sb.append(',');
		sb.append("provNm");
		sb.append('=');
		sb.append(((this.provNm == null) ? "<null>" : this.provNm));
		sb.append(',');
		sb.append("provNetworkStatus");
		sb.append('=');
		sb.append(((this.provNetworkStatus == null) ? "<null>" : this.provNetworkStatus));
		sb.append(',');
		sb.append("provRenderingNpi");
		sb.append('=');
		sb.append(((this.provRenderingNpi == null) ? "<null>" : this.provRenderingNpi));
		sb.append(',');
		sb.append("provBillingNpi");
		sb.append('=');
		sb.append(((this.provBillingNpi == null) ? "<null>" : this.provBillingNpi));
		sb.append(',');
		sb.append("claimTotAmt");
		sb.append('=');
		sb.append(((this.claimTotAmt == null) ? "<null>" : this.claimTotAmt));
		sb.append(',');
		sb.append("consumerAccountPaid");
		sb.append('=');
		sb.append(((this.consumerAccountPaid == null) ? "<null>" : this.consumerAccountPaid));
		sb.append(',');
		sb.append("otherClaimAttributes");
		sb.append('=');
		sb.append(((this.otherClaimAttributes == null) ? "<null>" : this.otherClaimAttributes));
		sb.append(',');
		sb.append("claimRemarkInfo");
		sb.append('=');
		sb.append(((this.claimRemarkInfo == null) ? "<null>" : this.claimRemarkInfo));
		sb.append(',');
		sb.append("claimMsg");
		sb.append('=');
		sb.append(((this.claimMsg == null) ? "<null>" : this.claimMsg));
		sb.append(',');
		sb.append("serviceLineInfo");
		sb.append('=');
		sb.append(((this.serviceLineInfo == null) ? "<null>" : this.serviceLineInfo));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
