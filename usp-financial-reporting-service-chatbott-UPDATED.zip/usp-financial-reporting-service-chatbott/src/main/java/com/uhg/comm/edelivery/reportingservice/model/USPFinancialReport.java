package com.uhg.comm.edelivery.reportingservice.model;


import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "usp_eob_hs_financial_report", schema = "edelivery")
@Data
@EqualsAndHashCode
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class USPFinancialReport {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eob_hs_financial_report_id_seq")
    @SequenceGenerator(name = "eob_hs_financial_report_id_seq", sequenceName = "eob_hs_financial_report_id_seq", schema = "edelivery", allocationSize = 1)
    @Column(name = "id", updatable = false, nullable = false)
    private Integer id;

    @Column(name = "trail_name")
    private String trailName;

    @Column(name = "month_year")
    private LocalDate monthYear;

    @Column(name = "month_year_str")
    private String monthYearStr;

    @Transient
    private String filename;

    @Column(name = "bob")
    private String bob;

    @Column(name = "total_eob_generated")
    private double totalEobGenerated;

    @Column(name = "total_eob_suppressed")
    private double totalEobSuppressed;

    @Column(name = "member_election_eob")
    private double memberElectionEob;

    @Column(name = "policy_setting_eob")
    private double policySettingEob;

    @Column(name = "total_eob_printed")
    private double totalEobPrinted;

    @Column(name = "eob_suppress_percent")
    private double eobSuppressPercent;

    @Column(name = "total_hs_generated")
    private double totalHsGenerated;

    @Column(name = "total_hs_suppressed")
    private double totalHsSuppressed;

    @Column(name = "member_election_hs")
    private double memberElectionHs;

    @Column(name = "policy_setting_hs")
    private double policySettingHs;

    @Column(name = "hs_mem_print")
    private double hsMemPrint;

    @Column(name = "total_hs_printed")
    private double totalHsPrinted;

    @Column(name = "hs_suppress_percent")
    private double hsSuppressPercent;

    @Column(name = "cae_eob_mail_count")
    private double caeEobMailCount;

    @Column(name = "cae_eob_no_email_count")
    private double caeEobNoEmailCount;

    @Column(name = "total_cae_eob_count")
    private double totalCaeEobCount;

    @Column(name = "created_by", updatable = false)
    private String createdBy;

    @CreationTimestamp
    @Column(name = "created_date", updatable = false)
    private LocalDateTime createdDate;

    @Column(name = "modified_by")
    private String modifiedBy;

    @UpdateTimestamp
    @Column(name = "modified_date")
    private LocalDateTime modifiedDate;

    @Column(name = "is_tx_completed")
    private int isTxCompleted;

    @Column(name = "is_completed")
    private int isCompleted;
}
