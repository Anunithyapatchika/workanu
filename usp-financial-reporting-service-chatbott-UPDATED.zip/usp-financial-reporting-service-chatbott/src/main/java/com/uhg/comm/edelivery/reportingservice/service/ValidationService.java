package com.uhg.comm.edelivery.reportingservice.service;

import com.uhg.comm.edelivery.reportingservice.dto.PrintingCostDto;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.List;
import java.util.ArrayList;
import java.util.Locale;

public class ValidationService {

    public static List<String> validate(PrintingCostDto printingCostDto) {
        List<String> errors = new ArrayList<>();

        String trailName = printingCostDto.getTrailName();
        String bob = printingCostDto.getBob();
        String month = printingCostDto.getMonth();

        if (StringUtils.isBlank(trailName)) {
            errors.add("Trail Name is mandatory field. Please provide valid value.");
        }
        if (StringUtils.isBlank(bob)) {
            errors.add("BOB is mandatory field. Please provide valid value.");
        }
        if (StringUtils.isBlank(month)) {
            errors.add("Month is mandatory field. Please provide valid value.");
        }

        LocalDate now = LocalDate.now();
        String monthName = now.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
        int year = now.getYear();

        String monthYear = monthName + " " + year;
//        if (printingCostDto.getMonth().equalsIgnoreCase(monthYear)) {
//            errors.add("You cannot enter the current month's data. Please provide any previous month.");
//        }

        if (printingCostDto.getPostageCost() <= 0) {
            errors.add("Postage Cost cannot be negative or zero. Please provide valid value.");
        }
        if (printingCostDto.getPrintExpenseCost() <= 0) {
            errors.add("Printing Expense Cost cannot be negative or zero. Please provide valid value.");
        }
        if (printingCostDto.getPaperCount() <= 0) {
            errors.add("Paper Count cannot be negative or zero. Make sure you have calculated it.");
        }
        if (printingCostDto.getImageCount() <= 0) {
            errors.add("Images cannot be negative or zero. Please provide valid value.");
        }
        if (printingCostDto.getEnvelopCount() <= 0) {
            errors.add("Envelop cannot be negative or zero. Please provide valid value.");
        }

        return errors;
    }
}
