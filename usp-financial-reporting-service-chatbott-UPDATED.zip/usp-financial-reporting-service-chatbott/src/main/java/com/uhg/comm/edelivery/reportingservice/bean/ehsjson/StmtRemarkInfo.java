package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "remarkCd", "remarkText", "remarkSecDispInd" })
@Generated("jsonschema2pojo")
public class StmtRemarkInfo {

	@JsonProperty("remarkCd")
	private String remarkCd;
	@JsonProperty("remarkText")
	private String remarkText;
	@JsonProperty("remarkSecDispInd")
	private String remarkSecDispInd;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("remarkCd")
	public String getRemarkCd() {
		return remarkCd;
	}

	@JsonProperty("remarkCd")
	public void setRemarkCd(String remarkCd) {
		this.remarkCd = remarkCd;
	}

	@JsonProperty("remarkText")
	public String getRemarkText() {
		return remarkText;
	}

	@JsonProperty("remarkText")
	public void setRemarkText(String remarkText) {
		this.remarkText = remarkText;
	}

	@JsonProperty("remarkSecDispInd")
	public String getRemarkSecDispInd() {
		return remarkSecDispInd;
	}

	@JsonProperty("remarkSecDispInd")
	public void setRemarkSecDispInd(String remarkSecDispInd) {
		this.remarkSecDispInd = remarkSecDispInd;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(StmtRemarkInfo.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this)))
				.append('[');
		sb.append("remarkCd");
		sb.append('=');
		sb.append(((this.remarkCd == null) ? "<null>" : this.remarkCd));
		sb.append(',');
		sb.append("remarkText");
		sb.append('=');
		sb.append(((this.remarkText == null) ? "<null>" : this.remarkText));
		sb.append(',');
		sb.append("remarkSecDispInd");
		sb.append('=');
		sb.append(((this.remarkSecDispInd == null) ? "<null>" : this.remarkSecDispInd));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
