package com.uhg.comm.edelivery.reportingservice.service;

import com.uhg.comm.edelivery.reportingservice.model.TrailAndBobDetails;
import com.uhg.comm.edelivery.reportingservice.repository.TrailAndBobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public class TrailAndBobDetailsService {

    @Autowired
    private TrailAndBobRepository trailAndBobRepository;
    public Set<TrailAndBobDetails> getActiveTrailAndBobDetails() {
        return trailAndBobRepository.findByIsActive(1);
    }
}
