package com.uhg.comm.edelivery.reportingservice.bean;

import com.uhg.comm.edelivery.avrobean.DocumentTypes;
import com.uhg.comm.edelivery.avrobean.Environments;
import com.uhg.comm.edelivery.avrobean.TrailTypes;
import lombok.Data;

@Data
public class QuadientBean {
	private String jobId;
	private String quadientResponseFileName;
	private String quadientResponseFilePath;
	private String prodTrailNumber;
	private String bounceTrailNumber;
	private TrailTypes trailType;
	private DocumentTypes documentType;
	private Environments environment;
	private String batchId;
	private String status;
	private String printTrailType;
	private String inputFileName;
	private String cae;
	private String actualJobStartTime;
	private int totalMatchedClaimCount;
	private int totalMismatchedClaimCount;
	private int totalCalculatedClaimForValidJson;
	private int totalClaimCountPE;
	private String claimMismatchedThreshold;
	private int noOfStatementComposed;
	private int noOfClaimComposed;
	private int totalValidStatement;
	private int totalInvalidStatement;
	private int totalNumRecords;
	private int noOfStatementsECSP;
	private int noOfStatementsSentFromPE;
	private int noOfStatementToEmail;
	private int noOfStatementToPrint;
	private String errorCode;
	private String errorMsg;
	private String errorDescription;
}


