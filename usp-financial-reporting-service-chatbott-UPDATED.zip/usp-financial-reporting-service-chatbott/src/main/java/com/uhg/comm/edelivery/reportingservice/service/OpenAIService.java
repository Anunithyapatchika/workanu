package com.uhg.comm.edelivery.reportingservice.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.uhg.comm.edelivery.reportingservice.bean.MessageWithImageResponse;
import com.uhg.comm.edelivery.reportingservice.model.Message;

import java.util.List;

public interface OpenAIService {

    MessageWithImageResponse callOpenAIApi(List<Message> req, String type) throws JsonProcessingException;

}
