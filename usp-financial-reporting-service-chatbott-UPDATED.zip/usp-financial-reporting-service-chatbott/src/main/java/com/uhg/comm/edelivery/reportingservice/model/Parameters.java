package com.uhg.comm.edelivery.reportingservice.model;

import lombok.Data;

import java.util.List;
import java.util.Map;


@Data
public class Parameters {
    private String endpoint;
    private boolean in_scope;
    private int strictness;
    private int top_n_documents;
    private Authentication authentication;
    private List<String> include_contexts;
    private String query_type; // Not queryType
    private String semantic_configuration; // Not semanticConfiguration
    private String index_name;
    private FieldMapping fields_mapping;

}
