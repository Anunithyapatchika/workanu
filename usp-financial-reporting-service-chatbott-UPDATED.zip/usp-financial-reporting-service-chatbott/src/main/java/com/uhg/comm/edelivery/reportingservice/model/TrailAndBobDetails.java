package com.uhg.comm.edelivery.reportingservice.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Entity
@Table(name = "trail_and_bob_details", schema = "edelivery")
@Data
@EqualsAndHashCode
@ToString
public class TrailAndBobDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "trail_bob_details_id_seq")
    @SequenceGenerator(name = "trail_bob_details_id_seq", sequenceName = "trail_bob_details_id_seq", schema = "edelivery", allocationSize = 1)
    @Column(name = "id")
    private Integer id;

    @Column(name = "trail_number")
    private String trailNumber;

    @Column(name = "bob_name")
    private String bobName;

    @Column(name = "is_active")
    private int isActive;
}
