package com.uhg.comm.edelivery.reportingservice.model;

import lombok.Data;

import java.util.List;

@Data
public class Message {
    private String role; // "user", "system", "assistant"
    private String content;
}