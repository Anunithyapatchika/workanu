package com.uhg.comm.edelivery.reportingservice.controller;

import com.azure.storage.blob.*;
import com.azure.storage.blob.models.BlobDownloadContentResponse;
import com.uhg.comm.edelivery.reportingservice.service.ChatBotService;
import com.uhg.comm.edelivery.reportingservice.util.BlobUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class ChatBotController {

    @Value("${filePath.chatBotJsonPath}")
    private String chatBotJsonPath;

    @Autowired
    private BlobUtils blobUtils;

    @Autowired
    private ChatBotService chatBotService;

    @GetMapping("/readJson")
    public String readJson() {
        log.info("Received request to read JSON from Azure Blob Storage :{}", chatBotJsonPath);
       return chatBotService.readInputJsonFile();
    }
}
