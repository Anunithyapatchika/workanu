package com.uhg.comm.edelivery.reportingservice.service.impl;

import com.azure.storage.blob.BlobClient;
import com.microsoft.azure.eventgrid.models.StorageBlobCreatedEventData;
import com.uhg.comm.edelivery.processLog.Processlog;
import com.uhg.comm.edelivery.reportingservice.model.TrailAndBobDetails;
import com.uhg.comm.edelivery.reportingservice.model.USPFinancialReport;
import com.uhg.comm.edelivery.reportingservice.nesslogger.NessLoggerService;
import com.uhg.comm.edelivery.reportingservice.repository.TrailAndBobRepository;
import com.uhg.comm.edelivery.reportingservice.repository.USP3231DataRepository;
import com.uhg.comm.edelivery.reportingservice.repository.USPFinancialReportRepository;
import com.uhg.comm.edelivery.reportingservice.service.SendEmailService;
import com.uhg.comm.edelivery.reportingservice.service.USP3231DataService;
import com.uhg.comm.edelivery.reportingservice.util.BlobUtils;
import com.uhg.comm.edelivery.reportingservice.util.CalculationUtils;
import com.uhg.comm.edelivery.reportingservice.util.DateUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static com.uhg.comm.edelivery.reportingservice.constants.Constants.*;

@Service
public class USP3231DataServiceImpl implements USP3231DataService {
    private static final Logger LOGGER = LoggerFactory.getLogger(com.uhg.comm.edelivery.reportingservice.service.USP3231DataService.class);

    @Value("${edelivery.configproperties.properties.USP3231.DateFilter}")
    private String dateFilter;

    @Value("${edelivery.configproperties.properties.USP3231.minusDays}")
    private Long minusDays;

    @Value("${edelivery.configproperties.properties.TxStatusUpdate.DayUpdateTxStatus}")
    private int DayUpdateTxStatus;

    @Autowired
    private BlobUtils blobUtils;

    @Autowired
    private USPFinancialReportRepository uspFinancialReportRepository;

    @Autowired
    private USP3231DataRepository usp3231DataRepo;

    @Autowired
    private SendEmailService sendEmailService;

    @Autowired
    private NessLoggerService nessLoggerService;


    @Autowired
    private TrailAndBobRepository trailAndBobRepo;

    @Override
    public void process() {
        Processlog processlog = new Processlog();
        try {
            LOGGER.info("Fetching USP3231 Data");
            processlog.setApiName("USP3231_scheduler");
            processlog.setTrailNumber(PT3231_EOB);
            processlog.setReqEntryTimestamp(new Timestamp(System.currentTimeMillis()).toString());
            processlog.setServiceName(USP_FIN_REPORTING_SERVICE);
            List<USPFinancialReport> uspFinancialReportList = usp3231DataRepo.getUSP3231Data(dateFilter,processlog);
            if (!CollectionUtils.isEmpty(uspFinancialReportList) && !CollectionUtils.isEmpty(uspFinancialReportList.stream().filter(a->StringUtils.isNotBlank(a.getBob())).collect(Collectors.toList()))) {
                LOGGER.info("USP3231 Data size :: {}", uspFinancialReportList.size());
                fetchUSP3231Data(uspFinancialReportList,processlog);
                LOGGER.info("Processed USP3231");
                processlog.setStatus("SUCCESS");

            } else {
                LOGGER.info("No USP3231 Data found in the DataBase");
                processlog.setStatus("NO_DATA_FOUND");
                processlog.setAdditionalProperty("fetchedDate", Date.valueOf(new Date(System.currentTimeMillis()).toLocalDate().minusDays(minusDays)).toString());
                processlog.setErrorMessage("No USP3231 Data found in the DataBase");
            }
            processlog.setReqFinishTimestamp(new Date(System.currentTimeMillis()).toString());
            nessLoggerService.publishNesslogsToSplunk(processlog.toString());
            sendEmailService.sendEmail(processlog);
            updateNewBoB(uspFinancialReportList, processlog);
            completeTrxForPrevMonth(processlog);
        } catch (Exception e) {
            LOGGER.error("Exception occurred while processing scheduler :: ", e);
            processlog.setStatus("FAILED");
            if (StringUtils.isBlank(processlog.getErrorMessage())){
                processlog.setErrorMessage(e.getLocalizedMessage());
            }
            processlog.setAdditionalProperty("fetchedDate", Date.valueOf(new Date(System.currentTimeMillis()).toLocalDate().minusDays(minusDays)).toString());
            processlog.setReqFinishTimestamp(new Date(System.currentTimeMillis()).toString());
            nessLoggerService.publishNesslogsToSplunk(processlog.toString());
            sendEmailService.sendEmail(processlog);
        }

    }


    @Override
    public void completeTrxForPrevMonth(Processlog processlog) {
        try {
            Date currentDate = new Date(System.currentTimeMillis());
            LOGGER.info("checking for last month transaction completion :: {}, DayUpdateTxStatus :: {}", currentDate, DayUpdateTxStatus);
            if (DateUtil.getDayOfMonth(currentDate) == DayUpdateTxStatus) {
                LocalDate datee = currentDate.toLocalDate().minusMonths(1).withDayOfMonth(1);
                String monthYearStr = DateUtil.getLocalDateToString(datee);
                LOGGER.info("Checking for last month transaction completion for trail :: {} , monthYearStr :: {}", PT3231_EOB, monthYearStr);
                List<USPFinancialReport> uspFinancialReportList = uspFinancialReportRepository.findByTrailNameAndIsTxCompletedAndMonthYearStr(PT3231_EOB, 0, monthYearStr);
                if (!CollectionUtils.isEmpty(uspFinancialReportList)) {
                    for (USPFinancialReport uspFinancialReport : uspFinancialReportList) {
                        uspFinancialReport.setIsTxCompleted(1);
                        uspFinancialReportRepository.save(uspFinancialReport);
                        LOGGER.info("Transaction completed for last month :: {}", uspFinancialReport);
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("Exception occurred while completing transaction of PT3231 for last month :: {}", e.getLocalizedMessage());
            processlog.setErrorMessage("Exception occurred while completing transaction of PT3231 for last month");
            throw e;
        }
    }

    public void fetchUSP3231Data(List<USPFinancialReport> uspFinancialReportList, Processlog processlog) {
        Optional<USPFinancialReport> uspFinancialReportDB = null;
        List<USPFinancialReport> uspFinancialReports = new ArrayList<>();
        String monthYearStr = null;
        LocalDate monthYear =null;
        boolean lastDayOfMonth =false;
        try {
            for (USPFinancialReport uspFinancialReport : uspFinancialReportList) {
                LOGGER.info("Processing USP3231 Data :: {}", uspFinancialReport);
                if(StringUtils.isNotBlank(uspFinancialReport.getBob())) {
                    uspFinancialReport.setTrailName(PT3231_EOB);
                    if (uspFinancialReport.getCreatedDate() != null) {
                        monthYearStr = DateUtil.getLocalDateToString(LocalDate.from(uspFinancialReport.getCreatedDate()));
                        monthYear = DateUtil.getLocalDate(monthYearStr, MONTH_YEAR_FORMAT);
                        lastDayOfMonth = isLastDayOfMonth(uspFinancialReport.getCreatedDate().toLocalDate());
                        uspFinancialReport.setMonthYear(monthYear);
                        uspFinancialReport.setMonthYearStr(monthYearStr);
                        uspFinancialReportDB = uspFinancialReportRepository.findByMonthYearStrAndBobAndTrailName(uspFinancialReport.getMonthYearStr(), uspFinancialReport.getBob(), PT3231_EOB);
                    }
                    if (!uspFinancialReportDB.isPresent()) {
                        LOGGER.info("USP3231 Data not found for the month :: {}", monthYearStr);
                        if (lastDayOfMonth) {
                            uspFinancialReport.setIsTxCompleted(1);
                        }
                        uspFinancialReport.setId(null);
                        calculatePercentage(uspFinancialReport);
                        uspFinancialReport.setModifiedBy(USP_FIN_REPORTING_SERVICE);
                        uspFinancialReportRepository.save(uspFinancialReport);

                    } else {
                        LOGGER.info("USP3231Data found for the month :: {}", monthYearStr);
                        addAndUpdateExistingEOBData(uspFinancialReport, uspFinancialReportDB.get());
                        if (lastDayOfMonth) {
                            uspFinancialReportDB.get().setIsTxCompleted(1);
                        }
                        uspFinancialReportRepository.save(uspFinancialReportDB.get());

                    }
                    uspFinancialReports.add(uspFinancialReport);
//                    JSONObject jsonObject = new JSONObject();
//                    jsonObject.put("data", uspFinancialReport);
                    processlog.setAdditionalProperty("record", uspFinancialReport);
                    processlog.setStatus("RECORD_SUCCESS");
                    processlog.setReqFinishTimestamp(new Date(System.currentTimeMillis()).toString());
                    nessLoggerService.publishNesslogsToSplunk(processlog.toString());
                }
            }
//            JSONObject jsonObject = new JSONObject();
//            jsonObject.put("data", uspFinancialReports);
            processlog.setAdditionalProperty("list", uspFinancialReports);
        } catch (Exception e) {
            LOGGER.error("Exception occurred while processing scheduler :: {}", e.getLocalizedMessage());
            processlog.setErrorMessage("Exception occurred while processing PT3231 scheduler");
            throw e;
        }
    }

    private void addAndUpdateExistingEOBData(USPFinancialReport uspFinancialReport, USPFinancialReport uspFinancialReportDB) {
        uspFinancialReportDB.setTotalEobGenerated(uspFinancialReportDB.getTotalEobGenerated() + uspFinancialReport.getTotalEobGenerated());
        uspFinancialReportDB.setTotalEobSuppressed(uspFinancialReportDB.getTotalEobSuppressed() + uspFinancialReport.getTotalEobSuppressed());
        uspFinancialReportDB.setMemberElectionEob(uspFinancialReportDB.getMemberElectionEob() + uspFinancialReport.getMemberElectionEob());
        uspFinancialReportDB.setPolicySettingEob(uspFinancialReportDB.getPolicySettingEob() + uspFinancialReport.getPolicySettingEob());
        uspFinancialReportDB.setTotalEobPrinted(uspFinancialReportDB.getTotalEobPrinted() + uspFinancialReport.getTotalEobPrinted());
        uspFinancialReportDB.setTotalHsGenerated(uspFinancialReportDB.getTotalHsGenerated() + uspFinancialReport.getTotalHsGenerated());
        uspFinancialReportDB.setTotalHsSuppressed(uspFinancialReportDB.getTotalHsSuppressed() + uspFinancialReport.getTotalHsSuppressed());
        uspFinancialReportDB.setMemberElectionHs(uspFinancialReportDB.getMemberElectionHs() + uspFinancialReport.getMemberElectionHs());
        uspFinancialReportDB.setPolicySettingHs(uspFinancialReportDB.getPolicySettingHs() + uspFinancialReport.getPolicySettingHs());
        uspFinancialReportDB.setTotalHsPrinted(uspFinancialReportDB.getTotalHsPrinted() + uspFinancialReport.getTotalHsPrinted());
        uspFinancialReportDB.setTotalCaeEobCount(uspFinancialReportDB.getTotalCaeEobCount() + uspFinancialReport.getTotalCaeEobCount());
        uspFinancialReportDB.setCaeEobMailCount(uspFinancialReportDB.getCaeEobMailCount() + uspFinancialReport.getCaeEobMailCount());
        uspFinancialReportDB.setCaeEobNoEmailCount(uspFinancialReportDB.getCaeEobNoEmailCount() + uspFinancialReport.getCaeEobNoEmailCount());
        uspFinancialReportDB.setHsMemPrint(uspFinancialReportDB.getHsMemPrint() + uspFinancialReport.getHsMemPrint());
        calculatePercentage(uspFinancialReportDB);
    }

    public String downloadBlobFile(StorageBlobCreatedEventData eventData) throws MalformedURLException {
        String fullfilename = "";
        String filename = "";
        try {
            URL aURL = new URL(eventData.url());
            String path = aURL.getPath();
            filename = path.substring(path.lastIndexOf('/') + 1);
            String[] res = path.split("[/]", 3);
            fullfilename = res[2];
            File f = new File(fullfilename);
            String filePath = f.getParentFile().getPath() + File.separator + filename;
            BlobClient blob = blobUtils.getBlobClient(filePath);
            if (blob == null) {
                LOGGER.error("Blob client is null");
                return null;
            } else {
                String csvString = blob.downloadContent().toString();
                LOGGER.info("download completed for the file: {}", filename);
                return csvString;
            }
        } catch (Exception ex) {
            LOGGER.error("Exception occurred in fetching csv file: {} ", ex.getMessage());
            throw ex;
        }
    }

    public List<USPFinancialReport> parsingCsv(String csvString) {
        //read line by line and parse the csv
        double hsSuppPercent = 0.0;
        double eobSuppPercent = 0.0;
        List<USPFinancialReport> uspFinancialReportList = new ArrayList<>();
        Scanner scanner = new Scanner(csvString);
        scanner.nextLine(); // Skip header line
        try {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] fields = line.split(",");
                USPFinancialReport uspeobFinReport = getUSPEOBFinReport(fields);
                if (uspeobFinReport.getTotalEobGenerated() == 0 && uspeobFinReport.getTotalHsGenerated() == 0) {
                    continue;
                } else {
                    hsSuppPercent = getSuppPercentage(uspeobFinReport.getTotalHsSuppressed(), uspeobFinReport.getTotalHsGenerated());
                }
                if (uspeobFinReport.getTotalEobGenerated() == 0 && uspeobFinReport.getTotalHsGenerated() == 0) {
                    continue;
                } else {
                    eobSuppPercent = getSuppPercentage(uspeobFinReport.getTotalEobSuppressed(), uspeobFinReport.getTotalEobGenerated());
                }
                uspeobFinReport.setHsSuppressPercent(hsSuppPercent);
                uspeobFinReport.setEobSuppressPercent(eobSuppPercent);
                uspFinancialReportList.add(uspeobFinReport);
            }
            LOGGER.info("USP3231 Data parsed  Successfully");
        } catch (Exception e) {
            LOGGER.error("Exception occurred while parsing csv file: {} ", e.getMessage());
            throw e;
        } finally {
            scanner.close();
        }
        return uspFinancialReportList;
    }

    private static double getSuppPercentage(double suppressed, double generated) {
        return CalculationUtils.roundOf((suppressed / generated) * 100);

    }

    private void calculatePercentage(USPFinancialReport uspFinancialReportDB){
        double hsSuppPercent = 0.0;
        double eobSuppPercent = 0.0;
        if (uspFinancialReportDB.getTotalEobGenerated() == 0 && uspFinancialReportDB.getTotalHsGenerated() == 0) {
        } else {
            hsSuppPercent = getSuppPercentage(uspFinancialReportDB.getTotalHsSuppressed(), uspFinancialReportDB.getTotalHsGenerated());
        }
        if (uspFinancialReportDB.getTotalEobGenerated() == 0 && uspFinancialReportDB.getTotalHsGenerated() == 0) {
        } else {
            eobSuppPercent = getSuppPercentage(uspFinancialReportDB.getTotalEobSuppressed(), uspFinancialReportDB.getTotalEobGenerated());
        }
        uspFinancialReportDB.setHsSuppressPercent(hsSuppPercent);
        uspFinancialReportDB.setEobSuppressPercent(eobSuppPercent);
        uspFinancialReportDB.setModifiedBy(USP_FIN_REPORTING_SERVICE);
    }

    private static USPFinancialReport getUSPEOBFinReport(String[] fields) {
        USPFinancialReport uspeobFinReport = new USPFinancialReport();
        String dateString = checkNullAndReturn(fields[0]);
        LOGGER.info("Date String: {}", dateString);
        if (!dateString.isEmpty()) {
            LocalDate date = LocalDate.parse(dateString, DateTimeFormatter.ofPattern(DATE_TIME_FORMATTER));
            uspeobFinReport.setCreatedDate(date.atStartOfDay());
            uspeobFinReport.setMonthYear(date);
        }
        uspeobFinReport.setBob(checkNullAndReturn(fields[1]));
        uspeobFinReport.setTotalEobGenerated(Integer.parseInt(checkNullAndReturn(fields[2])));
        uspeobFinReport.setTotalEobSuppressed(Integer.parseInt(checkNullAndReturn(fields[3])));
        uspeobFinReport.setMemberElectionEob(Integer.parseInt(checkNullAndReturn(fields[4])));
        uspeobFinReport.setPolicySettingEob(Integer.parseInt(checkNullAndReturn(fields[5])));
        uspeobFinReport.setTotalEobPrinted(Integer.parseInt(checkNullAndReturn(fields[6])));
        uspeobFinReport.setTotalHsGenerated(Integer.parseInt(checkNullAndReturn(fields[7])));
        uspeobFinReport.setTotalHsSuppressed(Integer.parseInt(checkNullAndReturn(fields[8])));
        uspeobFinReport.setTotalHsGenerated(Integer.parseInt(checkNullAndReturn(fields[9])));
        uspeobFinReport.setPolicySettingHs(Integer.parseInt(checkNullAndReturn(fields[10])));
        uspeobFinReport.setTotalHsPrinted(Integer.parseInt(checkNullAndReturn(fields[11])));
        uspeobFinReport.setTotalCaeEobCount(Integer.parseInt(checkNullAndReturn(fields[12])));
        uspeobFinReport.setCaeEobMailCount(Integer.parseInt(checkNullAndReturn(fields[13])));
        uspeobFinReport.setCaeEobNoEmailCount(Integer.parseInt(checkNullAndReturn(fields[14])));
        uspeobFinReport.setCreatedBy(USP_REPORTING_ONPREM_SERVICE);
        uspeobFinReport.setModifiedBy("");
        return uspeobFinReport;
    }

    private static String checkNullAndReturn(String field) {
        return StringUtils.isNotBlank(field) ?  field.replace("\"", ""):"";
    }

    public boolean isLastDayOfMonth( LocalDate date) {
        return date.equals(date.withDayOfMonth(date.lengthOfMonth()));
    }


    public void updateNewBoB(List<USPFinancialReport> uspFinancialReportList, Processlog processlog){
        try {
            Set<TrailAndBobDetails> trailAndBobDetailsList = trailAndBobRepo.findByTrailNumber(PT3231_EOB);
            if (!CollectionUtils.isEmpty(trailAndBobDetailsList) && !CollectionUtils.isEmpty(uspFinancialReportList)) {

                Map<String, List<USPFinancialReport>> groupedByBob = uspFinancialReportList.stream().filter(uspFinancialReport -> StringUtils.isNotBlank(uspFinancialReport.getBob()))
                        .collect(Collectors.groupingBy(USPFinancialReport::getBob));

                List<String> bobNames = trailAndBobDetailsList.stream().map(TrailAndBobDetails::getBobName).collect(Collectors.toList());

                List<String> newBobList = groupedByBob.keySet().stream().filter(bob -> !bobNames.contains(bob)).collect(Collectors.toList());
                if (!CollectionUtils.isEmpty(newBobList)) {
                    newBobList.forEach(newBob -> {
                        TrailAndBobDetails trailAndBobDetails = new TrailAndBobDetails();
                        trailAndBobDetails.setTrailNumber(PT3231_EOB);
                        trailAndBobDetails.setBobName(newBob);
                        trailAndBobDetails.setIsActive(1);
                        trailAndBobRepo.save(trailAndBobDetails);
                        processlog.setStatus("NEW BOB DETECTED");
                        processlog.setAdditionalProperty("newBob", newBob);
                        processlog.setAdditionalProperty("newBobDate", groupedByBob.get(newBob).stream().map(USPFinancialReport::getCreatedDate).min(LocalDateTime::compareTo).get());
                        sendEmailService.sendEmail(processlog);
                    });
                }
            }
        }catch(Exception e){
            LOGGER.error("Exception occurred while updating new BoB :", e );
            processlog.setErrorMessage("Exception occurred while updating new BoB");
            throw e;
        }

    }


}
