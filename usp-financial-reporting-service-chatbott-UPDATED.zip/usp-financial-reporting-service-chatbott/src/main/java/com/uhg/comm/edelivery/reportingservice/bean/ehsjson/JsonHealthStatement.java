package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "documentSetId", "documentSetInfo" })
@Generated("jsonschema2pojo")
public class JsonHealthStatement {

	/**
	 * (Required)
	 */
	@JsonProperty("documentSetId")
	private String documentSetId;
	/**
	 * (Required)
	 */
	@JsonProperty("documentSetInfo")
	private List<DocumentSetInfo> documentSetInfo;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

	/**
	 * (Required)
	 */
	@JsonProperty("documentSetId")
	public String getDocumentSetId() {
		return documentSetId;
	}

	/**
	 * (Required)
	 */
	@JsonProperty("documentSetId")
	public void setDocumentSetId(String documentSetId) {
		this.documentSetId = documentSetId;
	}

	/**
	 * (Required)
	 */
	@JsonProperty("documentSetInfo")
	public List<DocumentSetInfo> getDocumentSetInfo() {
		return documentSetInfo;
	}

	/**
	 * (Required)
	 */
	@JsonProperty("documentSetInfo")
	public void setDocumentSetInfo(List<DocumentSetInfo> documentSetInfo) {
		this.documentSetInfo = documentSetInfo;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}
