package com.uhg.comm.edelivery.reportingservice.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "hs_suppr_cost_report", schema = "edelivery")
@Data
@EqualsAndHashCode
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class HSSuppCostReport {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "hs_suppr_cost_report_id_seq")
    @SequenceGenerator(name = "hs_suppr_cost_report_id_seq", sequenceName = "hs_suppr_cost_report_id_seq", schema = "edelivery", allocationSize = 1)
    @Column(name = "id", updatable = false, nullable = false)
    private Integer id;

    @Column(name = "trail_name")
    private String trailName;

    @Column(name = "month_year")
    private LocalDate monthYear;

    @Column(name = "month_year_str")
    private String month;

    @Column(name = "bob")
    private String bob;

    @Column(name = "postage_cost")
    private double postageCost;

    @Column(name = "print_cost")
    private double printingCost;

    @Column(name = "stmt_printed")
    private double statementPrinted;

    @Column(name = "member_election_hs_supp")
    private double memberElectionHSSupp;

    @Column(name = "policy_setting_hs_supp")
    private double policySettingHSSupp;

    @Column(name = "mem_print")
    private double memPrint;

    @Column(name = "total_stmt_suppressed")
    private double totalStmtSuppressed;

    @Column(name = "total_stmt_generated")
    private double totalStmtGenerated;

    @Column(name = "total_print_postage_cost")
    private double totalPrintPostageCost;

    @Column(name = "hs_suppress_percent")
    private double hsSuppressPercent;

    @Column(name = "cost_per_stmt")
    private double costPerStmt;

    @Column(name = "total_sheets")
    private double totalSheets;

    @Column(name = "sheets_per_printed_stmt")
    private double sheetsPerPrintedStmt;

    @Column(name = "total_claims")
    private double totalClaims;

    @Column(name = "created_by", updatable = false)
    private String createdBy;

    @CreationTimestamp
    @Column(name = "created_date", updatable = false)
    private LocalDateTime createdDate;

    @Column(name = "modified_by")
    private String modifiedBy;

    @UpdateTimestamp
    @Column(name = "modified_date")
    private LocalDateTime modifiedDate;

    @Column(name = "is_completed")
    private int isCompleted;

    @Column(name = "is_tx_completed")
    private int isTxCompleted;


}
