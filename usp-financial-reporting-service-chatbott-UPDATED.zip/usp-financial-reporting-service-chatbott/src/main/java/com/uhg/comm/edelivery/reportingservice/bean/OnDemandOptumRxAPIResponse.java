package com.uhg.comm.edelivery.reportingservice.bean;

import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data
public class OnDemandOptumRxAPIResponse {

    private String jobId;
    private String uniqueId;
    private String timestamp;
    private String status;
    private String message;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
}
