package com.uhg.comm.edelivery.reportingservice.bean;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ApiResponse {
	
	boolean result;
	String message;

}
