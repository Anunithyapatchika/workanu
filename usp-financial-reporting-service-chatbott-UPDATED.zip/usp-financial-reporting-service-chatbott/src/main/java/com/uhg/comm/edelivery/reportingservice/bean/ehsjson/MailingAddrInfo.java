package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "mailingAddrNm", "addr1", "addr2", "city", "st", "zipCd" })
@Generated("jsonschema2pojo")
public class MailingAddrInfo {

	@JsonProperty("mailingAddrNm")
	private String mailingAddrNm;
	@JsonProperty("addr1")
	private String addr1;
	@JsonProperty("addr2")
	private String addr2;
	@JsonProperty("city")
	private String city;
	@JsonProperty("st")
	private String st;
	@JsonProperty("zipCd")
	private String zipCd;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("mailingAddrNm")
	public String getMailingAddrNm() {
		return mailingAddrNm;
	}

	@JsonProperty("mailingAddrNm")
	public void setMailingAddrNm(String mailingAddrNm) {
		this.mailingAddrNm = mailingAddrNm;
	}

	@JsonProperty("addr1")
	public String getAddr1() {
		return addr1;
	}

	@JsonProperty("addr1")
	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}

	@JsonProperty("addr2")
	public String getAddr2() {
		return addr2;
	}

	@JsonProperty("addr2")
	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}

	@JsonProperty("city")
	public String getCity() {
		return city;
	}

	@JsonProperty("city")
	public void setCity(String city) {
		this.city = city;
	}

	@JsonProperty("st")
	public String getSt() {
		return st;
	}

	@JsonProperty("st")
	public void setSt(String st) {
		this.st = st;
	}

	@JsonProperty("zipCd")
	public String getZipCd() {
		return zipCd;
	}

	@JsonProperty("zipCd")
	public void setZipCd(String zipCd) {
		this.zipCd = zipCd;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(MailingAddrInfo.class.getName()).append('@')
				.append(Integer.toHexString(System.identityHashCode(this))).append('[');
		sb.append("mailingAddrNm");
		sb.append('=');
		sb.append(((this.mailingAddrNm == null) ? "<null>" : this.mailingAddrNm));
		sb.append(',');
		sb.append("addr1");
		sb.append('=');
		sb.append(((this.addr1 == null) ? "<null>" : this.addr1));
		sb.append(',');
		sb.append("addr2");
		sb.append('=');
		sb.append(((this.addr2 == null) ? "<null>" : this.addr2));
		sb.append(',');
		sb.append("city");
		sb.append('=');
		sb.append(((this.city == null) ? "<null>" : this.city));
		sb.append(',');
		sb.append("st");
		sb.append('=');
		sb.append(((this.st == null) ? "<null>" : this.st));
		sb.append(',');
		sb.append("zipCd");
		sb.append('=');
		sb.append(((this.zipCd == null) ? "<null>" : this.zipCd));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
