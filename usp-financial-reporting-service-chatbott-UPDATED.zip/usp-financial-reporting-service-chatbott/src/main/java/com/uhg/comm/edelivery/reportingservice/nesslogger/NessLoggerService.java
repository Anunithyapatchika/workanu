package com.uhg.comm.edelivery.reportingservice.nesslogger;

import com.azure.security.keyvault.secrets.SecretClient;
import com.optum.eis.event.model.severity;
import com.optum.eis.kraken.core.NessLog;
import com.optum.eis.kraken.eventhubs.producers.NessEventHubProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.Properties;

import static com.uhg.comm.edelivery.reportingservice.constants.AzureVaultKey.LOGGER_STRING;

@Service
public class NessLoggerService {

	private static final Logger LOGGER = LoggerFactory.getLogger(NessLoggerService.class);

	private final SecretClient secretClient;

	@Autowired
	NessLoggerConfig nessLoggerConfig;

    public NessLoggerService(SecretClient secretClient) {
        this.secretClient = secretClient;
    }

    @Async
	public void publishNesslogsToSplunk(String message) {
		try {
			Properties properties = new Properties();
			properties = nessLoggerConfig.loadRequiredFields(properties);
			NessLog.NessLogBuilder logBuilder = new NessLog.NessLogBuilder().setSeverity(severity.INFO)
					.setTags("sample-tag");

			NessEventHubProducer.NessEventHubProducerBuilder eventHubProducerBuilder = new NessEventHubProducer.NessEventHubProducerBuilder()
					.setConnectionString(secretClient.getSecret(LOGGER_STRING).getValue());
			NessLog firstLog = logBuilder.setRequiredFields(properties).setMsg(message).buildLog();
			NessEventHubProducer eventHubProducer = eventHubProducerBuilder.buildNessProducer();
			eventHubProducer.publishNessLogs(firstLog);
			eventHubProducer.closeNessProducer();
		} catch (Exception e) {
			LOGGER.error("Error while write Process Log to Splunk ERROR: {}", e.getMessage());
		}
	}
}