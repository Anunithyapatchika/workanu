package com.uhg.comm.edelivery.reportingservice.model;

import lombok.Data;
import java.util.List;

@Data
public class FieldMapping {
    private String filepath_field;
    private String title_field;
    private List<String> vector_fields;
}