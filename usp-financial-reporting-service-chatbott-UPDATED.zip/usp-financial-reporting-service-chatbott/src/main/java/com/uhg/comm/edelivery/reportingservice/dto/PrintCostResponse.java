package com.uhg.comm.edelivery.reportingservice.dto;

import lombok.Data;

import java.util.List;

@Data
public class PrintCostResponse {

    private String date;
    private String trailNumber;
    private List<PrintCostResponseItems> items;
}
