package com.uhg.comm.edelivery.reportingservice.dto;

import lombok.Data;

@Data
public class EobReportItemDto {
    private String bob;
    private double totalEobsGenerated;
    private double totalEobsSuppressed;
    private double totalEobsSuppressedSubscriberElection;
    private double totalEobsSuppressedPolicySetting;
    private double totalEobsPrinted;
    private double eobSuppressedPercent;
}