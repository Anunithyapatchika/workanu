package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "legalEntityTxt", "legalEntityLogo", "docLogo1", "docLogo2", "mbrPortalUrl" })
@Generated("jsonschema2pojo")
public class BrandingInfo {

	@JsonProperty("legalEntityTxt")
	private String legalEntityTxt;
	@JsonProperty("legalEntityLogo")
	private String legalEntityLogo;
	@JsonProperty("docLogo1")
	private String docLogo1;
	@JsonProperty("docLogo2")
	private String docLogo2;
	@JsonProperty("mbrPortalUrl")
	private String mbrPortalUrl;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("legalEntityTxt")
	public String getLegalEntityTxt() {
		return legalEntityTxt;
	}

	@JsonProperty("legalEntityTxt")
	public void setLegalEntityTxt(String legalEntityTxt) {
		this.legalEntityTxt = legalEntityTxt;
	}

	@JsonProperty("legalEntityLogo")
	public String getLegalEntityLogo() {
		return legalEntityLogo;
	}

	@JsonProperty("legalEntityLogo")
	public void setLegalEntityLogo(String legalEntityLogo) {
		this.legalEntityLogo = legalEntityLogo;
	}

	@JsonProperty("docLogo1")
	public String getDocLogo1() {
		return docLogo1;
	}

	@JsonProperty("docLogo1")
	public void setDocLogo1(String docLogo1) {
		this.docLogo1 = docLogo1;
	}

	@JsonProperty("docLogo2")
	public String getDocLogo2() {
		return docLogo2;
	}

	@JsonProperty("docLogo2")
	public void setDocLogo2(String docLogo2) {
		this.docLogo2 = docLogo2;
	}

	@JsonProperty("mbrPortalUrl")
	public String getMbrPortalUrl() {
		return mbrPortalUrl;
	}

	@JsonProperty("mbrPortalUrl")
	public void setMbrPortalUrl(String mbrPortalUrl) {
		this.mbrPortalUrl = mbrPortalUrl;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(BrandingInfo.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this)))
				.append('[');
		sb.append("legalEntityTxt");
		sb.append('=');
		sb.append(((this.legalEntityTxt == null) ? "<null>" : this.legalEntityTxt));
		sb.append(',');
		sb.append("legalEntityLogo");
		sb.append('=');
		sb.append(((this.legalEntityLogo == null) ? "<null>" : this.legalEntityLogo));
		sb.append(',');
		sb.append("docLogo1");
		sb.append('=');
		sb.append(((this.docLogo1 == null) ? "<null>" : this.docLogo1));
		sb.append(',');
		sb.append("docLogo2");
		sb.append('=');
		sb.append(((this.docLogo2 == null) ? "<null>" : this.docLogo2));
		sb.append(',');
		sb.append("mbrPortalUrl");
		sb.append('=');
		sb.append(((this.mbrPortalUrl == null) ? "<null>" : this.mbrPortalUrl));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
