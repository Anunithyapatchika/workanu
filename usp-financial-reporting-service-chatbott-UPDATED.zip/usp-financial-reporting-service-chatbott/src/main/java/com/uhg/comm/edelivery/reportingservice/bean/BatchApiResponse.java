package com.uhg.comm.edelivery.reportingservice.bean;

import com.fasterxml.jackson.annotation.*;
import lombok.Data;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "UniqueId", "Status" })
@Generated("jsonschema2pojo")
@Data
public class BatchApiResponse {

	@JsonProperty("UniqueId")
	private String uniqueId;
	@JsonProperty("Status")
	private String status;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("UniqueId")
	public String getUniqueId() {
		return uniqueId;
	}

	@JsonProperty("UniqueId")
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	@JsonProperty("Status")
	public String getStatus() {
		return status;
	}

	@JsonProperty("Status")
	public void setStatus(String status) {
		this.status = status;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}
