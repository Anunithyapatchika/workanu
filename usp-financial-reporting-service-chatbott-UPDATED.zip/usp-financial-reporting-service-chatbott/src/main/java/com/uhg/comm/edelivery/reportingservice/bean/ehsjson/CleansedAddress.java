package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import lombok.Data;

@Data
public class CleansedAddress {

	private String statementNum;
	private String recipientFirstName;
	private String recipientLastName;
	private String recipientAddress1;
	private String recipientAddress2;
	private String recipientAddress3;
	private String recipientAddress4;
	private String recipientAddress5;
	private String recipientCity;
	private String recipientState;
	private String recipientZip;
	private String imbIndicator;
	private String cassIndicator;
	private String updateIndicator;
	private String coaFlag;

}
