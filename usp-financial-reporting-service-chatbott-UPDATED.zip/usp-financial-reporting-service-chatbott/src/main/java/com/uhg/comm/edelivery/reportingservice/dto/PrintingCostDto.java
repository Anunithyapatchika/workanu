package com.uhg.comm.edelivery.reportingservice.dto;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

/**
 * DTO class for Printing Cost Report.
 *
 * @author Madhav Kulkarni
 */
@Data
@ToString
@Builder
public class PrintingCostDto {

    @JsonProperty("id")
    private int id;

    @JsonProperty("trail_name")
    private String trailName;

    @JsonProperty("month")
    private String month;

    @JsonProperty("bob")
    private String bob;

    @JsonProperty("image_count")
    private double imageCount;

    @JsonProperty("envelop_count")
    private double envelopCount;

    @JsonProperty("paper_count")
    private double paperCount;

    @JsonProperty("print_exp_cost")
    private double printExpenseCost;

    @JsonProperty("postage_cost")
    private double postageCost;

    @JsonProperty("total_expense")
    private double totalExpense;

    @JsonProperty("image_per_envelop")
    private double imagePerEnvelop;

    @JsonProperty("print_exp_per_image")
    private double printExpPerImage;

    @JsonProperty("print_exp_per_envelop")
    private double printExpPerEnvelop;

    @JsonProperty("postage_exp_per_envelop")
    private double postageExpPerEnvelop;

    @JsonProperty("total_exp_per_envelop")
    private double totalExpPerEnvelop;

    @JsonProperty("user_id")
    private String userId;
}
