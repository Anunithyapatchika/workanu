package com.uhg.comm.edelivery.reportingservice.constants;

public class AzureVaultKey {
    private AzureVaultKey() {
        throw new IllegalStateException("Constant class for the Azure Vault Keys");
    }

    public static final String STORAGE_ACC_KEY = "STORAGE-ACC-KEY";
    public static final String LOGGER_STRING = "LOGGER-STRING";
    public static final String STORAGE_ACC_KEY_EXT = "STORAGE-ACC-KEY-EXT";
    public static final String KAFKA_JAAS_CONFIG_EH2 = "KAFKA-JAAS-CONFIG-EH2";
    public static final String EDEL_API_CLIENTID = "EDEL-API-CLIENTID";
    public static final String EDEL_API_CLIENTSECRET = "EDEL-API-CLIENTSECRET";
    public static final String OPENAI_API_KEY = "OPENAI-API-KEY";
    public static final String AI_STORAGE_ACC_KEY = "AI-STORAGE-ACC-KEY";

}
