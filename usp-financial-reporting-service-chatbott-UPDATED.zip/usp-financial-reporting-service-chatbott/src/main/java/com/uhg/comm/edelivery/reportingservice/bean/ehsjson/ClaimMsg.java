package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "claimMsgOrder", "claimMsgTxt", "claimMsgId", "claimDispLocation" })
@Generated("jsonschema2pojo")
public class ClaimMsg {

	@JsonProperty("claimMsgOrder")
	private String claimMsgOrder;
	@JsonProperty("claimMsgTxt")
	private String claimMsgTxt;
	@JsonProperty("claimMsgId")
	private String claimMsgId;
	@JsonProperty("claimDispLocation")
	private String claimDispLocation;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("claimMsgOrder")
	public String getClaimMsgOrder() {
		return claimMsgOrder;
	}

	@JsonProperty("claimMsgOrder")
	public void setClaimMsgOrder(String claimMsgOrder) {
		this.claimMsgOrder = claimMsgOrder;
	}

	@JsonProperty("claimMsgTxt")
	public String getClaimMsgTxt() {
		return claimMsgTxt;
	}

	@JsonProperty("claimMsgTxt")
	public void setClaimMsgTxt(String claimMsgTxt) {
		this.claimMsgTxt = claimMsgTxt;
	}

	@JsonProperty("claimMsgId")
	public String getClaimMsgId() {
		return claimMsgId;
	}

	@JsonProperty("claimMsgId")
	public void setClaimMsgId(String claimMsgId) {
		this.claimMsgId = claimMsgId;
	}

	@JsonProperty("claimDispLocation")
	public String getClaimDispLocation() {
		return claimDispLocation;
	}

	@JsonProperty("claimDispLocation")
	public void setClaimDispLocation(String claimDispLocation) {
		this.claimDispLocation = claimDispLocation;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(ClaimMsg.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this)))
				.append('[');
		sb.append("claimMsgOrder");
		sb.append('=');
		sb.append(((this.claimMsgOrder == null) ? "<null>" : this.claimMsgOrder));
		sb.append(',');
		sb.append("claimMsgTxt");
		sb.append('=');
		sb.append(((this.claimMsgTxt == null) ? "<null>" : this.claimMsgTxt));
		sb.append(',');
		sb.append("claimMsgId");
		sb.append('=');
		sb.append(((this.claimMsgId == null) ? "<null>" : this.claimMsgId));
		sb.append(',');
		sb.append("claimDispLocation");
		sb.append('=');
		sb.append(((this.claimDispLocation == null) ? "<null>" : this.claimDispLocation));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
