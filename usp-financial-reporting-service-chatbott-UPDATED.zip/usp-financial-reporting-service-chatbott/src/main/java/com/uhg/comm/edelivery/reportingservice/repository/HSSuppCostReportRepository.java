package com.uhg.comm.edelivery.reportingservice.repository;

import com.uhg.comm.edelivery.reportingservice.model.HSSuppCostReport;
import com.uhg.comm.edelivery.reportingservice.model.USPFinancialReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface HSSuppCostReportRepository extends JpaRepository<HSSuppCostReport, Integer> {


    @Query("SELECT h FROM HSSuppCostReport h WHERE h.trailName = ?1 AND h.bob = ?2 AND h.month = ?3")
    Optional<HSSuppCostReport> findByTrailNameBobAndMonth(String trailName, String bob, String month);

    @Query("SELECT h FROM HSSuppCostReport h WHERE h.trailName = ?1 AND h.bob = ?2 AND h.month = ?3 ")
    Optional<HSSuppCostReport> findByTrailNameBobAndMonthAndNotCompleted(String trailName, String bob, String month);

    @Query("SELECT h FROM HSSuppCostReport h WHERE h.trailName = ?1 AND h.isTxCompleted = ?2 AND h.month = ?3 ")
    List<HSSuppCostReport> findByTrailNameAndMonthAndNotTxCompleted(String trailName, int isTxCompleted, String month);

    @Query("SELECT h FROM HSSuppCostReport h WHERE h.trailName = :trailNumber AND h.monthYear BETWEEN :startDate AND :endDate ORDER BY h.monthYear ASC")
    List<HSSuppCostReport> findByTrailNumberAndBetweenMonthYearStr(
            @Param("trailNumber") String trailNumber,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate);

    @Query(value = "SELECT u.bob, u.month_year_str, u.is_completed, u.is_tx_completed " +
            "FROM edelivery.hs_suppr_cost_report u WHERE u.trail_name = :trailName AND u.is_tx_completed = 0 " +
            "AND u.month_year BETWEEN :startDate AND :endDate ORDER BY u.month_year ASC", nativeQuery = true)
    List<Object[]> getDetailsFromDB(@Param("trailName") String trailName, @Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);

}
