package com.uhg.comm.edelivery.reportingservice.service;

import com.uhg.comm.edelivery.reportingservice.bean.GetFieldValues;
import com.uhg.comm.edelivery.reportingservice.constants.Constants;
import com.uhg.comm.edelivery.reportingservice.dto.*;
import com.uhg.comm.edelivery.reportingservice.exception.USPException;
import com.uhg.comm.edelivery.reportingservice.model.PrintingCostReport;
import com.uhg.comm.edelivery.reportingservice.model.USPFinancialReport;
import com.uhg.comm.edelivery.reportingservice.repository.PrintingCostReportRepository;
import com.uhg.comm.edelivery.reportingservice.repository.USPFinancialReportRepository;
import com.uhg.comm.edelivery.reportingservice.util.CalculationUtils;
import com.uhg.comm.edelivery.reportingservice.util.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static com.uhg.comm.edelivery.reportingservice.constants.Constants.USP_FIN_REPORTING_SERVICE;
import static com.uhg.comm.edelivery.reportingservice.constants.Constants.USP_REPORTING_UI_SERVICE;

@Service
@Slf4j
public class USPFinancialReportService {

    @Autowired
    private USPFinancialReportRepository uspFinancialReportRepository;

    @Autowired
    private PrintingCostReportService printingCostReportService;

    @Autowired
    private PrintingCostReportRepository printingCostReportRepository;

    public FinancialReportResponseDto getFinancialReport(String trailNumber, String startDate, String endDate) {
        LocalDate start = DateUtil.getLocalDate(startDate, Constants.MONTH_YEAR_FORMAT);
        LocalDate end = DateUtil.getLocalDate(endDate, Constants.MONTH_YEAR_FORMAT);
        LocalDate endDateWithMonth = end.withDayOfMonth(end.getMonth().length(end.isLeapYear()));
        List<USPFinancialReport> reports = uspFinancialReportRepository.findByTrailNumberAndBetweenMonthYearStr(
                trailNumber, start, endDateWithMonth); // Fetches the reports from the repository.
        List<PrintCostResponse> printCostResponseList = printingCostReportService.getPrintCostReportResponse(trailNumber, start, endDateWithMonth, reports);
        Map<String, List<USPFinancialReport>> groupedByMonthYear = reports.stream()
                .collect(Collectors.groupingBy(USPFinancialReport::getMonthYearStr, LinkedHashMap::new, Collectors.toList())); // Groups the reports by month and year.
        List<EobReportDto> eobReports = new ArrayList<>(); // Initializes a list to hold EOB reports.
        List<HSReportDto> hsReportsList = new ArrayList<>(); // Initializes a list to hold EOB reports.
        List<CaeReportDto> caeReports = new ArrayList<>(); // Initializes a list to hold CAE reports.
        List<SuppressionChgResponse> suppressionChgResponses = new ArrayList<>(); // Initializes a list to hold change EOB reports.
        // Iterates over the grouped reports


//        if(!CollectionUtils.isEmpty(printCostResponseList)) {
            groupedByMonthYear.forEach((monthYear, reportList) -> {
                EobReportDto eobReport = new EobReportDto(); // Creates a new EOB report DTO.
                eobReport.setDate(monthYear); // Sets the date for the EOB report.
                eobReport.setTrailNumber(trailNumber); // Sets the trail number for the EOB report.
                List<EobReportItemDto> eobItems = reportList.stream().map(USPFinancialReportService::getEobReportItemDto).collect(Collectors.toList()); // Maps the reports to EOB report items
                // Calculate Monthly Total
                EobReportItemDto monthlyTotal = getEobReportItemDtoForMonthlyTotal(eobItems);
                eobItems.add(monthlyTotal); // Adds the monthly total to the EOB items.
                eobReport.setItems(eobItems); // Sets the items for the EOB report.
                eobReports.add(eobReport); // Adds the EOB report to the list.
            });

            groupedByMonthYear.forEach((monthYear, reportList) -> {
                HSReportDto hsReport = new HSReportDto();
                hsReport.setDate(monthYear);
                hsReport.setTrailNumber(trailNumber);
                List<HSReportItemsDto> hsItems = reportList.stream().map(USPFinancialReportService::getHSReportItemsDto)
                        .collect(Collectors.toList());

                HSReportItemsDto monthlyTotal = getHsReportItemsDtoForMonthlyTotal(hsItems);
                hsItems.add(monthlyTotal); // Adds the monthly total to the EOB items.
                hsReport.setItems(hsItems); // Sets the items for the EOB report.
                hsReportsList.add(hsReport); // Adds the EOB report to the list.
            });

            groupedByMonthYear.forEach((monthYear, reportList) -> {
                CaeReportDto caeReport = new CaeReportDto();
                caeReport.setDate(monthYear);
                caeReport.setTrailNumber(trailNumber);
                List<CaeReportItemDto> caeItems = reportList.stream().map(USPFinancialReportService::getCaeReportItemDto)
                        .collect(Collectors.toList()); // Iterates over the grouped reports for CAE.

                // Calculate Monthly Total for CAE
                CaeReportItemDto caeMonthlyTotal = new CaeReportItemDto();
                caeMonthlyTotal.setBob("Monthly Total");
                caeMonthlyTotal.setTotalCaeSuppressionEobsGenerated(caeItems.stream().mapToDouble(CaeReportItemDto::getTotalCaeSuppressionEobsGenerated).sum());
                caeMonthlyTotal.setCaeSuppressionEobsWithEmail(caeItems.stream().mapToDouble(CaeReportItemDto::getCaeSuppressionEobsWithEmail).sum());
                caeMonthlyTotal.setCaeSuppressionEobsNoEmail(caeItems.stream().mapToDouble(CaeReportItemDto::getCaeSuppressionEobsNoEmail).sum());
                caeItems.add(caeMonthlyTotal);
                caeReport.setItems(caeItems);
                caeReports.add(caeReport);
            });

        groupedByMonthYear.forEach((monthYear, reportList) -> {
            SuppressionChgResponse suppressionChgResponse = new SuppressionChgResponse();
            suppressionChgResponse.setDate(monthYear);
            suppressionChgResponse.setTrailNumber(trailNumber);
            List<SuppressionChgResponseItem> suppressionChgResponseItems = reportList.stream().map(USPFinancialReportService::getSuppressionChgResponseItem)
                    .collect(Collectors.toList()); // Iterates over the grouped reports for CAE.

            // Calculate Monthly Total for CAE
            SuppressionChgResponseItem chgMonthlyTotal = new SuppressionChgResponseItem();
            chgMonthlyTotal.setBob("Monthly Total");
            chgMonthlyTotal.setOldEOBPrint(suppressionChgResponseItems.stream().mapToDouble(SuppressionChgResponseItem::getOldEOBPrint).sum());
            chgMonthlyTotal.setOldEOBSuppress(suppressionChgResponseItems.stream().mapToDouble(SuppressionChgResponseItem::getOldEOBSuppress).sum());
            chgMonthlyTotal.setOldEOBAffected(suppressionChgResponseItems.stream().mapToDouble(SuppressionChgResponseItem::getOldEOBAffected).sum());
            suppressionChgResponseItems.add(chgMonthlyTotal);
            suppressionChgResponse.setItems(suppressionChgResponseItems);
            suppressionChgResponses.add(suppressionChgResponse);
        });

//        }else{
//            return new FinancialReportResponseDto();
//        }

        return getFinancialReportResponseDto(trailNumber, startDate, endDate, eobReports, caeReports, hsReportsList, printCostResponseList, suppressionChgResponses);
    }

    @NotNull
    private static HSReportItemsDto getHsReportItemsDtoForMonthlyTotal(List<HSReportItemsDto> hsItems) {
        HSReportItemsDto monthlyTotal = new HSReportItemsDto(); // Creates a new EOB report item for the monthly total.
        monthlyTotal.setBob("Monthly Total"); // Sets the bob field to "Monthly Total".

        BigDecimal totalGenerated = BigDecimal.valueOf(hsItems.stream().mapToDouble(HSReportItemsDto::getTotalHsGenerated).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalSuppressed = BigDecimal.valueOf(hsItems.stream().mapToDouble(HSReportItemsDto::getTotalHsSuppressed).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal memberElectionSuppress = BigDecimal.valueOf(hsItems.stream().mapToDouble(HSReportItemsDto::getTotalHsSuppressedSubscriberElection).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal policySettingSuppress = BigDecimal.valueOf(hsItems.stream().mapToDouble(HSReportItemsDto::getTotalHsSuppressedPolicySetting).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalPrinted = BigDecimal.valueOf(hsItems.stream().mapToDouble(HSReportItemsDto::getTotalHsPrinted).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal hsSuppressedPercent = BigDecimal.valueOf(hsItems.stream().mapToDouble(HSReportItemsDto::getHsSuppressedPercent).average().orElse(0.0)).setScale(2, RoundingMode.HALF_UP);

        monthlyTotal.setTotalHsGenerated(totalGenerated.doubleValue()); // Calculates the total EOBs generated.
        monthlyTotal.setTotalHsSuppressed(totalSuppressed.doubleValue());
        monthlyTotal.setTotalHsSuppressedSubscriberElection(memberElectionSuppress.doubleValue());
        monthlyTotal.setTotalHsSuppressedPolicySetting(policySettingSuppress.doubleValue());
        monthlyTotal.setTotalHsPrinted(totalPrinted.doubleValue());
        monthlyTotal.setHsSuppressedPercent(CalculationUtils.roundOf((monthlyTotal.getTotalHsSuppressed() / monthlyTotal.getTotalHsGenerated()) * 100));
        return monthlyTotal;
    }

    private static EobReportItemDto getEobReportItemDtoForMonthlyTotal(List<EobReportItemDto> eobItems) {
        EobReportItemDto monthlyTotal = new EobReportItemDto();
        monthlyTotal.setBob("Monthly Total");

        BigDecimal totalEobsGenerated = BigDecimal.valueOf(eobItems.stream().mapToDouble(EobReportItemDto::getTotalEobsGenerated).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalEobsSuppressed = BigDecimal.valueOf(eobItems.stream().mapToDouble(EobReportItemDto::getTotalEobsSuppressed).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal memberElectionEobSuppress = BigDecimal.valueOf(eobItems.stream().mapToDouble(EobReportItemDto::getTotalEobsSuppressedSubscriberElection).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal policySettingEobSuppress = BigDecimal.valueOf(eobItems.stream().mapToDouble(EobReportItemDto::getTotalEobsSuppressedPolicySetting).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal totalEobPrinted = BigDecimal.valueOf(eobItems.stream().mapToDouble(EobReportItemDto::getTotalEobsPrinted).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal eobSuppressedPercent = BigDecimal.valueOf(eobItems.stream().mapToDouble(EobReportItemDto::getEobSuppressedPercent).average().orElse(0.0)).setScale(2, RoundingMode.HALF_UP);

        monthlyTotal.setTotalEobsGenerated(totalEobsGenerated.doubleValue());
        monthlyTotal.setTotalEobsSuppressed(totalEobsSuppressed.doubleValue());
        monthlyTotal.setTotalEobsSuppressedSubscriberElection(memberElectionEobSuppress.doubleValue());
        monthlyTotal.setTotalEobsSuppressedPolicySetting(policySettingEobSuppress.doubleValue());
        monthlyTotal.setTotalEobsPrinted(totalEobPrinted.doubleValue());
        monthlyTotal.setEobSuppressedPercent(CalculationUtils.roundOf((monthlyTotal.getTotalEobsSuppressed() /  monthlyTotal.getTotalEobsGenerated()) * 100));

        return monthlyTotal;
    }

    private static FinancialReportResponseDto getFinancialReportResponseDto(String trailNumber, String startDate,
                                                                            String endDate,
                                                                            List<EobReportDto> eobReports, List<CaeReportDto> caeReports,
                                                                            List<HSReportDto> hsReportsList, List<PrintCostResponse> printCostResponseList,
                                                                            List<SuppressionChgResponse> suppressionChgResponseList) {
        List<EobReportDto> finalEobReports = new ArrayList<>(eobReports);
        List<HSReportDto> finalHsReports = new ArrayList<>(hsReportsList);
        List<CaeReportDto> finalCaeReports = new ArrayList<>(caeReports);
        List<PrintCostResponse> finalPrintCostReports = new ArrayList<>(printCostResponseList);
        List<SuppressionChgResponse> finalSuppressionChgResponses = new ArrayList<>(suppressionChgResponseList);

        // Calculate Period Total for all selected dates if there are multiple dates and more than one object
        if (startDate != null && endDate != null && !startDate.equals(endDate)) {
            if (eobReports.size() > 1) {
                EobReportDto periodTotalEobReport = new EobReportDto();
                periodTotalEobReport.setDate("Period Total");
                periodTotalEobReport.setTrailNumber(trailNumber);
                List<EobReportItemDto> periodTotalEobItems = eobReports.stream()
                        .flatMap(eobReport -> eobReport.getItems().stream())
                        .filter(Objects::nonNull)
                        .collect(Collectors.groupingBy(EobReportItemDto::getBob))
                        .entrySet().stream()
                        .map(entry -> {
                            String bob = entry.getKey();
                            List<EobReportItemDto> items = entry.getValue();
                            return getEobReportItemDtoForPeriodTotal(bob, items);
                        }).collect(Collectors.toList());
                List<EobReportItemDto> filteredItems = periodTotalEobItems.stream().filter(p -> !"Total".equalsIgnoreCase(p.getBob())).collect(Collectors.toList());
                List<EobReportItemDto> itemTotal = periodTotalEobItems.stream().filter(p -> "Total".equalsIgnoreCase(p.getBob())).collect(Collectors.toList());
                periodTotalEobItems.clear();
                periodTotalEobItems.addAll(filteredItems);
                periodTotalEobItems.addAll(itemTotal);
                periodTotalEobReport.setItems(periodTotalEobItems);
                finalEobReports.add(periodTotalEobReport);
            }

            if (caeReports.size() > 1) {
                CaeReportDto periodTotalCaeReport = new CaeReportDto();
                periodTotalCaeReport.setDate("Period Total");
                periodTotalCaeReport.setTrailNumber(trailNumber);
                List<CaeReportItemDto> periodTotalCaeItems = caeReports.stream()
                        .flatMap(caeReport -> caeReport.getItems().stream())
                        .filter(Objects::nonNull)
                        .collect(Collectors.groupingBy(CaeReportItemDto::getBob))
                        .entrySet().stream()
                        .map(entry -> {
                            String bob = entry.getKey();
                            List<CaeReportItemDto> items = entry.getValue();
                            return getCaeReportItemDtoForPeriodTotal(bob, items);
                        }).collect(Collectors.toList());
                List<CaeReportItemDto> filteredItems = periodTotalCaeItems.stream().filter(p -> !"Total".equalsIgnoreCase(p.getBob())).collect(Collectors.toList());
                List<CaeReportItemDto> itemTotal = periodTotalCaeItems.stream().filter(p -> "Total".equalsIgnoreCase(p.getBob())).collect(Collectors.toList());
                periodTotalCaeItems.clear();
                periodTotalCaeItems.addAll(filteredItems);
                periodTotalCaeItems.addAll(itemTotal);
                periodTotalCaeReport.setItems(periodTotalCaeItems);
                finalCaeReports.add(periodTotalCaeReport);
            }

            if (hsReportsList.size() > 1) {
                HSReportDto periodTotalHsReport = new HSReportDto();
                periodTotalHsReport.setDate("Period Total");
                periodTotalHsReport.setTrailNumber(trailNumber);
                List<HSReportItemsDto> periodTotalHsItems = hsReportsList.stream()
                        .flatMap(hsReport -> hsReport.getItems().stream())
                        .filter(Objects::nonNull)
                        .collect(Collectors.groupingBy(HSReportItemsDto::getBob))
                        .entrySet().stream()
                        .map(entry -> {
                            String bob = entry.getKey();
                            List<HSReportItemsDto> items = entry.getValue();
                            return getHSReportItemsDtoForPeriodTotal(bob, items);
                        }).collect(Collectors.toList());
                List<HSReportItemsDto> filteredItems = periodTotalHsItems.stream().filter(p -> !"Total".equalsIgnoreCase(p.getBob())).collect(Collectors.toList());
                List<HSReportItemsDto> itemTotal = periodTotalHsItems.stream().filter(p -> "Total".equalsIgnoreCase(p.getBob())).collect(Collectors.toList());
                periodTotalHsItems.clear();
                periodTotalHsItems.addAll(filteredItems);
                periodTotalHsItems.addAll(itemTotal);
                periodTotalHsReport.setItems(periodTotalHsItems);
                finalHsReports.add(periodTotalHsReport);
            }

            if (printCostResponseList.size() > 1) {
                PrintCostResponse periodTotalPrintCostResponse = new PrintCostResponse();
                periodTotalPrintCostResponse.setDate("Period Total");
                periodTotalPrintCostResponse.setTrailNumber(trailNumber);
                List<PrintCostResponseItems> periodTotalPrintCostItems = printCostResponseList.stream()
                        .flatMap(printCostResponse -> printCostResponse.getItems().stream())
                        .filter(Objects::nonNull)
                        .collect(Collectors.groupingBy(PrintCostResponseItems::getBob))
                        .entrySet().stream()
                        .map(entry -> {
                            String bob = entry.getKey();
                            List<PrintCostResponseItems> items = entry.getValue();
                            return getPrintCostResponseItemsForPeriodTotal(bob, items);
                        }).collect(Collectors.toList());
                List<PrintCostResponseItems> filteredItems = periodTotalPrintCostItems.stream().filter(p -> !"Total".equalsIgnoreCase(p.getBob())).collect(Collectors.toList());
                List<PrintCostResponseItems> itemTotal = periodTotalPrintCostItems.stream().filter(p -> "Total".equalsIgnoreCase(p.getBob())).collect(Collectors.toList());
                periodTotalPrintCostItems.clear();
                periodTotalPrintCostItems.addAll(filteredItems);
                periodTotalPrintCostItems.addAll(itemTotal);
                periodTotalPrintCostResponse.setItems(periodTotalPrintCostItems);
                finalPrintCostReports.add(periodTotalPrintCostResponse);
            }

            if (suppressionChgResponseList.size() > 1) {
                SuppressionChgResponse periodTotalSuppressionChgResponse = new SuppressionChgResponse();
                periodTotalSuppressionChgResponse.setDate("Period Total");
                periodTotalSuppressionChgResponse.setTrailNumber(trailNumber);
                List<SuppressionChgResponseItem> periodTotalSuppressionChgResponseItem = suppressionChgResponseList.stream()
                        .flatMap(suppressionChgResponse -> suppressionChgResponse.getItems().stream())
                        .filter(Objects::nonNull)
                        .collect(Collectors.groupingBy(SuppressionChgResponseItem::getBob))
                        .entrySet().stream()
                        .map(entry -> {
                            String bob = entry.getKey();
                            List<SuppressionChgResponseItem> items = entry.getValue();
                            return getSuppressionChgResponseItemForPeriodTotal(bob, items);
                        }).collect(Collectors.toList());
                List<SuppressionChgResponseItem> filteredItems = periodTotalSuppressionChgResponseItem.stream().filter(p -> !"Total".equalsIgnoreCase(p.getBob())).collect(Collectors.toList());
                List<SuppressionChgResponseItem> itemTotal = periodTotalSuppressionChgResponseItem.stream().filter(p -> "Total".equalsIgnoreCase(p.getBob())).collect(Collectors.toList());
                periodTotalSuppressionChgResponseItem.clear();
                periodTotalSuppressionChgResponseItem.addAll(filteredItems);
                periodTotalSuppressionChgResponseItem.addAll(itemTotal);
                periodTotalSuppressionChgResponse.setItems(periodTotalSuppressionChgResponseItem);
                finalSuppressionChgResponses.add(periodTotalSuppressionChgResponse);
            }
        }

        FinancialReportResponseDto response = new FinancialReportResponseDto();
        response.setEobPrintSuppressCountReport(finalEobReports);
        response.setHsPrintSuppressCountReport(finalHsReports);
        response.setCaePrintSuppressCountReport(finalCaeReports);
        response.setPrintCostReport(finalPrintCostReports);
        response.setSuppressionChangesReport(finalSuppressionChgResponses);
        return response;
    }

    private static HSReportItemsDto getHSReportItemsDtoForPeriodTotal(String bob, List<HSReportItemsDto> items) {
        HSReportItemsDto periodTotal = new HSReportItemsDto();
        periodTotal.setBob(bob.equals("Monthly Total") ? "Total" : bob);

        BigDecimal TotalHsGenerated = BigDecimal.valueOf(items.stream().mapToDouble(HSReportItemsDto::getTotalHsGenerated).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal TotalHsSuppressed = BigDecimal.valueOf(items.stream().mapToDouble(HSReportItemsDto::getTotalHsSuppressed).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal TotalHsSuppressedSubscriberElection = BigDecimal.valueOf(items.stream().mapToDouble(HSReportItemsDto::getTotalHsSuppressedSubscriberElection).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal TotalHsSuppressedPolicySetting = BigDecimal.valueOf(items.stream().mapToDouble(HSReportItemsDto::getTotalHsSuppressedPolicySetting).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal TotalHsPrinted = BigDecimal.valueOf(items.stream().mapToDouble(HSReportItemsDto::getTotalHsPrinted).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal HsSuppressedPercent = BigDecimal.valueOf(items.stream().mapToDouble(HSReportItemsDto::getHsSuppressedPercent).sum()).setScale(2, RoundingMode.HALF_UP);

        periodTotal.setTotalHsGenerated(TotalHsGenerated.doubleValue());
        periodTotal.setTotalHsSuppressed(TotalHsSuppressed.doubleValue());
        periodTotal.setTotalHsSuppressedSubscriberElection(TotalHsSuppressedSubscriberElection.doubleValue());
        periodTotal.setTotalHsSuppressedPolicySetting(TotalHsSuppressedPolicySetting.doubleValue());
        periodTotal.setTotalHsPrinted(TotalHsPrinted.doubleValue());
        periodTotal.setHsSuppressedPercent(CalculationUtils.roundOf((periodTotal.getTotalHsSuppressed()/ periodTotal.getTotalHsGenerated())*100));
        return periodTotal;
    }

    private static EobReportItemDto getEobReportItemDtoForPeriodTotal(String bob, List<EobReportItemDto> items) {
        EobReportItemDto totalItem = new EobReportItemDto();
        totalItem.setBob(bob.equals("Monthly Total") ? "Total" : bob);

        BigDecimal TotalEobsGenerated = BigDecimal.valueOf(items.stream().mapToDouble(EobReportItemDto::getTotalEobsGenerated).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal TotalEobsSuppressed = BigDecimal.valueOf(items.stream().mapToDouble(EobReportItemDto::getTotalEobsSuppressed).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal TotalEobsSuppressedSubscriberElection = BigDecimal.valueOf(items.stream().mapToDouble(EobReportItemDto::getTotalEobsSuppressedSubscriberElection).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal TotalEobsSuppressedPolicySetting = BigDecimal.valueOf(items.stream().mapToDouble(EobReportItemDto::getTotalEobsSuppressedPolicySetting).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal TotalEobsPrinted = BigDecimal.valueOf(items.stream().mapToDouble(EobReportItemDto::getTotalEobsPrinted).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal EobSuppressedPercent = BigDecimal.valueOf(items.stream().mapToDouble(EobReportItemDto::getEobSuppressedPercent).sum()).setScale(2, RoundingMode.HALF_UP);

        totalItem.setTotalEobsGenerated(TotalEobsGenerated.doubleValue());
        totalItem.setTotalEobsSuppressed(TotalEobsSuppressed.doubleValue());
        totalItem.setTotalEobsSuppressedSubscriberElection(TotalEobsSuppressedSubscriberElection.doubleValue());
        totalItem.setTotalEobsSuppressedPolicySetting(TotalEobsSuppressedPolicySetting.doubleValue());
        totalItem.setTotalEobsPrinted(TotalEobsPrinted.doubleValue());
        totalItem.setEobSuppressedPercent(CalculationUtils.roundOf((totalItem.getTotalEobsSuppressed() / totalItem.getTotalEobsGenerated()) * 100));
        return totalItem;
    }

    private static CaeReportItemDto getCaeReportItemDtoForPeriodTotal(String bob, List<CaeReportItemDto> items) {
        CaeReportItemDto totalItem = new CaeReportItemDto();
        totalItem.setBob(bob.equals("Monthly Total") ? "Total" : bob);

        BigDecimal totalCaeSuppressionEobsGenerated = BigDecimal.valueOf(items.stream().mapToDouble(CaeReportItemDto::getTotalCaeSuppressionEobsGenerated).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal caeSuppressionEobsWithEmail = BigDecimal.valueOf(items.stream().mapToDouble(CaeReportItemDto::getCaeSuppressionEobsWithEmail).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal caeSuppressionEobsNoEmail = BigDecimal.valueOf(items.stream().mapToDouble(CaeReportItemDto::getCaeSuppressionEobsNoEmail).sum()).setScale(2, RoundingMode.HALF_UP);

        totalItem.setTotalCaeSuppressionEobsGenerated(totalCaeSuppressionEobsGenerated.doubleValue());
        totalItem.setCaeSuppressionEobsWithEmail(caeSuppressionEobsWithEmail.doubleValue());
        totalItem.setCaeSuppressionEobsNoEmail(caeSuppressionEobsNoEmail.doubleValue());
        return totalItem;
    }

    private static PrintCostResponseItems getPrintCostResponseItemsForPeriodTotal(String bob, List<PrintCostResponseItems> items) {
        PrintCostResponseItems totalItem = new PrintCostResponseItems();
        totalItem.setBob(bob.equals("Monthly Total") ? "Total" : bob);

        BigDecimal postageCost = BigDecimal.valueOf(items.stream().mapToDouble(PrintCostResponseItems::getPostageCost).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal paperLabourCost = BigDecimal.valueOf(items.stream().mapToDouble(PrintCostResponseItems::getPaperLabourCost).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal costPerEnvelop = BigDecimal.valueOf(items.stream().mapToDouble(PrintCostResponseItems::getCostPerEnvelop).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal envelopeCount = BigDecimal.valueOf(items.stream().mapToDouble(PrintCostResponseItems::getEnvelopeCount).sum()).setScale(2, RoundingMode.HALF_UP);

        totalItem.setPostageCost(postageCost.doubleValue());
        totalItem.setPaperLabourCost(paperLabourCost.doubleValue());
        totalItem.setCostPerEnvelop(costPerEnvelop.doubleValue());
        totalItem.setEnvelopeCount(envelopeCount.doubleValue());
        return totalItem;
    }

    private static EobReportItemDto getEobReportItemDto(USPFinancialReport report) {
        EobReportItemDto item = new EobReportItemDto();
        item.setBob(report.getBob());
        item.setTotalEobsGenerated(report.getTotalEobGenerated());
        item.setTotalEobsSuppressed(report.getTotalEobSuppressed());
        item.setTotalEobsSuppressedSubscriberElection(report.getMemberElectionEob());
        item.setTotalEobsSuppressedPolicySetting(report.getPolicySettingEob());
        item.setTotalEobsPrinted(report.getTotalEobPrinted());
        item.setEobSuppressedPercent(report.getEobSuppressPercent());
        return item;
    }

    private static HSReportItemsDto getHSReportItemsDto(USPFinancialReport report) {
        HSReportItemsDto hsReportItems = new HSReportItemsDto();
        hsReportItems.setBob(report.getBob());
        hsReportItems.setTotalHsGenerated(report.getTotalHsGenerated());
        hsReportItems.setTotalHsSuppressed(report.getTotalHsSuppressed());
        hsReportItems.setTotalHsSuppressedSubscriberElection(report.getMemberElectionHs());
        hsReportItems.setTotalHsSuppressedPolicySetting(report.getPolicySettingHs());
        hsReportItems.setTotalHsPrinted(report.getTotalHsPrinted());
        hsReportItems.setHsSuppressedPercent(report.getHsSuppressPercent());
        return hsReportItems;
    }

    private static CaeReportItemDto getCaeReportItemDto(USPFinancialReport report) {
        CaeReportItemDto item = new CaeReportItemDto();
        item.setBob(report.getBob());
        item.setTotalCaeSuppressionEobsGenerated(report.getTotalCaeEobCount());
        item.setCaeSuppressionEobsWithEmail(report.getCaeEobMailCount());
        item.setCaeSuppressionEobsNoEmail(report.getCaeEobNoEmailCount());
        return item;

    }

    public void saveHsSuppDataFromPrintCostReportForPT3231(PrintingCostReport printingCostReport) {
        String trailName = printingCostReport.getTrailName();
        String month = printingCostReport.getMonth();
        String bob = printingCostReport.getBob();

        Optional<PrintingCostReport> printingCostReportFromDB = printingCostReportRepository.findByTrailNameAndBobAndMonth(trailName, bob, month);
        Optional<USPFinancialReport> uspFinancialReportDB = uspFinancialReportRepository.findByMonthYearStrAndBobAndTrailName(month, bob, trailName);
        if (printingCostReportFromDB.isPresent()) {

            boolean uspTxDataPresent = uspFinancialReportDB.isPresent();
            if (uspTxDataPresent) {
                USPFinancialReport uspFinancialReport = uspFinancialReportDB.get();
                uspFinancialReport.setIsCompleted(1);
                uspFinancialReport.setModifiedBy(USP_FIN_REPORTING_SERVICE);
                uspFinancialReportRepository.save(uspFinancialReport);
            } else {
                if( trailName.matches("^[a-zA-Z0-9._-]+$") && month.matches("^[0-9]{2}-[0-9]{4}$") && bob.matches("^[a-zA-Z0-9._-]+$")) {
                    log.info("EOB Suppression Cost Report not found for trailName: {}, month: {}, bob: {}. Creating new entry"
                            , trailName, month, bob);
                }
                LocalDate monthYear;
                try {
                    monthYear = DateUtil.getLocalDate(month, Constants.MONTH_YEAR_FORMAT);
                } catch (Exception e) {
                    log.error("Error while parsing date", e);
                    throw new USPException("Error while parsing date", e);
                }

                //tx entry not present in usp_financial_report table
                USPFinancialReport uspFinancialReport = new USPFinancialReport();
                uspFinancialReport.setTrailName(trailName);
                uspFinancialReport.setBob(bob);
                uspFinancialReport.setMonthYearStr(month);
                uspFinancialReport.setMonthYear(monthYear);
                uspFinancialReport.setIsCompleted(1);
                uspFinancialReport.setCreatedBy(USP_REPORTING_UI_SERVICE);
                uspFinancialReport.setModifiedBy(USP_REPORTING_UI_SERVICE);
                uspFinancialReportRepository.save(uspFinancialReport);

            }
        }
    }

    public HashMap<String, List<GetFieldValues>> fetchIsCompletedValues(String trailName, String startDate, String endDate) {
        if (trailName.matches("^[a-zA-Z0-9._-]+$") && startDate.matches("^[0-9]{2}-[0-9]{4}$") && endDate.matches("^[0-9]{2}-[0-9]{4}$")) {
            log.info("Fetching isCompleted values for trailName: {}, startDate: {}, endDate: {}",
                    trailName, startDate, endDate);
        }
        LocalDate start = DateUtil.getLocalDate(startDate, Constants.MONTH_YEAR_FORMAT);
        LocalDate end = DateUtil.getLocalDate(endDate, Constants.MONTH_YEAR_FORMAT);
        log.info("Start Date: {}, End Date: {}", start, end);
        LocalDate endDateWithMonth = end.withDayOfMonth(end.getMonth().length(end.isLeapYear()));
        List<Object[]> reports  = uspFinancialReportRepository.getDetailsFromDB(trailName, start, endDateWithMonth);
        log.info("Reports size: {}", reports.size());
        if(reports.isEmpty()){
            if (trailName.matches("^[a-zA-Z0-9._-]+$") && startDate.matches("^[0-9]{2}-[0-9]{4}$") && endDate.matches("^[0-9]{2}-[0-9]{4}$")) {
                log.info("No record found for trailName: {}, startDate: {}, endDate: {}",
                        trailName, startDate, endDate);
            }
            return new HashMap<>();
        }
    Map<String, List<GetFieldValues>> fieldMap = reports.stream().collect(
            Collectors.groupingBy(
                    report -> (String) report[1],
                    Collectors.mapping(report -> {
                        log.info("Report: {}", Arrays.toString(report));
                        GetFieldValues getFieldValues = new GetFieldValues();
                        getFieldValues.setBob((String) report[0]);
                        getFieldValues.setIsCompleted((Integer) report[2]);
                        getFieldValues.setIsTxCompleted((Integer) report[3]);
                        return getFieldValues;
                    }, Collectors.toList())
            )
    );

    return new HashMap<>(fieldMap);
    }

    private static SuppressionChgResponseItem getSuppressionChgResponseItem(USPFinancialReport report) {
        SuppressionChgResponseItem item = new SuppressionChgResponseItem();
        item.setBob(report.getBob());
        item.setOldEOBSuppress(report.getTotalHsSuppressed()-report.getHsMemPrint());
        item.setOldEOBPrint(report.getTotalHsPrinted()+report.getHsMemPrint());
        item.setOldEOBAffected(report.getHsMemPrint());
        return item;

    }

    private static SuppressionChgResponseItem getSuppressionChgResponseItemForPeriodTotal(String bob, List<SuppressionChgResponseItem> items) {
        SuppressionChgResponseItem totalItem = new SuppressionChgResponseItem();
        totalItem.setBob(bob.equals("Monthly Total") ? "Total" : bob);

        BigDecimal oldEOBSuppress = BigDecimal.valueOf(items.stream().mapToDouble(SuppressionChgResponseItem::getOldEOBSuppress).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal oldEOBPrint = BigDecimal.valueOf(items.stream().mapToDouble(SuppressionChgResponseItem::getOldEOBPrint).sum()).setScale(2, RoundingMode.HALF_UP);
        BigDecimal oldEOBAffected = BigDecimal.valueOf(items.stream().mapToDouble(SuppressionChgResponseItem::getOldEOBAffected).sum()).setScale(2, RoundingMode.HALF_UP);

        totalItem.setOldEOBPrint(oldEOBPrint.doubleValue());
        totalItem.setOldEOBSuppress(oldEOBSuppress.doubleValue());
        totalItem.setOldEOBAffected(oldEOBAffected.doubleValue());
        return totalItem;
    }
}