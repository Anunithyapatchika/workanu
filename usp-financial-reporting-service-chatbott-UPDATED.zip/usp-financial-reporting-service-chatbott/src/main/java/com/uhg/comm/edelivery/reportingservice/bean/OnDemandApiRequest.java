package com.uhg.comm.edelivery.reportingservice.bean;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.uhg.comm.edelivery.reportingservice.bean.ehsjson.Doc360Data;
import com.uhg.comm.edelivery.reportingservice.bean.ehsjson.EdeliveryData;
import com.uhg.comm.edelivery.reportingservice.bean.ehsjson.HsPackage;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OnDemandApiRequest {

	@JsonProperty("EDELIVERY_DATA")
	@JsonPropertyDescription("eDelivery Data")
	private EdeliveryData edeliveryData;

	@JsonProperty("DOC360_DATA")
	@JsonPropertyDescription("Doc360 Data")
	private Doc360Data doc360Data;

	@JsonProperty("HS_PACKAGE")
	@JsonPropertyDescription("Health Statement Data Package")
	private HsPackage hsPackage;

	@JsonProperty("HS_PACKAGE")
	public HsPackage getHsPackage() {
		return hsPackage;
	}

	@JsonProperty("HS_PACKAGE")
	public void setHsPackage(HsPackage hsPackage) {
		this.hsPackage = hsPackage;
	}

	@JsonProperty("EDELIVERY_DATA")
	public EdeliveryData getEdeliveryData() {
		return edeliveryData;
	}

	@JsonProperty("EDELIVERY_DATA")
	public void setEdeliveryData(EdeliveryData edeliveryData) {
		this.edeliveryData = edeliveryData;
	}

	@JsonProperty("DOC360_DATA")
	public Doc360Data getDoc360Data() {
		return doc360Data;
	}

	@JsonProperty("DOC360_DATA")
	public void setDoc360Data(Doc360Data doc360Data) {
		this.doc360Data = doc360Data;
	}

}
