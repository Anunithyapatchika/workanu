package com.uhg.comm.edelivery.reportingservice.bean;

import com.uhg.comm.edelivery.reportingservice.model.Message;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Data
@AllArgsConstructor
@ToString
public class MessageWithImageResponse {
    private Message message;
    private List<byte[]> images;

    // Constructors, getters, setters
    public MessageWithImageResponse() {}

}
