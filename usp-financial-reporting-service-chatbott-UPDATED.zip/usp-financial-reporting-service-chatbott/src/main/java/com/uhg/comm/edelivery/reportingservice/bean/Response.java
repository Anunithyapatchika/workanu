package com.uhg.comm.edelivery.reportingservice.bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Builder
@AllArgsConstructor
public class Response {
    boolean result;
    String message;
}
