package com.uhg.comm.edelivery.reportingservice.bean;

import lombok.Data;

@Data
public class StatusRequestInfo {

	private String jobId;

	private String recordId;

	private String tnoRecordId;

	private String status;

	private String errorCode;

	private String errorMessage;

}
