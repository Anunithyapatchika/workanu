package com.uhg.comm.edelivery.reportingservice.controller;

import com.uhg.comm.edelivery.reportingservice.bean.GetFieldValues;
import com.uhg.comm.edelivery.reportingservice.dto.EHSFinancialReportResponseDto;
import com.uhg.comm.edelivery.reportingservice.dto.HsSuppCostDto;
import com.uhg.comm.edelivery.reportingservice.service.HSSuppCostReportService;
import com.uhg.comm.edelivery.reportingservice.service.USP3696DataService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("hs-supp-report")
@CrossOrigin
public class HsSuppCostController {

    @Autowired
    private HSSuppCostReportService hsSuppCostReportService;

    @GetMapping(value = "/getReport", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<EHSFinancialReportResponseDto> getAllFinancialReports(
            @RequestParam String trailName,
            @RequestParam String startDate,
            @RequestParam String endDate) {
        //Calls the service method to get the financial report.
        if (StringUtils.isBlank(trailName) || StringUtils.isBlank(startDate) || StringUtils.isBlank(endDate)) {
            throw new IllegalArgumentException("Trail Name, Start Date and End Date are mandatory fields. Please provide valid values.");
        }
        EHSFinancialReportResponseDto ehsFinancialReportResponseDto = hsSuppCostReportService.getHSSuppCostReport(trailName, startDate, endDate);

        //Returns the response wrapped in a ResponseEntity.
        return ResponseEntity.ok(ehsFinancialReportResponseDto);
    }
}


