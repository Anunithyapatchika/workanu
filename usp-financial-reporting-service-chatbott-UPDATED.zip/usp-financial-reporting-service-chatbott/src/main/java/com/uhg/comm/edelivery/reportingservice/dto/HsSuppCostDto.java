package com.uhg.comm.edelivery.reportingservice.dto;

import lombok.Data;

import java.util.List;

@Data
public class HsSuppCostDto {

    private String date;
    private String trailName;
    private List<HsSuppCostItemsDto> items;
}
