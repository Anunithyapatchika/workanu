package com.uhg.comm.edelivery.reportingservice.controller;

import com.uhg.comm.edelivery.reportingservice.service.MgmtUIService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class MgmtUIController {

    private static final Logger LOGGER = LoggerFactory.getLogger(MgmtUIController.class);

    @Autowired
    private MgmtUIService mgmtUIService;

    @GetMapping("/downloadFile")
    public ResponseEntity<Resource> downLoadFile(@RequestParam String fileName,@RequestParam String inputFilePath) {
        if (fileName.matches("^[a-zA-Z0-9._-]+$") && inputFilePath.matches("^[a-zA-Z0-9._/-]+$")) {
            LOGGER.info("Received request to download PDF with file name: {}, -- {} ::",
                    fileName,inputFilePath);
        }
        ResponseEntity<Resource> result = mgmtUIService.downloadPdf(fileName, inputFilePath);
        if (result != null && result.getStatusCode().is2xxSuccessful()) {
            LOGGER.info("PDF downloaded successfully");
            return ResponseEntity.ok().body(result.getBody());
        } else {
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/downloadZips")
    public ResponseEntity<Resource> downloadZips(@RequestParam String fileName,@RequestParam String inputFilePath) {
        if (fileName.matches("^[a-zA-Z0-9._-]+$") && inputFilePath.matches("^[a-zA-Z0-9._/-]+$")) {
            LOGGER.info("Received request to download file name: {}, -- {} ::",
                    fileName,inputFilePath);
        }
        ResponseEntity<Resource> result = mgmtUIService.downloadzips(fileName, inputFilePath);
        if (result != null && result.getStatusCode().is2xxSuccessful()) {
            LOGGER.info("File downloaded successfully");
            return ResponseEntity.ok().body(result.getBody());
        } else {
            return ResponseEntity.internalServerError().build();
        }
    }
}
