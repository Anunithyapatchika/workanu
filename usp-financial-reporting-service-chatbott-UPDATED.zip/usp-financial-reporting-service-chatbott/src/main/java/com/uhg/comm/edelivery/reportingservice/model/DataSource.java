package com.uhg.comm.edelivery.reportingservice.model;

import lombok.Data;

import java.util.Map;

@Data
public class DataSource {
    private String type;
    private Parameters parameters;

    // getters and setters
    // constructor(s)
}

