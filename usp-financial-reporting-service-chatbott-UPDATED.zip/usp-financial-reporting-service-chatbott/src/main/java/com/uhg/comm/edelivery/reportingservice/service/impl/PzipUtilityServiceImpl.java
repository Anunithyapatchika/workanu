package com.uhg.comm.edelivery.reportingservice.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.StreamReadFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uhg.comm.edelivery.reportingservice.auth.OauthTokenUtil;
import com.uhg.comm.edelivery.reportingservice.bean.*;
import com.uhg.comm.edelivery.reportingservice.service.PzipUtilityService;
import com.uhg.comm.edelivery.reportingservice.util.BlobUtils;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.util.List;

import static com.uhg.comm.edelivery.reportingservice.constants.Constants.*;

@Service
public class PzipUtilityServiceImpl implements PzipUtilityService {

    private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(PzipUtilityServiceImpl.class);


	private static final String TEST_IND = null;


    @Value("${edelivery.configproperties.properties.onDemandOrxApi.orxOnDemandUrl}")
    private String orxOnDemandUrl;

    @Value("${edelivery.configproperties.properties.batchConsolidationOrxApi.orxBatchApiUri}")
    private String orxBatchApiUri;

    @Value("${edelivery.configproperties.properties.batchDeliveryWithOrx.orxBatchDeliveryApiUri}")
    private String orxBatchDeliveryApiUri;

    @Autowired
    private OauthTokenUtil oauthTokenUtil;

    @Autowired
    private WebClient webClient;
    
    @Autowired
    private BlobUtils blobUtils;

    ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public ApiResponse callOnDemandApi(OnDemandApiRequest ondemandRequestBody, String jobId, String supressIndictor, String trailType,String tnoId) {
        ResponseEntity<String> response = null;
        try {
            String token = oauthTokenUtil.callSecurityToken();
            if (token == null || StringUtils.isBlank(token)) {
                LOGGER.error("Failed to retrieve token");
                return ApiResponse.builder().result(false).message("Failed to retrieve token").build();
            }
            LOGGER.info("Token received successfully::");
            response = webClient.post().uri(orxOnDemandUrl)
                    .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                    .header(AUTHORIZATION, token)
                    .header(OPTUM_RX_IS_PRODUCTION, String.valueOf(true))
                    .header(OPTUM_RX_IS_APPROVAL_PACKAGE, String.valueOf(false))
                    .header(OPTUM_RX_COMM_TYPE, trailType + "_" + "PT3696")
                    .header(OPTUM_RX_REQ_ID, tnoId)
                    .header(OPTUM_RX_COMM_CODE, trailType)
                    .header(OPTUM_RX_COMM_FAMILY, "QUADIENT HSE - PENG - QHSE")
                    .header(OPTUM_RX_PARENTAL_JOB_ID, jobId)
                    .header(OPTUM_RX_EXTERNAL_ID, jobId)
                    .header(OPTUM_RX_COMPARE_TYPE, "")
                    .header(OPTUM_RX_JOB_TYPE, "")
                    .header(OPTUM_RX_USER_ID, OPTUM_RX_USER_ID_VALUE)
                    .header(SUPPRESS_INDICATOR, supressIndictor).
                    header(OPTUM_RX_REQUEST_TYPE, OPTUM_RX_REQUEST_TYPE_ON_DEMAND)
                    .body(Mono.just(ondemandRequestBody), OnDemandApiRequest.class)
                    .retrieve()
                    .toEntity(String.class)
                    .retryWhen(Retry.fixedDelay(3, Duration.ofSeconds(2)))
                    .timeout(Duration.ofSeconds(30))
                    .block();
            LOGGER.info("ORX ondemand response :{}",response.getBody());
            OnDemandOptumRxAPIResponse optumRxAPIResponse = objectMapper.readValue(response.getBody(), OnDemandOptumRxAPIResponse.class);
           // LOGGER.info("Response from OnDemand API: {}", optumRxAPIResponse);
            if (null != response && null != response.getBody() && HttpStatus.OK == response.getStatusCode()
                    && optumRxAPIResponse.getMessage().equalsIgnoreCase(ACCEPTED)) {
            	 LOGGER.info("Ondemand called successfully :{}",optumRxAPIResponse);
                return ApiResponse.builder().result(true).message("Ondemand called successfully").build();
            } else if (optumRxAPIResponse.getStatus().equalsIgnoreCase(FAILED) && optumRxAPIResponse.getMessage().contains(DUPLICATE)) {
            	LOGGER.info("Ondemand called Failed :{}",optumRxAPIResponse);
                return ApiResponse.builder().result(false).message("Ondemand called Failed "+optumRxAPIResponse.getMessage()).build();
            }else{
                LOGGER.error("OnDemand API call failed with status code: {}", response.getStatusCode());
                return ApiResponse.builder().result(false).message("Demand API call failed with status code: {}"+ response.getStatusCode()).build();
            }
        } catch (JsonProcessingException e) {
            LOGGER.error("Error converting request body to JSON: {}", e.getMessage());
            return ApiResponse.builder().result(false).message("Error converting request body to JSON").build();
        } catch (Exception e) {
            LOGGER.error("Error occurred while Ondemand Api:  {}", e);
            return ApiResponse.builder().result(false).message(e.getMessage()).build();
        }
    }

    @Override
    public ApiResponse callBatchConsolidationApi(String jobId, BatchFile batchConsolidationBody, String trailType, String tnoId) {
    	LOGGER.info("calling new");
            try {
                String token = oauthTokenUtil.callSecurityToken();
                if (token == null) {
                    LOGGER.error("Failed to retrieve token");
                    return ApiResponse.builder().result(false).message("Failed to retrieve token").build();
                }
                LOGGER.info("Token received successfully");

                //batchApi = createBatchApiFile(jobId, batchConsolidationBody);
                ResponseEntity<String> response = webClient.post()
                        .uri(orxBatchApiUri)
                        .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                        .header(OPTUM_RX_REQUEST_TYPE, OPTUM_RX_REQUEST_TYPE_BATCH_CONSOLIDATION)
                        .header(OPTUM_RX_IS_PRODUCTION, String.valueOf(true))
                        .header(OPTUM_RX_IS_APPROVAL_PACKAGE, String.valueOf(false))
                        .header(OPTUM_RX_JOB_TYPE, "")
                        .header(SUPPRESS_INDICATOR, "")
                        .header(OPTUM_RX_REQ_ID, tnoId)
                        .header(OPTUM_RX_PARENTAL_JOB_ID, jobId)
                        .header(OPTUM_RX_USER_ID, OPTUM_RX_USER_ID_VALUE)
                        .header(OPTUM_RX_INBOUND_STATUS, "")
                        .header(OPTUM_RX_COMM_TYPE, trailType + "_" + "PT3696")
                        .header(HttpHeaders.AUTHORIZATION, token)
                        .body(Mono.just(batchConsolidationBody), BatchFile.class)
                        .retrieve().toEntity(String.class).share()
                        .retryWhen(Retry.fixedDelay(3, Duration.ofSeconds(2)))
                        .timeout(Duration.ofSeconds(30))
                        .block();
                if (response != null && response.getBody() != null
                        && HttpStatus.OK == response.getStatusCode()) {
                    BatchApiResponse batchApiResponse = objectMapper.readValue(response.getBody(), BatchApiResponse.class);
                    if (null != batchApiResponse && StringUtils.isNotBlank(batchApiResponse.getStatus())) {
                        LOGGER.info("Batch Consolidation API call was successful:{}", batchApiResponse);
                        return ApiResponse.builder().result(true).message("Batch Consolidation API call was successful").build();
                    } else {
                        LOGGER.error("Batch Consolidation API call failed with status code: {}", response.getStatusCode());
                        return ApiResponse.builder().result(false).message("Batch Consolidation API call failed with status code: {}  "+response.getStatusCode()).build();
                    }
                }
            } catch (Exception e) {
                return ApiResponse.builder().result(false).message(e.getMessage()).build();
            }
       return ApiResponse.builder().result(false).message("Batch Consolidation API call failed").build();
    }

    @Override
    public ApiResponse callBatchDeliveryApi(String jobId,String trailType, String inputFileName, BatchDeliveryRequest batchDeliveryRequestBody) {
        if(inputFileName.matches("^[a-zA-Z0-9._/-]+$")) {
            LOGGER.info("Calling batchDelivery api with jobId: {}", inputFileName);
        }
        ResponseEntity<String> response;
        try {
            String token = oauthTokenUtil.callSecurityToken();
            if (token == null) {
                LOGGER.error("Failed to retrieve token");
                return ApiResponse.builder().result(false).message("Failed to retrieve token").build();
            }
            LOGGER.info("Token received successfully for batchDelivery api");

            response = webClient.post()
                    .uri(orxBatchDeliveryApiUri)
                    .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                    .header(OPTUM_RX_REQUEST_TYPE, BATCH_DELIVERY)
                    .header(OPTUM_RX_IS_PRODUCTION, String.valueOf(true))
                    .header(OPTUM_RX_IS_APPROVAL_PACKAGE, String.valueOf(false))
                    .header(OPTUM_RX_JOB_TYPE, "")
                    .header(SUPPRESS_INDICATOR, "")
                    .header(OPTUM_RX_PARENTAL_JOB_ID, jobId)
                    .header(OPTUM_RX_REQ_ID, jobId)
                    .header(OPTUM_RX_USER_ID, OPTUM_RX_USER_ID_VALUE)
                    .header(OPTUM_RX_INBOUND_STATUS, "")
                    .header(OPTUM_RX_COMM_TYPE, trailType + "_" + "PT3696")
                    .header(OPTUM_RX_COMM_FAMILY, "QUADIENT HSE - PENG - QHSE")
                    .header(OPTUM_RX_COMM_CODE, trailType)
                    .header(HttpHeaders.AUTHORIZATION, token)
                    .body(Mono.just(batchDeliveryRequestBody), BatchDeliveryRequest.class)
                    .retrieve()
                    .toEntity(String.class)
                    .retryWhen(Retry.fixedDelay(3, Duration.ofSeconds(2)))
                    .timeout(Duration.ofSeconds(30))
                    .retry(3)
                    .block();
            LOGGER.info("resonse:{}",response);
            if(response != null && response.getBody() != null
                    && HttpStatus.OK == response.getStatusCode()) {
                BatchApiResponse batchDelievryResponse = objectMapper.readValue(response.getBody(), BatchApiResponse.class);
                if (null != batchDelievryResponse && StringUtils.isNotBlank(batchDelievryResponse.getStatus())) {
                    LOGGER.info("Batch Delivery API call was successful");
                    return ApiResponse.builder().result(true).message("Batch Delivery API call was successful").build();
                } else {
                    LOGGER.error("Batch Delivery API call failed with status code: {}", response.getStatusCode());
                    return ApiResponse.builder().result(false).message("Batch Delivery API call failed with status code:"+response.getStatusCode()).build();
                }
            }
        } catch (Exception e) {
            return ApiResponse.builder().result(false).message(e.getMessage()).build();
        }
  
        return ApiResponse.builder().result(false).message("Batch Delivery API call failed").build();
    }

	@Override
	public List<String> getListOfFilesFromBlob(String inputFileName) {
		// TODO Auto-generated method stub
        try {
            if (inputFileName.matches("^[a-zA-Z0-9._-]+$")) {
                LOGGER.info("Fetching blob items list for input file name: {}", inputFileName);
            }
            List<String> blobItemsList = blobUtils.getBlobItemsList(inputFileName);
            return blobItemsList;
        }catch(Exception e){
            LOGGER.error("Error occurred while fetching blob items list: {}", e.getMessage());
            throw e;
        }
	}
}
