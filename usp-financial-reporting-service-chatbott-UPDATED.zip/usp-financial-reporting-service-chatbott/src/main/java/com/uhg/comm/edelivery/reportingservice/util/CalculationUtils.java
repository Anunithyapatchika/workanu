package com.uhg.comm.edelivery.reportingservice.util;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class CalculationUtils {

    public static double roundOf(double value) {
        if(Double.isFinite(value)){
            return BigDecimal.valueOf(value).setScale(2, RoundingMode.HALF_UP).doubleValue();
        }else{
            return 0 ;
        }
    }

}
