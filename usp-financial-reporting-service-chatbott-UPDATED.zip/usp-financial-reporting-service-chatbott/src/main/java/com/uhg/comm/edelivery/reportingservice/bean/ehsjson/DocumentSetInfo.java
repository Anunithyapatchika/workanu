package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "documentHeaderInfo", "genRecord", "otherStmtAttributes", "planAccumInfo", "claimInfo",
		"stmtRemarkInfo", "docMessageInfo", "stufferInfo", "additionalFieldsInfo" })
@Generated("jsonschema2pojo")
public class DocumentSetInfo {

	@JsonProperty("documentHeaderInfo")
	private DocumentHeaderInfo documentHeaderInfo;

	@JsonProperty("genRecord")
	private GenRecord genRecord;

	@JsonProperty("otherStmtAttributes")
	private OtherStmtAttributes otherStmtAttributes;

	@JsonProperty("planAccumInfo")
	private List<PlanAccumInfo> planAccumInfo = null;

	@JsonProperty("claimInfo")
	private List<ClaimInfo> claimInfo = null;

	@JsonProperty("stmtRemarkInfo")
	private List<StmtRemarkInfo> stmtRemarkInfo = null;

	@JsonProperty("docMessageInfo")
	private List<DocMessageInfo> docMessageInfo = null;

	@JsonProperty("stufferInfo")
	private List<StufferInfo> stufferInfo = null;

	@JsonProperty("additionalFieldsInfo")
	private AdditionalFieldsInfo additionalFieldsInfo;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("documentHeaderInfo")
	public DocumentHeaderInfo getDocumentHeaderInfo() {
		return documentHeaderInfo;
	}

	@JsonProperty("documentHeaderInfo")
	public void setDocumentHeaderInfo(DocumentHeaderInfo documentHeaderInfo) {
		this.documentHeaderInfo = documentHeaderInfo;
	}

	@JsonProperty("genRecord")
	public GenRecord getGenRecord() {
		return genRecord;
	}

	@JsonProperty("genRecord")
	public void setGenRecord(GenRecord genRecord) {
		this.genRecord = genRecord;
	}

	@JsonProperty("otherStmtAttributes")
	public OtherStmtAttributes getOtherStmtAttributes() {
		return otherStmtAttributes;
	}

	@JsonProperty("otherStmtAttributes")
	public void setOtherStmtAttributes(OtherStmtAttributes otherStmtAttributes) {
		this.otherStmtAttributes = otherStmtAttributes;
	}

	@JsonProperty("planAccumInfo")
	public List<PlanAccumInfo> getPlanAccumInfo() {
		return planAccumInfo;
	}

	@JsonProperty("planAccumInfo")
	public void setPlanAccumInfo(List<PlanAccumInfo> planAccumInfo) {
		this.planAccumInfo = planAccumInfo;
	}

	@JsonProperty("claimInfo")
	public List<ClaimInfo> getClaimInfo() {
		return claimInfo;
	}

	@JsonProperty("claimInfo")
	public void setClaimInfo(List<ClaimInfo> claimInfo) {
		this.claimInfo = claimInfo;
	}

	@JsonProperty("stmtRemarkInfo")
	public List<StmtRemarkInfo> getStmtRemarkInfo() {
		return stmtRemarkInfo;
	}

	@JsonProperty("stmtRemarkInfo")
	public void setStmtRemarkInfo(List<StmtRemarkInfo> stmtRemarkInfo) {
		this.stmtRemarkInfo = stmtRemarkInfo;
	}

	@JsonProperty("docMessageInfo")
	public List<DocMessageInfo> getDocMessageInfo() {
		return docMessageInfo;
	}

	@JsonProperty("docMessageInfo")
	public void setDocMessageInfo(List<DocMessageInfo> docMessageInfo) {
		this.docMessageInfo = docMessageInfo;
	}

	@JsonProperty("stufferInfo")
	public List<StufferInfo> getStufferInfo() {
		return stufferInfo;
	}

	@JsonProperty("stufferInfo")
	public void setStufferInfo(List<StufferInfo> stufferInfo) {
		this.stufferInfo = stufferInfo;
	}

	@JsonProperty("additionalFieldsInfo")
	public AdditionalFieldsInfo getAdditionalFieldsInfo() {
		return additionalFieldsInfo;
	}

	@JsonProperty("additionalFieldsInfo")
	public void setAdditionalFieldsInfo(AdditionalFieldsInfo additionalFieldsInfo) {
		this.additionalFieldsInfo = additionalFieldsInfo;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(DocumentSetInfo.class.getName()).append('@')
				.append(Integer.toHexString(System.identityHashCode(this))).append('[');
		sb.append("documentHeaderInfo");
		sb.append('=');
		sb.append(((this.documentHeaderInfo == null) ? "<null>" : this.documentHeaderInfo));
		sb.append(',');
		sb.append("genRecord");
		sb.append('=');
		sb.append(((this.genRecord == null) ? "<null>" : this.genRecord));
		sb.append(',');
		sb.append("otherStmtAttributes");
		sb.append('=');
		sb.append(((this.otherStmtAttributes == null) ? "<null>" : this.otherStmtAttributes));
		sb.append(',');
		sb.append("planAccumInfo");
		sb.append('=');
		sb.append(((this.planAccumInfo == null) ? "<null>" : this.planAccumInfo));
		sb.append(',');
		sb.append("claimInfo");
		sb.append('=');
		sb.append(((this.claimInfo == null) ? "<null>" : this.claimInfo));
		sb.append(',');
		sb.append("stmtRemarkInfo");
		sb.append('=');
		sb.append(((this.stmtRemarkInfo == null) ? "<null>" : this.stmtRemarkInfo));
		sb.append(',');
		sb.append("docMessageInfo");
		sb.append('=');
		sb.append(((this.docMessageInfo == null) ? "<null>" : this.docMessageInfo));
		sb.append(',');
		sb.append("stufferInfo");
		sb.append('=');
		sb.append(((this.stufferInfo == null) ? "<null>" : this.stufferInfo));
		sb.append(',');
		sb.append("additionalFieldsInfo");
		sb.append('=');
		sb.append(((this.additionalFieldsInfo == null) ? "<null>" : this.additionalFieldsInfo));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
