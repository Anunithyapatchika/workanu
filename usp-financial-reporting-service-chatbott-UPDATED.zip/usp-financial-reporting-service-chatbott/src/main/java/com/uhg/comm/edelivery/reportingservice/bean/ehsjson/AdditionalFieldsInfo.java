package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "addr1", "addr2", "addr3", "addr4", "addr5", "deliveryPoint", "casReturnCd", "chgOfAddrMatchInd",
		"suppressCd" })
@Generated("jsonschema2pojo")
public class AdditionalFieldsInfo {

	@JsonProperty("addr1")
	private String addr1;
	@JsonProperty("addr2")
	private String addr2;
	@JsonProperty("addr3")
	private String addr3;
	@JsonProperty("addr4")
	private String addr4;
	@JsonProperty("addr5")
	private String addr5;
	@JsonProperty("deliveryPoint")
	private String deliveryPoint;
	@JsonProperty("casReturnCd")
	private String casReturnCd;
	@JsonProperty("chgOfAddrMatchInd")
	private String chgOfAddrMatchInd;
	@JsonProperty("suppressCd")
	private String suppressCd;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("addr1")
	public String getAddr1() {
		return addr1;
	}

	@JsonProperty("addr1")
	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}

	@JsonProperty("addr2")
	public String getAddr2() {
		return addr2;
	}

	@JsonProperty("addr2")
	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}

	@JsonProperty("addr3")
	public String getAddr3() {
		return addr3;
	}

	@JsonProperty("addr3")
	public void setAddr3(String addr3) {
		this.addr3 = addr3;
	}

	@JsonProperty("addr4")
	public String getAddr4() {
		return addr4;
	}

	@JsonProperty("addr4")
	public void setAddr4(String addr4) {
		this.addr4 = addr4;
	}

	@JsonProperty("addr5")
	public String getAddr5() {
		return addr5;
	}

	@JsonProperty("addr5")
	public void setAddr5(String addr5) {
		this.addr5 = addr5;
	}

	@JsonProperty("deliveryPoint")
	public String getDeliveryPoint() {
		return deliveryPoint;
	}

	@JsonProperty("deliveryPoint")
	public void setDeliveryPoint(String deliveryPoint) {
		this.deliveryPoint = deliveryPoint;
	}

	@JsonProperty("casReturnCd")
	public String getCasReturnCd() {
		return casReturnCd;
	}

	@JsonProperty("casReturnCd")
	public void setCasReturnCd(String casReturnCd) {
		this.casReturnCd = casReturnCd;
	}

	@JsonProperty("chgOfAddrMatchInd")
	public String getChgOfAddrMatchInd() {
		return chgOfAddrMatchInd;
	}

	@JsonProperty("chgOfAddrMatchInd")
	public void setChgOfAddrMatchInd(String chgOfAddrMatchInd) {
		this.chgOfAddrMatchInd = chgOfAddrMatchInd;
	}

	@JsonProperty("suppressCd")
	public String getSuppressCd() {
		return suppressCd;
	}

	@JsonProperty("suppressCd")
	public void setSuppressCd(String suppressCd) {
		this.suppressCd = suppressCd;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(AdditionalFieldsInfo.class.getName()).append('@')
				.append(Integer.toHexString(System.identityHashCode(this))).append('[');
		sb.append("addr1");
		sb.append('=');
		sb.append(((this.addr1 == null) ? "<null>" : this.addr1));
		sb.append(',');
		sb.append("addr2");
		sb.append('=');
		sb.append(((this.addr2 == null) ? "<null>" : this.addr2));
		sb.append(',');
		sb.append("addr3");
		sb.append('=');
		sb.append(((this.addr3 == null) ? "<null>" : this.addr3));
		sb.append(',');
		sb.append("addr4");
		sb.append('=');
		sb.append(((this.addr4 == null) ? "<null>" : this.addr4));
		sb.append(',');
		sb.append("addr5");
		sb.append('=');
		sb.append(((this.addr5 == null) ? "<null>" : this.addr5));
		sb.append(',');
		sb.append("deliveryPoint");
		sb.append('=');
		sb.append(((this.deliveryPoint == null) ? "<null>" : this.deliveryPoint));
		sb.append(',');
		sb.append("casReturnCd");
		sb.append('=');
		sb.append(((this.casReturnCd == null) ? "<null>" : this.casReturnCd));
		sb.append(',');
		sb.append("chgOfAddrMatchInd");
		sb.append('=');
		sb.append(((this.chgOfAddrMatchInd == null) ? "<null>" : this.chgOfAddrMatchInd));
		sb.append(',');
		sb.append("suppressCd");
		sb.append('=');
		sb.append(((this.suppressCd == null) ? "<null>" : this.suppressCd));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
