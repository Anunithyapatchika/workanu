   package com.uhg.comm.edelivery.reportingservice.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.PathMatchConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfigurationConfig implements WebMvcConfigurer {

 @Override
 public void configurePathMatch(PathMatchConfigurer configurer) {
 // Enables matching of URLs with or without a trailing slash
 configurer.setUseTrailingSlashMatch(true);
 }
}

