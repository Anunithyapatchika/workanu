package com.uhg.comm.edelivery.reportingservice.repository;

import com.uhg.comm.edelivery.processLog.Processlog;
import com.uhg.comm.edelivery.reportingservice.model.USP3696Data;
import com.uhg.comm.edelivery.reportingservice.model.USPFinancialReport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static com.uhg.comm.edelivery.reportingservice.constants.Constants.*;

@Repository
public class USP3231DataRepository {

    private static final Logger LOGGER = LoggerFactory.getLogger(USP3231DataRepository.class);


    @Autowired
    JdbcTemplate jdbcTemplate;

    public List<USPFinancialReport> getUSP3231Data(String dateFilter, Processlog processlog) {
        try {
            String query = "with bt as ( \n" +
                    "WITH filtered_preprocessor_jobs AS ( \n" +
                    "    SELECT pj.id, pj.job_id,j.data,j.created_timestamp \n" +
                    "    FROM edelivery.job j \n" +
                    "    JOIN edelivery.preprocessor_job pj ON j.id = pj.job_id \n" +
                    "    JOIN edelivery.archival_job aj ON j.id = aj.job_id \n" +
                    "    WHERE j.trail_num = 'PT3231' \n" +
                    "    AND j.created_timestamp::date " + dateFilter + " \n" +
                    ") \n" +
                    "\n" +
                    "SELECT \n" +
                    "    MIN(pr.id) AS id, \n" +
                    "    COUNT(*) AS count, \n" +
                    "    pr.book_of_business AS bob, \n" +
                    "    pr.final_decision AS f, \n" +
                    "    jsonb(fpj.data)->>'fileName' AS filename, \n" +
                    "    COALESCE(pr.health_statement_ind, 'N') AS h_ind, \n" +
                    "    epmp_response_fields->>'code' AS epmp_response, \n" +
                    "    fpj.created_timestamp::date AS created_date \n" +
                    " FROM edelivery.preprocessor_record pr \n" +
                    " JOIN filtered_preprocessor_jobs fpj ON pr.preprocessor_job_id = fpj.id \n" +
                    " GROUP BY \n" +
                    "    pr.final_decision, \n" +
                    "    pr.book_of_business, \n" +
                    "    h_ind, \n" +
                    "    epmp_response_fields->>'code', \n" +
                    "    jsonb(fpj.data)->>'fileName', \n" +
                    "    fpj.created_timestamp::date \n" +
                    ") \n" +
                    " select  min(id) as id , \n" +
                    "bt.created_date , \n" +
                    "bt.filename, \n" +
                    "bt.bob, \n" +
                    "(select sum(count) from bt as b where filename like '%prnt%' and b.filename = bt.filename and b.created_date = bt.created_date and b.bob = bt.bob) as total, \n" +
                    "(select sum(count) from bt as b where filename like '%prnt%' and b.filename = bt.filename and b.created_date = bt.created_date and b.bob = bt.bob and (f= 'E' OR f='Y')) as suppr, \n" +
                    "(select sum(count) from bt as b where filename like '%prnt%' and b.filename = bt.filename and b.created_date = bt.created_date and b.bob = bt.bob and f= 'E') as mem_supp, \n" +
                    "(select sum(count) from bt as b where filename like '%prnt%' and b.filename = bt.filename and b.created_date = bt.created_date and b.bob = bt.bob and f= 'Y') as policy_supp, \n" +
                    "(select sum(count) from bt as b where filename like '%prnt%' and b.filename = bt.filename and b.created_date = bt.created_date and b.bob = bt.bob and f= 'P') as print_supp, \n" +
                    "(select sum(count) from bt as b where filename like '%prnt%' and b.filename = bt.filename and b.created_date = bt.created_date and b.bob = bt.bob and h_ind= 'H') as hs_total, \n" +
                    "(select sum(count) from bt as b where filename like '%prnt%' and b.filename = bt.filename and b.created_date = bt.created_date and b.bob = bt.bob and h_ind= 'H' and (f= 'E' OR f='Y')) as hs_suppr, \n" +
                    "(select sum(count) from bt as b where filename like '%prnt%' and b.filename = bt.filename and b.created_date = bt.created_date and b.bob = bt.bob and h_ind= 'H' and f= 'E') as hs_mem_supp, \n" +
                    "(select sum(count) from bt as b where filename like '%prnt%' and b.filename = bt.filename and b.created_date = bt.created_date and b.bob = bt.bob and h_ind= 'H' and f= 'Y') as hs_policy_supp, \n" +
                    "(select sum(count) from bt as b where filename like '%prnt%' and b.filename = bt.filename and b.created_date = bt.created_date and b.bob = bt.bob and h_ind= 'H' and f= 'Y' and epmp_response = 'PM') as hs_mem_print, \n" +
                    "(select sum(count) from bt as b where filename like '%prnt%' and b.filename = bt.filename and b.created_date = bt.created_date and b.bob = bt.bob and h_ind= 'H' and f= 'P') as hs_print_supp, \n" +
                    "(select sum(count) from bt as b where filename like '%sprs%' and b.filename = bt.filename and b.created_date = bt.created_date and b.bob = bt.bob ) as cae_total, \n" +
                    "(select sum(count) from bt as b where filename like '%sprs%' and b.filename = bt.filename and b.created_date = bt.created_date and b.bob = bt.bob and f= 'E') as cae_email, \n" +
                    "(select sum(count) from bt as b where filename like '%sprs%' and b.filename = bt.filename and b.created_date = bt.created_date and b.bob = bt.bob and (f= 'P' OR f='Y')) as cae_no_email \n" +
                    " from bt group by bt.created_date,bt.bob,bt.filename ";
            return jdbcTemplate.query(query, new USPFinancialReportRowMapper());
        }catch (Exception e){
            LOGGER.error("Error while fetching USP3231 data from database", e);
            processlog.setErrorMessage("Error while fetching USP3231 data from database");
            throw e;
        }
    }

    public static class USPFinancialReportRowMapper implements RowMapper<USPFinancialReport> {
        @Override
        public USPFinancialReport mapRow(ResultSet rs, int rowNum) throws SQLException {
            USPFinancialReport uspFinancialReport = new USPFinancialReport();
            uspFinancialReport.setId(rs.getInt("id"));
            uspFinancialReport.setBob(rs.getString("bob"));
            uspFinancialReport.setTotalEobGenerated(rs.getInt("total"));
            uspFinancialReport.setTotalEobSuppressed(rs.getInt("suppr"));
            uspFinancialReport.setMemberElectionEob(rs.getInt("mem_supp"));
            uspFinancialReport.setPolicySettingEob(rs.getInt("policy_supp"));
            uspFinancialReport.setTotalEobPrinted(rs.getInt("print_supp"));
            uspFinancialReport.setTotalHsGenerated(rs.getInt("hs_total"));

            uspFinancialReport.setTotalHsSuppressed(rs.getInt("hs_suppr"));
            uspFinancialReport.setMemberElectionHs(rs.getInt("hs_mem_supp"));
            uspFinancialReport.setPolicySettingHs(rs.getInt("hs_policy_supp"));
            uspFinancialReport.setHsMemPrint(rs.getObject("hs_mem_print")==null?0:rs.getInt("hs_mem_print"));
            uspFinancialReport.setTotalHsPrinted(rs.getInt("hs_print_supp"));
            uspFinancialReport.setTotalCaeEobCount(rs.getInt("cae_total"));
            uspFinancialReport.setCaeEobMailCount(rs.getInt("cae_email"));
            uspFinancialReport.setCaeEobNoEmailCount(rs.getInt("cae_no_email"));
            uspFinancialReport.setFilename(rs.getString("filename"));
            LOGGER.info("Date String: {}", rs.getDate("created_date"));
            Date date = rs.getDate("created_date");
            if (date != null) {
                LocalDate localDate = LocalDate.parse(date.toString(), DateTimeFormatter.ofPattern(DATE_TIME_FORMATTER));
                uspFinancialReport.setCreatedDate(localDate.atStartOfDay());
                uspFinancialReport.setMonthYear(localDate);
            }
            uspFinancialReport.setCreatedBy(USP_FIN_REPORTING_SERVICE);
            return uspFinancialReport;
        }
    }
}
