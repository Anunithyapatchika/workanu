package com.uhg.comm.edelivery.reportingservice.exception;

public class USPException extends RuntimeException {

    public USPException(String message) {
        super(message);
    }

    public USPException(String message, Exception e) {
        super(message);
    }
}
