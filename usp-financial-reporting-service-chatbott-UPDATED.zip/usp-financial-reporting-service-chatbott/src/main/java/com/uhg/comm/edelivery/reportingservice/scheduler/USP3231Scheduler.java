package com.uhg.comm.edelivery.reportingservice.scheduler;


import com.uhg.comm.edelivery.reportingservice.service.USP3231DataService;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class USP3231Scheduler {

    private static final Logger LOGGER = LoggerFactory.getLogger(USP3231Scheduler.class);

    @Autowired
    private USP3231DataService  usp3231DataService;

    @Scheduled(cron = "${scheduler.poll.fetchUSP3231Data}")
    @SchedulerLock(name = "FetchUSP3231Data", lockAtMostFor = "6m", lockAtLeastFor = "230s")
    public void updateTotalRecordCount() {
        LOGGER.info("USP3231 Scheduler started..!!");
        usp3231DataService.process();
        LOGGER.info("USP3231 Scheduler completed..!!");
    }

}
