package com.uhg.comm.edelivery.reportingservice.service;

import com.uhg.comm.edelivery.reportingservice.constants.Constants;
import com.uhg.comm.edelivery.reportingservice.dto.PrintCostResponse;
import com.uhg.comm.edelivery.reportingservice.dto.PrintCostResponseItems;
import com.uhg.comm.edelivery.reportingservice.dto.PrintingCostDto;
import com.uhg.comm.edelivery.reportingservice.exception.USPException;
import com.uhg.comm.edelivery.reportingservice.model.PrintingCostReport;
import com.uhg.comm.edelivery.reportingservice.model.USPFinancialReport;
import com.uhg.comm.edelivery.reportingservice.repository.PrintingCostReportRepository;
import com.uhg.comm.edelivery.reportingservice.util.DateUtil;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Slf4j
public class PrintingCostReportService {


    @Autowired
    private PrintingCostReportRepository printingCostReportRepository;

    @Autowired
    private HSSuppCostReportService hsSuppCostReportService;

    @Autowired
    private USPFinancialReportService uspFinancialReportService;


    @Transactional(value = Transactional.TxType.REQUIRED)
    public boolean savePostageCostReport(PrintingCostDto printingCostDto) {
        List<String> errors = ValidationService.validate(printingCostDto);
        if (!errors.isEmpty()) {
            log.error("Validation failed for Printing Cost Report details: {}", errors);
            throw new USPException(errors.toString());
        }
        int id = printingCostDto.getId();
        if (id == 0) {
            log.info("Trying to save Printing Cost Report details in DB");
            PrintingCostReport printCostReport = getPrintCostReport(printingCostDto);
            printingCostReportRepository.save(printCostReport);
        } else {
            printingCostReportRepository.findById(id)
                    .ifPresentOrElse(printingCostReport -> {
                        log.info("Printing Cost Report details found in DB, updating the details");
                        PrintingCostReport printCostReport = getPrintCostReport(printingCostDto);
                        printingCostReportRepository.save(printCostReport);
                    }, () -> {
                        log.error("Printing Cost Report details not found in DB, failed to update the details");
                        throw new USPException("Printing Cost Report details not found in DB, failed to update the details");
                    });
        }
        if (Constants.PT3696_USP.equalsIgnoreCase(printingCostDto.getTrailName())) {
            hsSuppCostReportService.saveHsSuppDataFromPrintCostReport(getPrintCostReport(printingCostDto));
            log.info("HS Suppression Cost Report details saved successfully");
        } else if (Constants.PT3231_EOB.equalsIgnoreCase(printingCostDto.getTrailName())) {
            uspFinancialReportService.saveHsSuppDataFromPrintCostReportForPT3231(getPrintCostReport(printingCostDto));
            log.info("HS Suppression Cost Report details for PT3231 saved successfully");
        }

        return true;
    }

    public PrintingCostDto getByTrailBOBAndMonth(String trailName, String bob, String month) {
        Optional<PrintingCostReport> optional = printingCostReportRepository.findByTrailNameAndBobAndMonth(trailName, bob, month);
        return optional.map(this::getPrintCostDtoFromReport).orElse(null);
    }

    public List<PrintCostResponse> getPrintCostReportResponse(String trailName, LocalDate startDate, LocalDate endDate, List<USPFinancialReport> reports) {
        if (trailName.matches("^[a-zA-Z0-9._-]+$")) {
            log.info("Getting Printing Cost Report details for trailName: {}, startDate: {}, endDate: {}",
                    trailName, startDate, endDate);
        }
       List<PrintCostResponse> printCostResponseList = new ArrayList<>();
        List<PrintingCostReport> list = printingCostReportRepository.findByTrailNameAndDateBetween(trailName, startDate, endDate);
        List<PrintingCostReport> finalList = new ArrayList<>();
        List<USPFinancialReport> finalReports = new ArrayList<>();
        for (PrintingCostReport report : list) {
            for (USPFinancialReport r : reports) {
                if(r.getBob().equalsIgnoreCase(report.getBob()) && r.getMonthYearStr().equalsIgnoreCase(report.getMonth())){
                    finalList.add(report);
                    finalReports.add(r);
                }
            }
        }
        reports = new ArrayList<>(finalReports);
        if (finalList.isEmpty()) {
            log.error("Printing Cost Report details not found in DB");
            return new ArrayList<>();
        }

        LinkedHashMap<String, List<PrintingCostReport>> map = finalList.stream()
                .collect(Collectors.groupingBy(PrintingCostReport::getMonth, LinkedHashMap::new, Collectors.toList()));

        map.forEach((monthYear, reportList) -> {
            PrintCostResponse response = new PrintCostResponse(); // Creates a new EOB report DTO.
            response.setDate(monthYear); // Sets the date for the EOB report.
            response.setTrailNumber(trailName); // Sets the trail number for the EOB report.
            List<PrintCostResponseItems> printCostResponseItems = reportList.stream()
                    .map(PrintingCostReportService::getPrintCostReportResponseDto).collect(Collectors.toList()); // Maps the reports to EOB report items
            // Calculate Monthly Total
            PrintCostResponseItems monthlyTotal = getPrintCostReportItemDtoForMonthlyTotal(printCostResponseItems);
            printCostResponseItems.add(monthlyTotal); // Adds the monthly total to the EOB items.
            response.setItems(printCostResponseItems); // Sets the items for the EOB report.
            printCostResponseList.add(response); // Adds the EOB report to the list.
        });

        return printCostResponseList;
    }

    public static PrintCostResponseItems getPrintCostResponseItems(String bob, List<PrintCostResponseItems> items) {
        PrintCostResponseItems totalItem = new PrintCostResponseItems();
        totalItem.setBob(bob.equals("Monthly Total") ? "Total" : bob);

        double postageCost = BigDecimal.valueOf(items.stream().mapToDouble(PrintCostResponseItems::getPostageCost).sum()).setScale(2, RoundingMode.HALF_UP).doubleValue();
        double labourCost = BigDecimal.valueOf(items.stream().mapToDouble(PrintCostResponseItems::getPaperLabourCost).sum()).setScale(2, RoundingMode.HALF_UP).doubleValue();
        double costPerEnvelop = BigDecimal.valueOf(items.stream().mapToDouble(PrintCostResponseItems::getCostPerEnvelop).sum()).setScale(2, RoundingMode.HALF_UP).doubleValue();
        double envelopeCount = BigDecimal.valueOf(items.stream().mapToDouble(PrintCostResponseItems::getEnvelopeCount).sum()).setScale(2, RoundingMode.HALF_UP).doubleValue();

        totalItem.setPostageCost(postageCost);
        totalItem.setPaperLabourCost(labourCost); // Calculates the total EOBs suppressed.
        totalItem.setCostPerEnvelop(costPerEnvelop); // Calculates the total EOBs printed.
        totalItem.setEnvelopeCount(envelopeCount);

        return totalItem;
    }

    private static PrintCostResponseItems getPrintCostReportResponseDto(PrintingCostReport printingCostReport) {
        PrintCostResponseItems printCostResponseItems = new PrintCostResponseItems();
        printCostResponseItems.setBob(printingCostReport.getBob());
        printCostResponseItems.setPostageCost(printingCostReport.getPostageCost());
        printCostResponseItems.setPaperLabourCost(printingCostReport.getPrintExpenseCost());
        printCostResponseItems.setCostPerEnvelop(printingCostReport.getTotalExpPerEnvelop());
        printCostResponseItems.setEnvelopeCount(printingCostReport.getEnvelopCount());
        return printCostResponseItems;
    }

    private static PrintCostResponseItems getPrintCostReportItemDtoForMonthlyTotal(List<PrintCostResponseItems> items) {
        PrintCostResponseItems monthlyTotal = new PrintCostResponseItems();
        monthlyTotal.setBob("Monthly Total"); // Sets the bob field to "Monthly Total".

        double postageCost = BigDecimal.valueOf(items.stream().mapToDouble(PrintCostResponseItems::getPostageCost).sum()).setScale(2, RoundingMode.HALF_UP).doubleValue();
        double labourCost = BigDecimal.valueOf(items.stream().mapToDouble(PrintCostResponseItems::getPaperLabourCost).sum()).setScale(2, RoundingMode.HALF_UP).doubleValue();
        double costPerEnvelop = BigDecimal.valueOf(items.stream().mapToDouble(PrintCostResponseItems::getCostPerEnvelop).sum()).setScale(2, RoundingMode.HALF_UP).doubleValue();
        double envelopeCount = BigDecimal.valueOf(items.stream().mapToDouble(PrintCostResponseItems::getEnvelopeCount).sum()).setScale(2, RoundingMode.HALF_UP).doubleValue();

        monthlyTotal.setPostageCost(postageCost);
        monthlyTotal.setPaperLabourCost(labourCost);
        monthlyTotal.setCostPerEnvelop(costPerEnvelop);
        monthlyTotal.setEnvelopeCount(envelopeCount);

        return monthlyTotal;
    }

    private PrintingCostReport getPrintCostReport(PrintingCostDto printingCostDto) {
        String monthStr = printingCostDto.getMonth();
        LocalDate monthYear;
        try {
            monthYear = DateUtil.getLocalDate(monthStr, Constants.MONTH_YEAR_FORMAT);
        } catch (Exception e) {
            log.error("Error while parsing date", e);
            throw new USPException("Error while parsing date", e);
        }

        PrintingCostReport printingCostReport = PrintingCostReport.builder()
                .bob(printingCostDto.getBob())
                .trailName(printingCostDto.getTrailName())
                .month(monthStr)
                .monthYear(monthYear)
                .imageCount(printingCostDto.getImageCount())
                .envelopCount(printingCostDto.getEnvelopCount())
                .printExpenseCost(printingCostDto.getPrintExpenseCost())
                .postageCost(printingCostDto.getPostageCost())
                .totalExpense(printingCostDto.getTotalExpense())
                .imagePerEnvelop(printingCostDto.getImagePerEnvelop())
                .printExpPerImage(printingCostDto.getPrintExpPerImage())
                .printExpPerEnvelop(printingCostDto.getPrintExpPerEnvelop())
                .postageExpPerEnvelop(printingCostDto.getPostageExpPerEnvelop())
                .totalExpPerEnvelop(printingCostDto.getTotalExpPerEnvelop())
                .paperCount(printingCostDto.getPaperCount())
                .createdBy(printingCostDto.getUserId())
                .modifiedBy(printingCostDto.getUserId())
                .createdDate(LocalDateTime.now())
                .modifiedDate(LocalDateTime.now())
                .build();

        if (printingCostDto.getId() > 0) {
            printingCostReport.setId(printingCostDto.getId());
        }
        return printingCostReport;
    }

    private PrintingCostDto getPrintCostDtoFromReport(PrintingCostReport costReport) {
        return PrintingCostDto.builder()
                .id(costReport.getId())
                .bob(costReport.getBob())
                .trailName(costReport.getTrailName())
                .month(costReport.getMonth())
                .imageCount(costReport.getImageCount())
                .envelopCount(costReport.getEnvelopCount())
                .printExpenseCost(costReport.getPrintExpenseCost())
                .postageCost(costReport.getPostageCost())
                .totalExpense(costReport.getTotalExpense())
                .imagePerEnvelop(costReport.getImagePerEnvelop())
                .printExpPerImage(costReport.getPrintExpPerImage())
                .printExpPerEnvelop(costReport.getPrintExpPerEnvelop())
                .postageExpPerEnvelop(costReport.getPostageExpPerEnvelop())
                .totalExpPerEnvelop(costReport.getTotalExpPerEnvelop())
                .paperCount(costReport.getPaperCount())
                .userId(costReport.getCreatedBy())
                .build();
    }

}

