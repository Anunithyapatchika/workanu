package com.uhg.comm.edelivery.reportingservice.util;

import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.core.http.rest.PagedIterable;
import com.azure.storage.blob.*;
import com.azure.storage.blob.models.BlobItem;
import com.azure.storage.blob.models.ListBlobsOptions;
import com.azure.storage.blob.specialized.BlobInputStream;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import static com.uhg.comm.edelivery.reportingservice.constants.AzureVaultKey.*;
import static com.uhg.comm.edelivery.reportingservice.constants.Constants.UCSFile;

@Service
@Slf4j
public class BlobUtils {

	private final SecretClient secretClient;


	private static final Logger LOGGER = LoggerFactory.getLogger(BlobUtils.class);

	@Value("${blobclient.endpoint}")
	private String endpoint;

	@Value("${blobclient.containerName}")
	private String containerName;

	@Value("${blobclient.pdfContainerName}")
	private String pdfContainerName;

	// New extenal storage account
	@Value("${blobclient.extendpoint}")
	private String extendpoint;

	@Value("${blobclient.extcontainerName}")
	private String extcontainerName;

    @Value("${blobclient.chatBotStorageEndPoint}")
    private String chatBotStorageEndPoint;

    @Value("${blobclient.imageContainer}")
    private String imageContainer;


    public BlobUtils(SecretClient secretClient) {
        this.secretClient = secretClient;
    }

	public BlobClient getBlobClient(String fileName) {
        log.info("Print all the values from BlobUtils class endpoint: {}, containerName: {}, fileName: {}", endpoint, containerName, fileName);
		BlobServiceClient blobServiceClient = new BlobServiceClientBuilder().endpoint(endpoint)
				.connectionString(secretClient.getSecret(STORAGE_ACC_KEY).getValue()).buildClient();
		BlobContainerClient containerClient = blobServiceClient.getBlobContainerClient(containerName);
        log.info("no isseue");
		return containerClient.getBlobClient(fileName);
	}


	public BlobClient getPdfBlobClient(String fileName,String flag) {
		if(flag.equalsIgnoreCase(UCSFile)){
			BlobServiceClient blobServiceClient = new BlobServiceClientBuilder().endpoint(endpoint)
					.connectionString(secretClient.getSecret(STORAGE_ACC_KEY).getValue()).buildClient();
			BlobContainerClient containerClient = blobServiceClient.getBlobContainerClient(pdfContainerName);
			return containerClient.getBlobClient(fileName);
		}else {
			BlobServiceClient blobServiceClient = new BlobServiceClientBuilder().endpoint(extendpoint)
					.connectionString(secretClient.getSecret(STORAGE_ACC_KEY_EXT).getValue()).buildClient();
			BlobContainerClient containerClient = blobServiceClient.getBlobContainerClient(extcontainerName);
			return containerClient.getBlobClient(fileName);
		}
	}

	public BlobContainerClient getBlobClient() {
		BlobServiceClient blobServiceClient = new BlobServiceClientBuilder().endpoint(endpoint)
				.connectionString(secretClient.getSecret(STORAGE_ACC_KEY).getValue()).buildClient();

		return blobServiceClient.getBlobContainerClient(containerName);
	}

	public List<String> getBlobItemsList(String fileName) {

		BlobContainerClient containerClient = getBlobClient();
		List<String> blobNames = new ArrayList<>();

		String fullPrefix = "quadient/composed/OptumRx_ pt3696/" + fileName;

		ListBlobsOptions options = new ListBlobsOptions().setPrefix(fullPrefix);
		for (BlobItem blobItem : containerClient.listBlobs(options, null)) {
			blobNames.add(blobItem.getName());
		}

		return blobNames;
	}

    public List<byte[]> getImagesFromBlobFolder(String filePath) {
        List<byte[]> images = new ArrayList<>();
        BlobContainerClient containerClient = new BlobContainerClientBuilder()
                .endpoint(chatBotStorageEndPoint)
                .connectionString(secretClient.getSecret(AI_STORAGE_ACC_KEY).getValue())
                .containerName(imageContainer)
                .buildClient();
        LOGGER.info("Get images from blob folder: {}", filePath);
        // List blobs with the given prefix (folder path)
        for (BlobItem blobItem : containerClient.listBlobsByHierarchy(filePath+"/")) {
            String blobName = blobItem.getName();
            LOGGER.info("blobName: {}", blobName);
            if (blobName.endsWith(".png") || blobName.endsWith(".jpg") || blobName.endsWith(".jpeg") || blobName.endsWith(".gif")) {
                BlobClient blobClient = containerClient.getBlobClient(blobName);
                try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
                    blobClient.download(outputStream);
                    images.add(outputStream.toByteArray());
                    LOGGER.info("Downloaded image from blob: {}", blobName);
                } catch (IOException e) {
                    LOGGER.info("error occurred while downloading image from blob: {}", e.getLocalizedMessage());
                }
            }
        }
        LOGGER.info("SuccessFully downloaded image :{}",images);
        return images;
    }



}
