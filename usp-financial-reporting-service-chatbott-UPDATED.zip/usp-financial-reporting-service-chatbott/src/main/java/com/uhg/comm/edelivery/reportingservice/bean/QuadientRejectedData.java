package com.uhg.comm.edelivery.reportingservice.bean;

import lombok.Data;

@Data
public class QuadientRejectedData {
	
	private String uniqueId;
	private String status;
	private String errorCode;
	private String errorMessage;
	private String errorWorkflow;

}
