package com.uhg.comm.edelivery.reportingservice.service;

import com.microsoft.azure.eventgrid.models.StorageBlobCreatedEventData;
import com.uhg.comm.edelivery.processLog.Processlog;

public interface USP3231DataService {

    void completeTrxForPrevMonth(Processlog processlog);

    void process();
}
