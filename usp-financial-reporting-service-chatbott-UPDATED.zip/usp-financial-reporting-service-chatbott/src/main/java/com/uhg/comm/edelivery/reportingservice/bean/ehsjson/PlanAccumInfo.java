package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "planTyp", "planAccumTyp", "planEffDt", "planEndDt", "accumDefMsg", "accumMsgTxt", "accumMsgId",
		"accumDetails" })
@Generated("jsonschema2pojo")
public class PlanAccumInfo {

	@JsonProperty("planTyp")
	private String planTyp;
	@JsonProperty("planAccumTyp")
	private String planAccumTyp;
	@JsonProperty("planEffDt")
	private String planEffDt;
	@JsonProperty("planEndDt")
	private String planEndDt;
	@JsonProperty("accumDefMsg")
	private String accumDefMsg;
	@JsonProperty("accumMsgTxt")
	private String accumMsgTxt;
	@JsonProperty("accumMsgId")
	private String accumMsgId;
	@JsonProperty("accumDetails")
	private List<AccumDetail> accumDetails = null;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("planTyp")
	public String getPlanTyp() {
		return planTyp;
	}

	@JsonProperty("planTyp")
	public void setPlanTyp(String planTyp) {
		this.planTyp = planTyp;
	}

	@JsonProperty("planAccumTyp")
	public String getPlanAccumTyp() {
		return planAccumTyp;
	}

	@JsonProperty("planAccumTyp")
	public void setPlanAccumTyp(String planAccumTyp) {
		this.planAccumTyp = planAccumTyp;
	}

	@JsonProperty("planEffDt")
	public String getPlanEffDt() {
		return planEffDt;
	}

	@JsonProperty("planEffDt")
	public void setPlanEffDt(String planEffDt) {
		this.planEffDt = planEffDt;
	}

	@JsonProperty("planEndDt")
	public String getPlanEndDt() {
		return planEndDt;
	}

	@JsonProperty("planEndDt")
	public void setPlanEndDt(String planEndDt) {
		this.planEndDt = planEndDt;
	}

	@JsonProperty("accumDefMsg")
	public String getAccumDefMsg() {
		return accumDefMsg;
	}

	@JsonProperty("accumDefMsg")
	public void setAccumDefMsg(String accumDefMsg) {
		this.accumDefMsg = accumDefMsg;
	}

	@JsonProperty("accumMsgTxt")
	public String getAccumMsgTxt() {
		return accumMsgTxt;
	}

	@JsonProperty("accumMsgTxt")
	public void setAccumMsgTxt(String accumMsgTxt) {
		this.accumMsgTxt = accumMsgTxt;
	}

	@JsonProperty("accumMsgId")
	public String getAccumMsgId() {
		return accumMsgId;
	}

	@JsonProperty("accumMsgId")
	public void setAccumMsgId(String accumMsgId) {
		this.accumMsgId = accumMsgId;
	}

	@JsonProperty("accumDetails")
	public List<AccumDetail> getAccumDetails() {
		return accumDetails;
	}

	@JsonProperty("accumDetails")
	public void setAccumDetails(List<AccumDetail> accumDetails) {
		this.accumDetails = accumDetails;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(PlanAccumInfo.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this)))
				.append('[');
		sb.append("planTyp");
		sb.append('=');
		sb.append(((this.planTyp == null) ? "<null>" : this.planTyp));
		sb.append(',');
		sb.append("planAccumTyp");
		sb.append('=');
		sb.append(((this.planAccumTyp == null) ? "<null>" : this.planAccumTyp));
		sb.append(',');
		sb.append("planEffDt");
		sb.append('=');
		sb.append(((this.planEffDt == null) ? "<null>" : this.planEffDt));
		sb.append(',');
		sb.append("planEndDt");
		sb.append('=');
		sb.append(((this.planEndDt == null) ? "<null>" : this.planEndDt));
		sb.append(',');
		sb.append("accumDefMsg");
		sb.append('=');
		sb.append(((this.accumDefMsg == null) ? "<null>" : this.accumDefMsg));
		sb.append(',');
		sb.append("accumMsgTxt");
		sb.append('=');
		sb.append(((this.accumMsgTxt == null) ? "<null>" : this.accumMsgTxt));
		sb.append(',');
		sb.append("accumMsgId");
		sb.append('=');
		sb.append(((this.accumMsgId == null) ? "<null>" : this.accumMsgId));
		sb.append(',');
		sb.append("accumDetails");
		sb.append('=');
		sb.append(((this.accumDetails == null) ? "<null>" : this.accumDetails));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
