package com.uhg.comm.edelivery.reportingservice.constants;

public class Constants {

    private Constants() {}

    public static final String PT3696_USP = "PT3696-USP HS";
    public static final String SERVICE_NAME = "USP-financial-reporting-service";

    public static final String MONTH_YEAR_FORMAT = "MMMM yyyy";

    public static final String USP_REPORTING_UI_SERVICE = "USP Reporting UI Service";

    public static final String MONTHLY_TOTAL = "Monthly Total";

    public static final String PERIOD_TOTAL = "Period Total";

    public static final String TOTAL = "Total";
    public static final String PT3231_EOB = "PT3231-USP EOB";

    public static final String DATE_TIME_FORMATTER = "yyyy-MM-dd";

    public static final String USP_REPORTING_ONPREM_SERVICE = "USP Reporting onPrem Service";

    public static final String USP_FIN_REPORTING_SERVICE = "USP Financial Reporting Service";

    public static final String OAUTHURI = "oauthuri";
    public static final String CLIENTID = "clientid";
    public static final String CLIENTSECRET = "clientsecret";
    public static final String OPTUM_RX_IS_PRODUCTION="isProduction";
    public static final String OPTUM_RX_IS_APPROVAL_PACKAGE="isApprovalPackage";
    public static final String OPTUM_RX_COMM_CODE="commCode";
    public static final String OPTUM_RX_COMM_FAMILY="CommFamily";
    public static final String OPTUM_RX_COMM_TYPE="commType";
    public static final String OPTUM_RX_PARENTAL_JOB_ID="parentJobId";
    public static final String OPTUM_RX_EXTERNAL_ID="externalId";
    public static final String OPTUM_RX_REQ_ID="reqId";
    public static final String OPTUM_RX_JOB_TYPE="TestInd";
    public static final String OPTUM_RX_COMPARE_TYPE="compareType";
    public static final String OPTUM_RX_REQUEST_TYPE="request_type";
    public static final String OPTUM_RX_REQUEST_TYPE_ON_DEMAND="Standard";
    public static final String OPTUM_RX_REQUEST_TYPE_BATCH_CONSOLIDATION="batchConsolidation";
    public static final String BATCH_DELIVERY = "batchDelivery";
    public static final String OPTUM_RX_USER_ID="userId";
    public static final String OPTUM_RX_USER_ID_VALUE="UCS";
    public static final String OPTUM_RX_INBOUND_STATUS="inboundStatus";
    public static final String AUTHORIZATION = "Authorization";
    public static final String SUPPRESS_INDICATOR = "suppressIndicator";
    public static final String ACCEPTED = "accepted";
    public static final String FAILED = "failed";
    public static final String DUPLICATE = "[DUPLICATE]";
    public static final String UCSFile = "ucsFile";



}
