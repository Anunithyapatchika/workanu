package com.uhg.comm.edelivery.reportingservice.service;

import com.uhg.comm.edelivery.processLog.Processlog;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

public interface SendEmailService {

    boolean sendEmail(Processlog processlog);
}
