package com.uhg.comm.edelivery.reportingservice.dto;

import lombok.Data;

@Data
public class SuppressionChgResponseItem {
    private String bob;
    private double oldEOBPrint;
    private double oldEOBSuppress;
    private double oldEOBAffected;
}
