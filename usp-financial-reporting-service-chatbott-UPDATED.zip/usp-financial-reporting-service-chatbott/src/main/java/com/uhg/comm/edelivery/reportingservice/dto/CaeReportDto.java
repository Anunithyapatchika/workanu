package com.uhg.comm.edelivery.reportingservice.dto;

import lombok.Data;
import java.util.List;

@Data
public class CaeReportDto {
    private String date;
    private String trailNumber;
    private List<CaeReportItemDto> items;
}