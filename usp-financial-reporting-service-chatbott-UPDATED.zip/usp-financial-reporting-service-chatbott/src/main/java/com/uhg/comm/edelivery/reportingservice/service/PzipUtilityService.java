package com.uhg.comm.edelivery.reportingservice.service;

import java.util.List;

import com.uhg.comm.edelivery.reportingservice.bean.ApiResponse;
import com.uhg.comm.edelivery.reportingservice.bean.BatchDeliveryRequest;
import com.uhg.comm.edelivery.reportingservice.bean.BatchFile;
import com.uhg.comm.edelivery.reportingservice.bean.OnDemandApiRequest;

public interface PzipUtilityService {

	ApiResponse callOnDemandApi(OnDemandApiRequest onDemandBody, String jobId, String supressIndictor,String trailType, String tnoId);

    ApiResponse callBatchConsolidationApi(String jobId, BatchFile batchConsolidationBody, String token, String batchConsolidationRequestBody);

    ApiResponse callBatchDeliveryApi(String jobId,String trailType, String inputFileName, BatchDeliveryRequest batchDeliveryRequestBody);

	List<String> getListOfFilesFromBlob(String inputFileName);
}
