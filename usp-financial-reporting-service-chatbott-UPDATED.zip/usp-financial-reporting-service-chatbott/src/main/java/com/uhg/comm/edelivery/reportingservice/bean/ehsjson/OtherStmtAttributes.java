package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "polAccumTypCd" })
@Generated("jsonschema2pojo")
public class OtherStmtAttributes {

	@JsonProperty("polAccumTypCd")
	private String polAccumTypCd;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("polAccumTypCd")
	public String getPolAccumTypCd() {
		return polAccumTypCd;
	}

	@JsonProperty("polAccumTypCd")
	public void setPolAccumTypCd(String polAccumTypCd) {
		this.polAccumTypCd = polAccumTypCd;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(OtherStmtAttributes.class.getName()).append('@')
				.append(Integer.toHexString(System.identityHashCode(this))).append('[');
		sb.append("polAccumTypCd");
		sb.append('=');
		sb.append(((this.polAccumTypCd == null) ? "<null>" : this.polAccumTypCd));
		sb.append(',');
		sb.append("additionalProperties");
		sb.append('=');
		sb.append(((this.additionalProperties == null) ? "<null>" : this.additionalProperties));
		sb.append(',');
		if (sb.charAt((sb.length() - 1)) == ',') {
			sb.setCharAt((sb.length() - 1), ']');
		} else {
			sb.append(']');
		}
		return sb.toString();
	}

}
