package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import lombok.Data;

@Data
public class AddressCleanseRecord {

	private String jobId;

	private String statementNum;

	private CleansedAddress cleansedAddress;

}
