package com.uhg.comm.edelivery.reportingservice.dto;

import lombok.Data;

import java.util.List;

@Data
public class EHSFinancialReportResponseDto {
    private List<HsSuppCostDto> hsSuppCostReport;
    private List<EHSSuppressionChgResponse> ehsSuppressionChgResponses;

}
