package com.uhg.comm.edelivery.reportingservice.bean;

import lombok.Data;

@Data
public class ZipInfo {
	
	private String zipFileName;
    private String zipBLOBPath;
    private String recordCount;

}
