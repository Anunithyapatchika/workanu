package com.uhg.comm.edelivery.reportingservice.controller;

import com.uhg.comm.edelivery.reportingservice.dto.PrintingCostDto;
import com.uhg.comm.edelivery.reportingservice.service.PrintingCostReportService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("postage-report")
@CrossOrigin
@Slf4j
public class PrintingCostReportController {

    @Autowired
    private PrintingCostReportService printingCostReportService;

    @PostMapping(value = "/save", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> savePostageCostReport(@RequestBody PrintingCostDto printingCostDto) {
        boolean result = printingCostReportService.savePostageCostReport(printingCostDto);
        if (result) {
            return ResponseEntity.ok("Success");
        } else {
            return ResponseEntity.badRequest().body("Failed");
        }
    }

    @GetMapping(value = "/get", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<PrintingCostDto> checkExistingData(@RequestParam String trailName, @RequestParam String bob,
                                                             @RequestParam String month) {
        PrintingCostDto printingCostDto = printingCostReportService.getByTrailBOBAndMonth(trailName, bob, month);
        if (printingCostDto != null) {
            return ResponseEntity.ok(printingCostDto);
        } else {
            return ResponseEntity.badRequest().body(null);
        }
    }
}
