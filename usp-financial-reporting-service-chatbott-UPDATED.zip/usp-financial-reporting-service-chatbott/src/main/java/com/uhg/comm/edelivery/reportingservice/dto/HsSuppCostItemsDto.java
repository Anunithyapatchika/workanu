package com.uhg.comm.edelivery.reportingservice.dto;

import lombok.Data;

@Data
public class HsSuppCostItemsDto {

    private String bob;
    private double postageCost;
    private double printCost;
    private double stmtPrinted;
    private double hsSuppMemberElection;
    private double hsSuppPolicySetting;
    private double totalStmtSupp;
    private double totalStmtGenerated;
    private double totalPrintPostCost;
    private double hsSuppressedPercent;
    private double costPerPrintedStmt;
    private double totalSheets;
    private double sheetsPerPrintedStmt;
    private double numberOfClaims;
}
