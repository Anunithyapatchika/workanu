package com.uhg.comm.edelivery.reportingservice.bean.ehsjson;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.processing.Generated;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Health_Statement", "Address_data", "Pref" })
@Generated("jsonschema2pojo")
public class HsPackage {

	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("Health_Statement")
	private List<JsonHealthStatement> jsonHealthStatement;
	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("Address_data")
	private List<AddressCleanseRecord> addressData;
	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("Pref")
	private List<MemberPref> pref;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("Health_Statement")
	public List<JsonHealthStatement> getJsonHealthStatement() {
		return jsonHealthStatement;
	}

	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("Health_Statement")
	public void setJsonHealthStatement(List<JsonHealthStatement> jsonHealthStatement) {
		this.jsonHealthStatement = jsonHealthStatement;
	}

	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("Address_data")
	public List<AddressCleanseRecord> getAddressData() {
		return addressData;
	}

	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("Address_data")
	public void setAddressData(List<AddressCleanseRecord> addressData) {
		this.addressData = addressData;
	}

	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("Pref")
	public List<MemberPref> getPref() {
		return pref;
	}

	/**
	 *
	 * (Required)
	 *
	 */
	@JsonProperty("Pref")
	public void setPref(List<MemberPref> pref) {
		this.pref = pref;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}