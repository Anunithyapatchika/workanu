package com.uhg.comm.edelivery.reportingservice.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.thymeleaf.spring6.SpringTemplateEngine;


@Configuration
public class SpringTemplateConfig {

    @Bean
    public SpringTemplateEngine getSpringTemplate() {
        return new SpringTemplateEngine();
    }


}