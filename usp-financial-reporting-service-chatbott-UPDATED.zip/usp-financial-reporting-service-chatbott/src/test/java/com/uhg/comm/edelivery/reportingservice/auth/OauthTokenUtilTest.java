package com.uhg.comm.edelivery.reportingservice.auth;

import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.models.KeyVaultSecret;
import com.uhg.comm.edelivery.reportingservice.model.OAuthResponseObj;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Mono;

import static com.uhg.comm.edelivery.reportingservice.constants.AzureVaultKey.EDEL_API_CLIENTID;
import static com.uhg.comm.edelivery.reportingservice.constants.AzureVaultKey.EDEL_API_CLIENTSECRET;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.lenient;

@ExtendWith(MockitoExtension.class)
public class OauthTokenUtilTest {

    @Mock
    private WebClient webClient;

    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private SecretClient secretClient;

    @InjectMocks
    private OauthTokenUtil oauthTokenUtil;

    private final String TEST_AUTH_URL = "https://test-auth-url.com/token";
    private final String TEST_CLIENT_ID = "test-client-id";
    private final String TEST_CLIENT_SECRET = "test-client-secret";
    private final String TEST_ACCESS_TOKEN = "test-access-token";

    @BeforeEach
    public void setup() {
        ReflectionTestUtils.setField(oauthTokenUtil, "authUrl", TEST_AUTH_URL);
        ReflectionTestUtils.setField(oauthTokenUtil, "webClient", webClient);
        lenient().when(secretClient.getSecret(EDEL_API_CLIENTID)).thenReturn(new KeyVaultSecret(EDEL_API_CLIENTID, TEST_CLIENT_ID));
        lenient().when(secretClient.getSecret(EDEL_API_CLIENTSECRET)).thenReturn(new KeyVaultSecret(EDEL_API_CLIENTSECRET, TEST_CLIENT_SECRET));
    }

    @Test
    public void testCallSecurityToken_Success() {
        // Setup mock chain
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(TEST_AUTH_URL)).thenReturn(requestBodySpec);
        when(requestBodySpec.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE))
                .thenReturn(requestBodySpec);
        when(requestBodySpec.header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE))
                .thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(OAuthResponseObj.class)).thenReturn(Mono.just(getSuccessResponse()));

        // Execute
        String token = oauthTokenUtil.callSecurityToken();

        // Verify
        assertNotNull(token);
        assertEquals(TEST_ACCESS_TOKEN, token);
    }

    @Test
    public void testCallSecurityToken_NullResponse() {
        // Setup mock chain
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(TEST_AUTH_URL)).thenReturn(requestBodySpec);
        when(requestBodySpec.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE))
                .thenReturn(requestBodySpec);
        when(requestBodySpec.header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE))
                .thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(OAuthResponseObj.class)).thenReturn(Mono.just(ResponseEntity.ok().body(null)));

        // Execute
        String token = oauthTokenUtil.callSecurityToken();

        // Verify
        assertEquals("", token);
    }

    @Test
    public void testCallSecurityToken_Exception() {
        // Setup mock chain
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(TEST_AUTH_URL)).thenReturn(requestBodySpec);
        when(requestBodySpec.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE))
                .thenReturn(requestBodySpec);
        when(requestBodySpec.header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE))
                .thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(OAuthResponseObj.class)).thenReturn(Mono.error(new RuntimeException("Test Exception")));

        // Execute
        String token = oauthTokenUtil.callSecurityToken();

        // Verify
        assertEquals("", token);
    }

    @Test
    public void testCallSecurityToken_NullAccessToken() {
        // Setup mock chain
        ResponseEntity<OAuthResponseObj> responseWithNullToken = ResponseEntity.ok().body(new OAuthResponseObj());

        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(TEST_AUTH_URL)).thenReturn(requestBodySpec);
        when(requestBodySpec.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE))
                .thenReturn(requestBodySpec);
        when(requestBodySpec.header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE))
                .thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(OAuthResponseObj.class)).thenReturn(Mono.just(responseWithNullToken));

        // Execute
        String token = oauthTokenUtil.callSecurityToken();

        // Verify
        assertEquals("", token);
    }

    @Test
    public void testGetSecTknFormParams() throws Exception {
        MultiValueMap<String, String> params = ReflectionTestUtils.invokeMethod(oauthTokenUtil, "getSecTknFormParams");
        assertEquals("client_credentials", params.getFirst("grant_type"));
        assertEquals(TEST_CLIENT_ID, params.getFirst("client_id"));
        assertEquals(TEST_CLIENT_SECRET, params.getFirst("client_secret"));
    }

    @Test
    public void testConstructor() {
        OauthTokenUtil util = new OauthTokenUtil(secretClient);
        assertNotNull(util);
    }

    private ResponseEntity<OAuthResponseObj> getSuccessResponse() {
        OAuthResponseObj oAuthResponseObj = new OAuthResponseObj();
        oAuthResponseObj.setAccess_token(TEST_ACCESS_TOKEN);
        oAuthResponseObj.setToken_type("Bearer");
        oAuthResponseObj.setExpires_in(3600);
        return ResponseEntity.ok().body(oAuthResponseObj);
    }
}