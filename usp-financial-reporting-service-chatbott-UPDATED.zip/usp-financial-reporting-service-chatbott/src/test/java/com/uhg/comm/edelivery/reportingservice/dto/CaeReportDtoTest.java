package com.uhg.comm.edelivery.reportingservice.dto;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CaeReportDtoTest {
    @Test
    void testGettersAndSetters() {
        CaeReportDto caeReport = new CaeReportDto();
        caeReport.setDate("2023-10");
        caeReport.setTrailNumber("12345");
        List<CaeReportItemDto> items = new ArrayList<>();
        caeReport.setItems(items);

        assertEquals("2023-10", caeReport.getDate());
        assertEquals("12345", caeReport.getTrailNumber());
        assertEquals(items, caeReport.getItems());
    }

    @Test
    void testEqualsAndHashCode() {
        CaeReportDto caeReport = new CaeReportDto();
        caeReport.setDate("2023-10");
        caeReport.setTrailNumber("12345");

        CaeReportDto caeReport2 = new CaeReportDto();
        caeReport2.setDate("2023-10");
        caeReport2.setTrailNumber("12345");

        assertEquals(caeReport, caeReport2);
        assertEquals(caeReport.hashCode(), caeReport2.hashCode());
    }

    @Test
    void testToString() {
        CaeReportDto caeReport = new CaeReportDto();
        caeReport.setDate("2023-10");
        caeReport.setTrailNumber("12345");

        String expected = "CaeReportDto(date=2023-10, trailNumber=12345, items=null)";
        assertEquals(expected, caeReport.toString());
    }

}