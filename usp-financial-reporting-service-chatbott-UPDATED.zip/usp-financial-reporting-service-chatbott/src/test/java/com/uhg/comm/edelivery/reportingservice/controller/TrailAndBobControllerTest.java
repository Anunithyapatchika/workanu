package com.uhg.comm.edelivery.reportingservice.controller;

import com.uhg.comm.edelivery.reportingservice.model.TrailAndBobDetails;
import com.uhg.comm.edelivery.reportingservice.service.TrailAndBobDetailsService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TrailAndBobControllerTest {

    @InjectMocks
    private TrailAndBobController trailAndBobController;

    @Mock
    private TrailAndBobDetailsService trailAndBobDetailsService;

    private Set<TrailAndBobDetails> mockTrailAndBobDetailsSet;

    @BeforeEach
    void setUp() {
        mockTrailAndBobDetailsSet = new HashSet<>();
        TrailAndBobDetails trailAndBobDetails = new TrailAndBobDetails();
        trailAndBobDetails.setBobName("bob1");
        trailAndBobDetails.setTrailNumber("trail1");

        mockTrailAndBobDetailsSet.add(trailAndBobDetails);
    }

    @Test
    void testGetTrailAndBodDetails() {
        when(trailAndBobDetailsService.getActiveTrailAndBobDetails()).thenReturn(mockTrailAndBobDetailsSet);

        ResponseEntity<Set<TrailAndBobDetails>> response = trailAndBobController.getTrailAndBodDetails();

        assertEquals(mockTrailAndBobDetailsSet, response.getBody());
        assertEquals(200, response.getStatusCodeValue());
    }
}