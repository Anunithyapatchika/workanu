package com.uhg.comm.edelivery.reportingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class USPReportApplicationTests {

//	@Test
	void contextLoads() {
	}

}
