package com.uhg.comm.edelivery.reportingservice.nesslogger;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Properties;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class NessLoggerConfigTest {

	@InjectMocks
	private NessLoggerConfig nessLoggerConfig;

	private final Properties properties = new Properties();

	@BeforeEach
	void setup() {
		ReflectionTestUtils.setField(nessLoggerConfig, "applicationAskId", "applicationAskIdValue");
		ReflectionTestUtils.setField(nessLoggerConfig, "applicationName", "applicationNameValue");
		ReflectionTestUtils.setField(nessLoggerConfig, "deviceVendor", "deviceVendorValue");
		ReflectionTestUtils.setField(nessLoggerConfig, "deviceProduct", "deviceProductValue");
		ReflectionTestUtils.setField(nessLoggerConfig, "hostName", "host_name");
	}

	@Test
	void test_loadRequiredFields() throws Exception {
		Properties actual = nessLoggerConfig.loadRequiredFields(properties);
		assertNotNull(actual);
	}

	@Test
	void test_getDeviceIp4() throws Exception {
		String actual = nessLoggerConfig.getDeviceIp4();
		assertNotNull(actual);
	}

}
