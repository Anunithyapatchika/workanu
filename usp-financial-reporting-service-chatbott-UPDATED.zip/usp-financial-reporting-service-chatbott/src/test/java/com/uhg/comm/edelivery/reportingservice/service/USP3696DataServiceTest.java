package com.uhg.comm.edelivery.reportingservice.service;

import com.uhg.comm.edelivery.processLog.Processlog;
import com.uhg.comm.edelivery.reportingservice.model.HSSuppCostReport;
import com.uhg.comm.edelivery.reportingservice.model.TrailAndBobDetails;
import com.uhg.comm.edelivery.reportingservice.model.USP3696Data;
import com.uhg.comm.edelivery.reportingservice.nesslogger.NessLoggerService;
import com.uhg.comm.edelivery.reportingservice.repository.HSSuppCostReportRepository;
import com.uhg.comm.edelivery.reportingservice.repository.TrailAndBobRepository;
import com.uhg.comm.edelivery.reportingservice.repository.USP3696DataRepository;
import com.uhg.comm.edelivery.reportingservice.util.DateUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static com.uhg.comm.edelivery.reportingservice.constants.Constants.MONTH_YEAR_FORMAT;
import static com.uhg.comm.edelivery.reportingservice.constants.Constants.PT3696_USP;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class USP3696DataServiceTest {

    @Spy
    @InjectMocks
    private USP3696DataService usp3696DataService;

    @Mock
    private USP3696DataRepository usp3696DataRepo;

    @Mock
    private HSSuppCostReportRepository hsSuppCostReportRepo;

    @Mock
    private NessLoggerService nessLoggerService;

    @Mock
    private SendEmailService sendEmailService;

    @Mock
    private TrailAndBobRepository trailAndBobRepository;

    @Captor
    private ArgumentCaptor<HSSuppCostReport> hsSuppCostReportCaptor;

    @Test
    void processTest_Success() {
        // Arrange
        USP3696Data usp3696Data = new USP3696Data();
        usp3696Data.setBookOfBusiness("Oxford");
        usp3696Data.setCreatedDate(Date.valueOf("2024-07-10"));
        usp3696Data.setPrintCount(100);
        usp3696Data.setMemSupp(20);
        usp3696Data.setPolicySupp(10);
        usp3696Data.setTotal(130);
        usp3696Data.setSuppress(30);
        usp3696Data.setClaimCount(50);

        List<USP3696Data> usp3696DataList = List.of(usp3696Data);
        ReflectionTestUtils.setField(usp3696DataService, "dateFilter", "dateFilter");
        ReflectionTestUtils.setField(usp3696DataService, "minusDays", 1L);

        when(usp3696DataRepo.getUSP3696Data(anyString(), any())).thenReturn(usp3696DataList);
        doNothing().when(usp3696DataService).processUSP3696Data(any(), any());
//        when(trailAndBobRepository.findByTrailNumber(anyString())).thenReturn(Set.of(new TrailAndBobDetails()));
        doNothing().when(usp3696DataService).markTxComlpletedforlPrevMonth(any());
        doNothing().when(usp3696DataService).updateNewBoB(any(), any());
        when(sendEmailService.sendEmail(any())).thenReturn(true);
        doNothing().when(nessLoggerService).publishNesslogsToSplunk(anyString());

        // Act
        usp3696DataService.process();

        // Assert
        verify(usp3696DataRepo).getUSP3696Data(eq("dateFilter"), any(Processlog.class));
        verify(usp3696DataService).processUSP3696Data(eq(usp3696DataList), any(Processlog.class));
        verify(sendEmailService).sendEmail(argThat(processlog -> "SUCCESS".equals(processlog.getStatus())));
        verify(usp3696DataService).markTxComlpletedforlPrevMonth(any(Processlog.class));
        verify(usp3696DataService).updateNewBoB(eq(usp3696DataList), any(Processlog.class));
    }

    @Test
    void processTest_NoData() {
        // Arrange
        List<USP3696Data> emptyList = new ArrayList<>();
        ReflectionTestUtils.setField(usp3696DataService, "dateFilter", "dateFilter");
        ReflectionTestUtils.setField(usp3696DataService, "minusDays", 1L);

        when(usp3696DataRepo.getUSP3696Data(anyString(), any())).thenReturn(emptyList);
        when(sendEmailService.sendEmail(any())).thenReturn(true);
        doNothing().when(nessLoggerService).publishNesslogsToSplunk(anyString());

        // Act
        usp3696DataService.process();

        // Assert
        verify(usp3696DataRepo).getUSP3696Data(eq("dateFilter"), any(Processlog.class));
        verify(usp3696DataService, never()).processUSP3696Data(any(), any());
        verify(sendEmailService).sendEmail(argThat(processlog -> "NO_DATA_FOUND".equals(processlog.getStatus())));
        verify(usp3696DataService).markTxComlpletedforlPrevMonth(any(Processlog.class));
    }

    @Test
    void processTest_Exception() {
        // Arrange
        ReflectionTestUtils.setField(usp3696DataService, "dateFilter", "dateFilter");
        ReflectionTestUtils.setField(usp3696DataService, "minusDays", 1L);

        when(usp3696DataRepo.getUSP3696Data(anyString(), any())).thenThrow(new RuntimeException("Test Exception"));
        when(sendEmailService.sendEmail(any())).thenReturn(true);
        doNothing().when(nessLoggerService).publishNesslogsToSplunk(anyString());

        // Act
        usp3696DataService.process();

        // Assert
        verify(usp3696DataRepo).getUSP3696Data(eq("dateFilter"), any(Processlog.class));
        verify(sendEmailService).sendEmail(argThat(processlog -> "FAILED".equals(processlog.getStatus())));
        verify(usp3696DataService, never()).processUSP3696Data(any(), any());
        verify(usp3696DataService, never()).markTxComlpletedforlPrevMonth(any());
    }

    @Test
    void processUSP3696Data_NewRecord() {
        // Arrange
        USP3696Data usp3696Data = new USP3696Data();
        usp3696Data.setBookOfBusiness("Oxford");
        usp3696Data.setCreatedDate(Date.valueOf("2024-07-15"));
        usp3696Data.setPrintCount(100);
        usp3696Data.setMemSupp(20);
        usp3696Data.setPolicySupp(10);
        usp3696Data.setTotal(130);
        usp3696Data.setSuppress(30);
        usp3696Data.setClaimCount(50);
        usp3696Data.setMemPrint(1);

        List<USP3696Data> usp3696DataList = List.of(usp3696Data);
        Processlog processlog = new Processlog();

        when(hsSuppCostReportRepo.findByTrailNameBobAndMonthAndNotCompleted(anyString(), anyString(), anyString()))
                .thenReturn(Optional.empty());
        doNothing().when(nessLoggerService).publishNesslogsToSplunk(anyString());

        // Act
        usp3696DataService.processUSP3696Data(usp3696DataList, processlog);

        // Assert
        verify(hsSuppCostReportRepo).save(hsSuppCostReportCaptor.capture());

        HSSuppCostReport savedReport = hsSuppCostReportCaptor.getValue();
        assertEquals(PT3696_USP, savedReport.getTrailName());
        assertEquals("Oxford", savedReport.getBob());
        assertEquals("July 2024", savedReport.getMonth());
        assertEquals(100, savedReport.getStatementPrinted());
        assertEquals(20, savedReport.getMemberElectionHSSupp());
        assertEquals(10, savedReport.getPolicySettingHSSupp());
        assertEquals(130, savedReport.getTotalStmtGenerated());
        assertEquals(30, savedReport.getTotalStmtSuppressed());
        assertEquals(50, savedReport.getTotalClaims());
        assertEquals(23.08, savedReport.getHsSuppressPercent(), 0.01); // (30/130)*100 = 23.08%
        assertEquals(0, savedReport.getIsTxCompleted()); // Not last day of month
    }

    @Test
    void processUSP3696Data_ExistingRecord() {
        // Arrange
        USP3696Data usp3696Data = new USP3696Data();
        usp3696Data.setBookOfBusiness("Oxford");
        usp3696Data.setCreatedDate(Date.valueOf("2024-07-15"));
        usp3696Data.setPrintCount(100);
        usp3696Data.setMemSupp(20);
        usp3696Data.setPolicySupp(10);
        usp3696Data.setTotal(130);
        usp3696Data.setSuppress(30);
        usp3696Data.setClaimCount(50);
        usp3696Data.setMemPrint(1);

        List<USP3696Data> usp3696DataList = List.of(usp3696Data);
        Processlog processlog = new Processlog();

        HSSuppCostReport existingReport = new HSSuppCostReport();
        existingReport.setTrailName(PT3696_USP);
        existingReport.setBob("Oxford");
        existingReport.setMonth("Jul-2024");
        existingReport.setMonthYear(LocalDate.of(2024, 7, 1));
        existingReport.setStatementPrinted(200);
        existingReport.setMemberElectionHSSupp(40);
        existingReport.setPolicySettingHSSupp(20);
        existingReport.setTotalStmtGenerated(260);
        existingReport.setTotalStmtSuppressed(60);
        existingReport.setTotalClaims(100);
        existingReport.setMemPrint(1);
        existingReport.setHsSuppressPercent(23.08);

        when(hsSuppCostReportRepo.findByTrailNameBobAndMonthAndNotCompleted(anyString(), anyString(), anyString()))
                .thenReturn(Optional.of(existingReport));
        doNothing().when(nessLoggerService).publishNesslogsToSplunk(anyString());

        // Act
        usp3696DataService.processUSP3696Data(usp3696DataList, processlog);

        // Assert
        verify(hsSuppCostReportRepo).save(hsSuppCostReportCaptor.capture());

        HSSuppCostReport savedReport = hsSuppCostReportCaptor.getValue();
        assertEquals(PT3696_USP, savedReport.getTrailName());
        assertEquals("Oxford", savedReport.getBob());
        assertEquals("Jul-2024", savedReport.getMonth());
        assertEquals(300, savedReport.getStatementPrinted()); // 200 + 100
        assertEquals(60, savedReport.getMemberElectionHSSupp()); // 40 + 20
        assertEquals(30, savedReport.getPolicySettingHSSupp()); // 20 + 10
        assertEquals(390, savedReport.getTotalStmtGenerated()); // 260 + 130
        assertEquals(90, savedReport.getTotalStmtSuppressed()); // 60 + 30
        assertEquals(150, savedReport.getTotalClaims()); // 100 + 50
        assertEquals(23.08, savedReport.getHsSuppressPercent(), 0.01); // (90/390)*100 = 23.08%
    }

    @Test
    void processUSP3696Data_LastDayOfMonth() {
        // Arrange
        // July 31, 2024 is the last day of the month
        USP3696Data usp3696Data = new USP3696Data();
        usp3696Data.setBookOfBusiness("Oxford");
        usp3696Data.setCreatedDate(Date.valueOf("2024-07-31"));
        usp3696Data.setPrintCount(100);
        usp3696Data.setMemSupp(20);
        usp3696Data.setPolicySupp(10);
        usp3696Data.setTotal(130);
        usp3696Data.setSuppress(30);
        usp3696Data.setClaimCount(50);
        usp3696Data.setMemPrint(1);

        List<USP3696Data> usp3696DataList = List.of(usp3696Data);
        Processlog processlog = new Processlog();

        when(hsSuppCostReportRepo.findByTrailNameBobAndMonthAndNotCompleted(anyString(), anyString(), anyString()))
                .thenReturn(Optional.empty());
        doNothing().when(nessLoggerService).publishNesslogsToSplunk(anyString());

        // Act
        usp3696DataService.processUSP3696Data(usp3696DataList, processlog);

        // Assert
        verify(hsSuppCostReportRepo).save(hsSuppCostReportCaptor.capture());

        HSSuppCostReport savedReport = hsSuppCostReportCaptor.getValue();
        assertEquals(1, savedReport.getIsTxCompleted()); // Last day of month
    }

    @Test
    void processUSP3696Data_CalculateFinancialData() {
        // Arrange
        USP3696Data usp3696Data = new USP3696Data();
        usp3696Data.setBookOfBusiness("Oxford");
        usp3696Data.setCreatedDate(Date.valueOf("2024-07-15"));
        usp3696Data.setPrintCount(100);
        usp3696Data.setMemSupp(20);
        usp3696Data.setPolicySupp(10);
        usp3696Data.setTotal(130);
        usp3696Data.setSuppress(30);
        usp3696Data.setClaimCount(50);
        usp3696Data.setMemPrint(1);

        List<USP3696Data> usp3696DataList = List.of(usp3696Data);
        Processlog processlog = new Processlog();

        HSSuppCostReport existingReport = new HSSuppCostReport();
        existingReport.setTrailName(PT3696_USP);
        existingReport.setBob("Oxford");
        existingReport.setMonth("Jul-2024");
        existingReport.setMonthYear(LocalDate.of(2024, 7, 1));
        existingReport.setStatementPrinted(100);
        existingReport.setMemberElectionHSSupp(20);
        existingReport.setPolicySettingHSSupp(10);
        existingReport.setTotalStmtGenerated(130);
        existingReport.setTotalStmtSuppressed(30);
        existingReport.setTotalClaims(50);
        existingReport.setPrintingCost(500.0); // Has printing cost
        existingReport.setPostageCost(300.0); // Has postage cost
        existingReport.setTotalSheets(200.0);
        existingReport.setMemPrint(1.0);

        when(hsSuppCostReportRepo.findByTrailNameBobAndMonthAndNotCompleted(anyString(), anyString(), anyString()))
                .thenReturn(Optional.of(existingReport));
        doNothing().when(nessLoggerService).publishNesslogsToSplunk(anyString());

        // Act
        usp3696DataService.processUSP3696Data(usp3696DataList, processlog);

        // Assert
        verify(hsSuppCostReportRepo).save(hsSuppCostReportCaptor.capture());

        HSSuppCostReport savedReport = hsSuppCostReportCaptor.getValue();
        assertEquals(800.0, savedReport.getTotalPrintPostageCost()); // 500 + 300
        assertEquals(4.0, savedReport.getCostPerStmt()); // 800 / 200
        assertEquals(1.0, savedReport.getSheetsPerPrintedStmt()); // 200 / 200
        assertEquals(1, savedReport.getIsCompleted()); // Should be completed
    }

    @Test
    void processUSP3696Data_InvalidData() {
        // Arrange
        // Missing BookOfBusiness
        USP3696Data invalidData1 = new USP3696Data();
        invalidData1.setCreatedDate(Date.valueOf("2024-07-15"));
        invalidData1.setPrintCount(100);

        // Missing CreatedDate
        USP3696Data invalidData2 = new USP3696Data();
        invalidData2.setBookOfBusiness("Oxford");
        invalidData2.setPrintCount(100);

        List<USP3696Data> usp3696DataList = List.of(invalidData1, invalidData2);
        Processlog processlog = new Processlog();

        // Act
        usp3696DataService.processUSP3696Data(usp3696DataList, processlog);

        // Assert
        verify(hsSuppCostReportRepo, never()).save(any());
    }

    @Test
    void processUSP3696Data_Exception() {
        // Arrange
        USP3696Data usp3696Data = new USP3696Data();
        usp3696Data.setBookOfBusiness("Oxford");
        usp3696Data.setCreatedDate(Date.valueOf("2024-07-15"));
        usp3696Data.setPrintCount(100);

        List<USP3696Data> usp3696DataList = List.of(usp3696Data);
        Processlog processlog = new Processlog();

        when(hsSuppCostReportRepo.findByTrailNameBobAndMonthAndNotCompleted(anyString(), anyString(), anyString()))
                .thenThrow(new RuntimeException("Test exception"));

        // Act & Assert
        Exception exception = assertThrows(RuntimeException.class, () -> {
            usp3696DataService.processUSP3696Data(usp3696DataList, processlog);
        });

        assertEquals("Test exception", exception.getMessage());
        assertEquals("Error while processing USP3696 Transaction Data", processlog.getErrorMessage());
    }

    @Test
    void markTxComlpletedforlPrevMonth_Success() {
        // Arrange
        ReflectionTestUtils.setField(usp3696DataService, "DayUpdateTxStatus", 10);

        // Mock current date to be the 10th day of month
        Date currentDate = Date.valueOf("2024-07-10");
        try (MockedStatic<Date> dateMock = Mockito.mockStatic(Date.class)) {
            // Fix: Use a proper approach for mocking static Date methods
            // If needed, also mock the specific method with any parameter
            dateMock.when(() -> Date.valueOf(Mockito.any(String.class))).thenReturn(currentDate);

            HSSuppCostReport report1 = new HSSuppCostReport();
            report1.setTrailName(PT3696_USP);
            report1.setMonth("Jun-2024");
            report1.setIsTxCompleted(0);

            HSSuppCostReport report2 = new HSSuppCostReport();
            report2.setTrailName(PT3696_USP);
            report2.setMonth("Jun-2024");
            report2.setIsTxCompleted(0);

            List<HSSuppCostReport> reports = List.of(report1, report2);

//            when(hsSuppCostReportRepo.findByTrailNameAndMonthAndNotTxCompleted(
//                    eq(PT3696_USP), eq(0), eq("Jun-2024")))
//                    .thenReturn(reports);

            Processlog processlog = new Processlog();

            // Act
            assertDoesNotThrow(()->usp3696DataService.markTxComlpletedforlPrevMonth(processlog));

            // Assert
            List<HSSuppCostReport> savedReports = hsSuppCostReportCaptor.getAllValues();

        }
    }

    @Test
    void markTxComlpletedforlPrevMonth_Exception() {
        // Arrange
        ReflectionTestUtils.setField(usp3696DataService, "DayUpdateTxStatus", 10);

        // Mock current date to be the update day
        Date currentDate = Date.valueOf("2024-07-10");
        try (MockedStatic<Date> dateMock = Mockito.mockStatic(Date.class)) {

//            doThrow(new RuntimeException("Test exception")).when(hsSuppCostReportRepo).findByTrailNameAndMonthAndNotTxCompleted(
//                            anyString(), anyInt(), anyString());

            Processlog processlog = new Processlog();

            assertDoesNotThrow( () -> {
                usp3696DataService.markTxComlpletedforlPrevMonth(processlog);
            });
        }
    }

    @Test
    void isLastDateOfMonth_True() {
        // Arrange
        LocalDate lastDayOfJuly = LocalDate.of(2024, Month.JULY, 31);

        // Act
        int result = ReflectionTestUtils.invokeMethod(usp3696DataService, "isLastDateOfMonth", lastDayOfJuly);

        // Assert
        assertEquals(1, result);
    }

    @Test
    void isLastDateOfMonth_False() {
        // Arrange
        LocalDate notLastDayOfJuly = LocalDate.of(2024, Month.JULY, 15);

        // Act
        int result = ReflectionTestUtils.invokeMethod(usp3696DataService, "isLastDateOfMonth", notLastDayOfJuly);

        // Assert
        assertEquals(0, result);
    }

    @Test
    void calculateFinancialData_Success() {
        // Arrange
        HSSuppCostReport report = new HSSuppCostReport();
        report.setStatementPrinted(100);
        report.setTotalStmtGenerated(130);
        report.setTotalStmtSuppressed(30);
        report.setPrintingCost(500.0);
        report.setPostageCost(300.0);
        report.setTotalSheets(200.0);

        // Act
        ReflectionTestUtils.invokeMethod(usp3696DataService, "calculateFinancialData", report);

        // Assert
        assertEquals(800.0, report.getTotalPrintPostageCost()); // 500 + 300
        assertEquals(8.0, report.getCostPerStmt()); // 800 / 100
        assertEquals(2.0, report.getSheetsPerPrintedStmt()); // 200 / 100
        assertEquals(23.08, report.getHsSuppressPercent(), 0.01); // (30/130)*100
        assertEquals(1, report.getIsCompleted()); // Should be completed
    }

    @Test
    void calculateFinancialData_ZeroDivisionHandling() {
        // Arrange
        HSSuppCostReport report = new HSSuppCostReport();
        report.setStatementPrinted(0); // Will cause division by zero
        report.setTotalStmtGenerated(0); // Will cause division by zero
        report.setTotalStmtSuppressed(30);
        report.setPrintingCost(500.0);
        report.setPostageCost(300.0);
        report.setTotalSheets(200.0);

        // Act
        ReflectionTestUtils.invokeMethod(usp3696DataService, "calculateFinancialData", report);

        // Assert
        assertEquals(800.0, report.getTotalPrintPostageCost()); // 500 + 300
        // NaN or Infinity values should be handled gracefully
        assertEquals(1, report.getIsCompleted()); // Should still be completed
    }


    @Test
    void updateNewBoB_WithNewBOBs() {
        // Arrange
        USP3696Data usp3696Data1 = new USP3696Data();
        usp3696Data1.setBookOfBusiness("NewBOB1");
        usp3696Data1.setCreatedDate(Date.valueOf("2024-07-10"));

        USP3696Data usp3696Data2 = new USP3696Data();
        usp3696Data2.setBookOfBusiness("NewBOB2");
        usp3696Data2.setCreatedDate(Date.valueOf("2024-07-15"));

        List<USP3696Data> usp3696DataList = List.of(usp3696Data1, usp3696Data2);

        TrailAndBobDetails existingBOB = new TrailAndBobDetails();
        existingBOB.setTrailNumber(PT3696_USP);
        existingBOB.setBobName("ExistingBOB");

        Processlog processlog = new Processlog();

        when(trailAndBobRepository.findByTrailNumber(PT3696_USP)).thenReturn(Set.of(existingBOB));
        when(trailAndBobRepository.save(any())).thenReturn(new TrailAndBobDetails());
        when(sendEmailService.sendEmail(any())).thenReturn(true);

        // Act
        usp3696DataService.updateNewBoB(usp3696DataList, processlog);

        // Assert
        verify(trailAndBobRepository, times(2)).save(any(TrailAndBobDetails.class));
        verify(sendEmailService, times(2)).sendEmail(any(Processlog.class));

        // Verify both BOBs were saved
        ArgumentCaptor<TrailAndBobDetails> bobCaptor = ArgumentCaptor.forClass(TrailAndBobDetails.class);
        verify(trailAndBobRepository, times(2)).save(bobCaptor.capture());
        List<TrailAndBobDetails> savedBobs = bobCaptor.getAllValues();

        assertEquals(2, savedBobs.size());
        assertEquals(PT3696_USP, savedBobs.get(0).getTrailNumber());
        assertEquals(1, savedBobs.get(0).getIsActive());
    }

    @Test
    void updateNewBoB_NoNewBOBs() {
        // Arrange
        USP3696Data usp3696Data = new USP3696Data();
        usp3696Data.setBookOfBusiness("ExistingBOB");
        usp3696Data.setCreatedDate(Date.valueOf("2024-07-10"));

        List<USP3696Data> usp3696DataList = List.of(usp3696Data);

        TrailAndBobDetails existingBOB = new TrailAndBobDetails();
        existingBOB.setTrailNumber(PT3696_USP);
        existingBOB.setBobName("ExistingBOB");

        Processlog processlog = new Processlog();

        when(trailAndBobRepository.findByTrailNumber(PT3696_USP)).thenReturn(Set.of(existingBOB));

        // Act
        usp3696DataService.updateNewBoB(usp3696DataList, processlog);

        // Assert
        verify(trailAndBobRepository, never()).save(any());
        verify(sendEmailService, never()).sendEmail(any());
    }

    @Test
    void updateNewBoB_EmptyExistingBOBs() {
        // Arrange
        USP3696Data usp3696Data = new USP3696Data();
        usp3696Data.setBookOfBusiness("NewBOB");
        usp3696Data.setCreatedDate(Date.valueOf("2024-07-10"));

        List<USP3696Data> usp3696DataList = List.of(usp3696Data);
        Processlog processlog = new Processlog();

        when(trailAndBobRepository.findByTrailNumber(PT3696_USP)).thenReturn(Set.of());
//        when(trailAndBobRepository.save(any())).thenReturn(new TrailAndBobDetails());
//        when(sendEmailService.sendEmail(any())).thenReturn(true);

        // Act
        assertDoesNotThrow(()->usp3696DataService.updateNewBoB(usp3696DataList, processlog));

    }

    @Test
    void updateNewBoB_EmptyInputList() {
        // Arrange
        List<USP3696Data> emptyList = List.of();
        Processlog processlog = new Processlog();

        when(trailAndBobRepository.findByTrailNumber(PT3696_USP)).thenReturn(Set.of(new TrailAndBobDetails()));

        // Act
        usp3696DataService.updateNewBoB(emptyList, processlog);

        // Assert
        verify(trailAndBobRepository, never()).save(any(TrailAndBobDetails.class));
        verify(sendEmailService, never()).sendEmail(any(Processlog.class));
    }

    @Test
    void updateNewBoB_NullBOBName() {
        // Arrange
        USP3696Data usp3696Data1 = new USP3696Data(); // null BOB name
        usp3696Data1.setCreatedDate(Date.valueOf("2024-07-10"));

        USP3696Data usp3696Data2 = new USP3696Data();
        usp3696Data2.setBookOfBusiness(""); // empty BOB name
        usp3696Data2.setCreatedDate(Date.valueOf("2024-07-15"));

        USP3696Data usp3696Data3 = new USP3696Data();
        usp3696Data3.setBookOfBusiness("ValidBOB");
        usp3696Data3.setCreatedDate(Date.valueOf("2024-07-15"));

        List<USP3696Data> usp3696DataList = List.of(usp3696Data1, usp3696Data2, usp3696Data3);

        TrailAndBobDetails existingBOB = new TrailAndBobDetails();
        existingBOB.setBobName("ExistingBOB");

        Processlog processlog = new Processlog();

        when(trailAndBobRepository.findByTrailNumber(PT3696_USP)).thenReturn(Set.of(existingBOB));
        when(trailAndBobRepository.save(any())).thenReturn(new TrailAndBobDetails());
        when(sendEmailService.sendEmail(any())).thenReturn(true);

        // Act
        usp3696DataService.updateNewBoB(usp3696DataList, processlog);

        // Assert
        verify(trailAndBobRepository, times(1)).save(any(TrailAndBobDetails.class));
        verify(sendEmailService, times(1)).sendEmail(any(Processlog.class));
    }

    @Test
    void updateNewBoB_ExceptionHandling() {
        // Arrange
        USP3696Data usp3696Data = new USP3696Data();
        usp3696Data.setBookOfBusiness("NewBOB");
        usp3696Data.setCreatedDate(Date.valueOf("2024-07-10"));

        List<USP3696Data> usp3696DataList = List.of(usp3696Data);
        Processlog processlog = new Processlog();

        when(trailAndBobRepository.findByTrailNumber(PT3696_USP))
                .thenThrow(new RuntimeException("Test exception"));

        // Act & Assert
        Exception exception = assertThrows(RuntimeException.class, () ->
                usp3696DataService.updateNewBoB(usp3696DataList, processlog));

        assertEquals("Test exception", exception.getMessage());
        assertEquals("Error while updating new BOB for USP3696", processlog.getErrorMessage());
    }

}
