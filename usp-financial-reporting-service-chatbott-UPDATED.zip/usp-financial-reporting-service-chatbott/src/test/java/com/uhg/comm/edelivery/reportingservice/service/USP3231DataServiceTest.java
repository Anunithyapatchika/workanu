package com.uhg.comm.edelivery.reportingservice.service;

import com.azure.core.util.BinaryData;
import com.azure.storage.blob.BlobClient;
import com.microsoft.azure.eventgrid.models.StorageBlobCreatedEventData;
import com.uhg.comm.edelivery.processLog.Processlog;
import com.uhg.comm.edelivery.reportingservice.model.TrailAndBobDetails;
import com.uhg.comm.edelivery.reportingservice.model.USPFinancialReport;
import com.uhg.comm.edelivery.reportingservice.nesslogger.NessLoggerService;
import com.uhg.comm.edelivery.reportingservice.repository.TrailAndBobRepository;
import com.uhg.comm.edelivery.reportingservice.repository.USP3231DataRepository;
import com.uhg.comm.edelivery.reportingservice.repository.USPFinancialReportRepository;
import com.uhg.comm.edelivery.reportingservice.service.impl.USP3231DataServiceImpl;
import com.uhg.comm.edelivery.reportingservice.util.BlobUtils;
import com.uhg.comm.edelivery.reportingservice.util.DateUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.util.ReflectionTestUtils;

import java.net.MalformedURLException;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class USP3231DataServiceTest {

    @Mock
    private BlobUtils blobUtils;

    @Mock
    private USPFinancialReportRepository uspFinancialReportRepository;

    @InjectMocks
    @Spy
    private USP3231DataServiceImpl usp3231DataService;

    @Mock
   private  BlobClient blobClient;


    @Mock
    private BinaryData binaryData;

    @Mock
    private NessLoggerService nessLoggerService;

    @Mock
    private TrailAndBobRepository trailAndBobRepo;

    @Mock
    private USP3231DataRepository usp3231DataRepo;

    @Mock
    private SendEmailService sendEmailService;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        Date currentDate = new Date(System.currentTimeMillis());

        ReflectionTestUtils.setField(usp3231DataService,"DayUpdateTxStatus",DateUtil.getDayOfMonth(currentDate));
    }

    @Test
    void testFetchUSP3231DataForExistingDBData() {
        // Mock data
        USPFinancialReport report = new USPFinancialReport();
        report.setCreatedDate(getLastDayOfMonth(LocalDateTime.now()));
        report.setBob("Bob1");
        List<USPFinancialReport> reports = List.of(report);

        Optional<USPFinancialReport> optional = Optional.of(getUspFinReportFromDb());
        // Mock repository behavior
        when(uspFinancialReportRepository.findByMonthYearStrAndBobAndTrailName(anyString(), anyString(), anyString()))
                .thenReturn(optional);

        // Call the method
        Processlog processlog = new Processlog();
        usp3231DataService.fetchUSP3231Data(reports,processlog);

        // Verify interactions
        verify(uspFinancialReportRepository, times(1)).save(any(USPFinancialReport.class));
    }

    @Test
    void testFetchUSP3231DataForNewData() {
        // Mock data
        USPFinancialReport report = new USPFinancialReport();
        report.setCreatedDate(getLastDayOfMonth(LocalDateTime.now()));
        report.setBob("Bob1");
        List<USPFinancialReport> reports = List.of(report);

        Optional<USPFinancialReport> optional = Optional.empty();
        // Mock repository behavior
        when(uspFinancialReportRepository.findByMonthYearStrAndBobAndTrailName(anyString(), anyString(), anyString()))
                .thenReturn(optional);

        // Call the method
        Processlog processlog = new Processlog();
        usp3231DataService.fetchUSP3231Data(reports,processlog);

        // Verify interactions
        verify(uspFinancialReportRepository, times(1)).save(any(USPFinancialReport.class));
    }

    @Test
    void testDownloadBlobFile() throws MalformedURLException {
        // Mock data
        StorageBlobCreatedEventData eventData = mock(StorageBlobCreatedEventData.class);
        when(eventData.url()).thenReturn("https://stecedelqdev.blob.core.windows.net/cont-ecedel-qdev/uspReporting/PT3231_USP_EOBCount_20240825.csv");
        when(blobUtils.getBlobClient(anyString())).thenReturn(blobClient);
        when(blobClient.downloadContent()).thenReturn(binaryData);
        when(binaryData.toString()).thenReturn("csv content");
        //when(blobClient.downloadContent().toString()).thenReturn("csv content");
        // Call the method
        String result = usp3231DataService.downloadBlobFile(eventData);

        // Verify result
        assertEquals("csv content", result);
    }

    @Test
    void testParsingCsv() {
        // Mock CSV content
        String csvContent = "\"Date\",\"Book of Business\",\"Total Count\",\"Suppressed Count\",\"Member Suppressed Count\",\"Policy Suppressed Count\",\"Print Suppressed Count\",\"HS Total\",\"HS Suppressed Count\",\"HS Member Suppressed Count\",\"HS Policy Suppressed Count\",\"HS Print Suppressed Count\",\"CAE Total\",\"CAE Email Count\",\"CAE No Email Count\"\n" +
                "\"2024-08-03\",\"Employer and Individual\",\"31\",\"3\",\"0\",\"3\",\"28\",\"0\",\"0\",\"0\",\"0\",\"0\",\"0\",\"0\",\"0\"";

        // Call the method
        List<USPFinancialReport> result = usp3231DataService.parsingCsv(csvContent);

        // Verify result
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Employer and Individual", result.get(0).getBob());
    }

    @Test
    void testCompleteTrxForPrevMonth() {
        Date currentDate = Date.valueOf("2023-10-15"); // Example date, adjust as needed
        // Mock the repository to return a list of reports
        Processlog processlog = new Processlog();
        USPFinancialReport report = new USPFinancialReport();
        report.setIsTxCompleted(0);
        List<USPFinancialReport> reports = List.of(report);
        when(uspFinancialReportRepository.findByTrailNameAndIsTxCompletedAndMonthYearStr(anyString(), eq(0), anyString()))
                .thenReturn(reports);

        // Call the method
        usp3231DataService.completeTrxForPrevMonth(processlog);

        // Verify interactions
        verify(uspFinancialReportRepository, times(1)).save(any(USPFinancialReport.class));
        assertEquals(1, report.getIsTxCompleted());
    }

    USPFinancialReport getUspFinReportFromDb(){
        USPFinancialReport uspFinancialReport = new USPFinancialReport();
        uspFinancialReport.setBob("Employer and Individual");
        uspFinancialReport.setTotalEobGenerated(31);
        uspFinancialReport.setTotalEobSuppressed(3);
        uspFinancialReport.setMemberElectionEob(0);
        uspFinancialReport.setPolicySettingEob(3);
        uspFinancialReport.setTotalEobPrinted(28);
        uspFinancialReport.setTotalHsGenerated(0);
        uspFinancialReport.setTotalHsSuppressed(0);
        uspFinancialReport.setPolicySettingHs(0);
        uspFinancialReport.setTotalHsPrinted(0);
        uspFinancialReport.setTotalCaeEobCount(0);
        uspFinancialReport.setCaeEobMailCount(0);
        uspFinancialReport.setCaeEobNoEmailCount(0);
        return uspFinancialReport;
    }
    public LocalDateTime getLastDayOfMonth(LocalDateTime dateTime) {
        LocalDate lastDayOfMonth = dateTime.toLocalDate().withDayOfMonth(dateTime.toLocalDate().lengthOfMonth());
        return LocalDateTime.of(lastDayOfMonth, dateTime.toLocalTime());
    }


    @Test
    void testUpdateNewBoB_NewBobDetected() {
        // Mock data
        USPFinancialReport report1 = new USPFinancialReport();
        report1.setBob("NewBob1");
        report1.setCreatedDate(LocalDateTime.now());

        USPFinancialReport report2 = new USPFinancialReport();
        report2.setBob("ExistingBob");
        report2.setCreatedDate(LocalDateTime.now());

        List<USPFinancialReport> uspFinancialReportList = Arrays.asList(report1, report2);

        TrailAndBobDetails existingBob = new TrailAndBobDetails();
        existingBob.setBobName("ExistingBob");

        Set<TrailAndBobDetails> trailAndBobDetailsSet = new HashSet<>(Collections.singletonList(existingBob));

        when(trailAndBobRepo.findByTrailNumber(anyString())).thenReturn(trailAndBobDetailsSet);

        Processlog processlog = new Processlog();

        // Call the method
        usp3231DataService.updateNewBoB(uspFinancialReportList, processlog);

        // Verify interactions
        verify(trailAndBobRepo, times(1)).save(any(TrailAndBobDetails.class));
        verify(sendEmailService, times(1)).sendEmail(any(Processlog.class));
    }

    @Test
    void testUpdateNewBoB_NoNewBobDetected() {
        // Mock data
        USPFinancialReport report1 = new USPFinancialReport();
        report1.setBob("ExistingBob1");
        report1.setCreatedDate(LocalDateTime.now());

        USPFinancialReport report2 = new USPFinancialReport();
        report2.setBob("ExistingBob2");
        report2.setCreatedDate(LocalDateTime.now());

        List<USPFinancialReport> uspFinancialReportList = Arrays.asList(report1, report2);

        TrailAndBobDetails existingBob1 = new TrailAndBobDetails();
        existingBob1.setBobName("ExistingBob1");

        TrailAndBobDetails existingBob2 = new TrailAndBobDetails();
        existingBob2.setBobName("ExistingBob2");

        Set<TrailAndBobDetails> trailAndBobDetailsSet = new HashSet<>(Arrays.asList(existingBob1, existingBob2));

        when(trailAndBobRepo.findByTrailNumber(anyString())).thenReturn(trailAndBobDetailsSet);

        Processlog processlog = new Processlog();

        // Call the method
        usp3231DataService.updateNewBoB(uspFinancialReportList, processlog);

        // Verify interactions
        verify(trailAndBobRepo, never()).save(any(TrailAndBobDetails.class));
        verify(sendEmailService, never()).sendEmail(any(Processlog.class));
    }

    @Test
    void testUpdateNewBoB_Exception() {
        // Mock data
        USPFinancialReport report1 = new USPFinancialReport();
        report1.setBob("NewBob1");
        report1.setCreatedDate(LocalDateTime.now());

        List<USPFinancialReport> uspFinancialReportList = Collections.singletonList(report1);

        when(trailAndBobRepo.findByTrailNumber(anyString())).thenThrow(new RuntimeException("Database error"));

        Processlog processlog = new Processlog();

        // Call the method and assert exception
        Exception exception = assertThrows(RuntimeException.class, () -> {
            usp3231DataService.updateNewBoB(uspFinancialReportList, processlog);
        });

        assertEquals("Database error", exception.getMessage());
        verify(trailAndBobRepo, never()).save(any(TrailAndBobDetails.class));
        verify(sendEmailService, never()).sendEmail(any(Processlog.class));
    }

    @Test
    void testProcess_Success() {
        // Mock data
        List<USPFinancialReport> uspFinancialReportList = new ArrayList<>();
        USPFinancialReport report = new USPFinancialReport();
        report.setBob("Business1");
        uspFinancialReportList.add(report);

        when(usp3231DataRepo.getUSP3231Data(any(), any(Processlog.class))).thenReturn(uspFinancialReportList);

        // Call the method
        ReflectionTestUtils.setField(usp3231DataService,"minusDays",2L);
        usp3231DataService.process();

        // Verify interactions
        verify(usp3231DataRepo, times(1)).getUSP3231Data(any(), any(Processlog.class));
    }

    @Test
    void testProcess_NoDataFound() {
        // Mock data
        List<USPFinancialReport> uspFinancialReportList = new ArrayList<>();

        when(usp3231DataRepo.getUSP3231Data(any(), any(Processlog.class))).thenReturn(uspFinancialReportList);

        // Call the method
        ReflectionTestUtils.setField(usp3231DataService,"minusDays",2L);
        usp3231DataService.process();

        // Verify interactions
        verify(usp3231DataRepo, times(1)).getUSP3231Data(any(), any(Processlog.class));
        verify(uspFinancialReportRepository, never()).save(any(USPFinancialReport.class));
        verify(sendEmailService, times(1)).sendEmail(any(Processlog.class));
    }

    @Test
    void testProcess_Exception() {
        // Mock data
        when(usp3231DataRepo.getUSP3231Data(any(), any(Processlog.class))).thenThrow(new RuntimeException("Database error"));
        ReflectionTestUtils.setField(usp3231DataService,"minusDays",2L);
        // Call the method and assert exception
        usp3231DataService.process();

        // Verify interactions
        verify(usp3231DataRepo, times(1)).getUSP3231Data(any(), any(Processlog.class));
        verify(uspFinancialReportRepository, never()).save(any(USPFinancialReport.class));
        verify(sendEmailService, times(1)).sendEmail(any(Processlog.class));
    }
}