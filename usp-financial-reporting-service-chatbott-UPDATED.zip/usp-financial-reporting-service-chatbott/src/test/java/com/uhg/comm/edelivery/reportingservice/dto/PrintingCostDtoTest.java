package com.uhg.comm.edelivery.reportingservice.dto;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class PrintingCostDtoTest {

   @Test
    void testBuilder() {
        // Arrange
        int id = 1;
        String trailName = "Test Trail";
        String month = "January";
        String bob = "Test Bob";
        double imageCount = 100.0;
        double envelopCount = 50.0;
        double paperCount = 200.0;
        double printExpenseCost = 150.0;
        double postageCost = 75.0;
        double totalExpense = 225.0;
        double imagePerEnvelop = 2.0;
        double printExpPerImage = 1.5;
        double printExpPerEnvelop = 3.0;
        double postageExpPerEnvelop = 1.5;
        double totalExpPerEnvelop = 4.5;
        String userId = "testUser";

        // Act
        PrintingCostDto dto = PrintingCostDto.builder()
                .id(id)
                .trailName(trailName)
                .month(month)
                .bob(bob)
                .imageCount(imageCount)
                .envelopCount(envelopCount)
                .paperCount(paperCount)
                .printExpenseCost(printExpenseCost)
                .postageCost(postageCost)
                .totalExpense(totalExpense)
                .imagePerEnvelop(imagePerEnvelop)
                .printExpPerImage(printExpPerImage)
                .printExpPerEnvelop(printExpPerEnvelop)
                .postageExpPerEnvelop(postageExpPerEnvelop)
                .totalExpPerEnvelop(totalExpPerEnvelop)
                .userId(userId)
                .build();

        // Assert
        assertEquals(id, dto.getId());
        assertEquals(trailName, dto.getTrailName());
        assertEquals(month, dto.getMonth());
        assertEquals(bob, dto.getBob());
        assertEquals(imageCount, dto.getImageCount());
        assertEquals(envelopCount, dto.getEnvelopCount());
        assertEquals(paperCount, dto.getPaperCount());
        assertEquals(printExpenseCost, dto.getPrintExpenseCost());
        assertEquals(postageCost, dto.getPostageCost());
        assertEquals(totalExpense, dto.getTotalExpense());
        assertEquals(imagePerEnvelop, dto.getImagePerEnvelop());
        assertEquals(printExpPerImage, dto.getPrintExpPerImage());
        assertEquals(printExpPerEnvelop, dto.getPrintExpPerEnvelop());
        assertEquals(postageExpPerEnvelop, dto.getPostageExpPerEnvelop());
        assertEquals(totalExpPerEnvelop, dto.getTotalExpPerEnvelop());
        assertEquals(userId, dto.getUserId());
    }

    @Test
    void testSettersAndGetters() {
        // Arrange
        PrintingCostDto dto = PrintingCostDto.builder().build();

        // Act & Assert - Test each setter and getter
        int id = 2;
        dto.setId(id);
        assertEquals(id, dto.getId());

        String trailName = "Updated Trail";
        dto.setTrailName(trailName);
        assertEquals(trailName, dto.getTrailName());

        String month = "February";
        dto.setMonth(month);
        assertEquals(month, dto.getMonth());

        String bob = "Updated Bob";
        dto.setBob(bob);
        assertEquals(bob, dto.getBob());

        double imageCount = 200.0;
        dto.setImageCount(imageCount);
        assertEquals(imageCount, dto.getImageCount());

        double envelopCount = 100.0;
        dto.setEnvelopCount(envelopCount);
        assertEquals(envelopCount, dto.getEnvelopCount());

        double paperCount = 400.0;
        dto.setPaperCount(paperCount);
        assertEquals(paperCount, dto.getPaperCount());

        double printExpenseCost = 300.0;
        dto.setPrintExpenseCost(printExpenseCost);
        assertEquals(printExpenseCost, dto.getPrintExpenseCost());

        double postageCost = 150.0;
        dto.setPostageCost(postageCost);
        assertEquals(postageCost, dto.getPostageCost());

        double totalExpense = 450.0;
        dto.setTotalExpense(totalExpense);
        assertEquals(totalExpense, dto.getTotalExpense());

        double imagePerEnvelop = 2.5;
        dto.setImagePerEnvelop(imagePerEnvelop);
        assertEquals(imagePerEnvelop, dto.getImagePerEnvelop());

        double printExpPerImage = 2.0;
        dto.setPrintExpPerImage(printExpPerImage);
        assertEquals(printExpPerImage, dto.getPrintExpPerImage());

        double printExpPerEnvelop = 5.0;
        dto.setPrintExpPerEnvelop(printExpPerEnvelop);
        assertEquals(printExpPerEnvelop, dto.getPrintExpPerEnvelop());

        double postageExpPerEnvelop = 2.5;
        dto.setPostageExpPerEnvelop(postageExpPerEnvelop);
        assertEquals(postageExpPerEnvelop, dto.getPostageExpPerEnvelop());

        double totalExpPerEnvelop = 7.5;
        dto.setTotalExpPerEnvelop(totalExpPerEnvelop);
        assertEquals(totalExpPerEnvelop, dto.getTotalExpPerEnvelop());

        String userId = "updatedUser";
        dto.setUserId(userId);
        assertEquals(userId, dto.getUserId());
    }

    @Test
    void testEqualsAndHashCode() {
        // Arrange
        PrintingCostDto dto1 = PrintingCostDto.builder()
                .id(1)
                .trailName("Test Trail")
                .month("January")
                .build();

        PrintingCostDto dto2 = PrintingCostDto.builder()
                .id(1)
                .trailName("Test Trail")
                .month("January")
                .build();

        PrintingCostDto dto3 = PrintingCostDto.builder()
                .id(2)
                .trailName("Different Trail")
                .month("February")
                .build();

        // Act & Assert
        assertEquals(dto1, dto2);
        assertEquals(dto1.hashCode(), dto2.hashCode());

        assertNotEquals(dto1, dto3);
        assertNotEquals(dto1.hashCode(), dto3.hashCode());

        assertNotEquals(dto1, null);
        assertNotEquals(dto1, new Object());
    }

    @Test
    void testToString() {
        // Arrange
        PrintingCostDto dto = PrintingCostDto.builder()
                .id(1)
                .trailName("Test Trail")
                .month("January")
                .bob("Test Bob")
                .build();

        // Act
        String toStringResult = dto.toString();

        // Assert
        assertTrue(toStringResult.contains("id=1"));
        assertTrue(toStringResult.contains("trailName=Test Trail"));
        assertTrue(toStringResult.contains("month=January"));
        assertTrue(toStringResult.contains("bob=Test Bob"));
    }

    @Test
    void testEdgeCases() {
        // Test with zero values
        PrintingCostDto zeroDto = PrintingCostDto.builder()
                .id(0)
                .imageCount(0)
                .envelopCount(0)
                .paperCount(0)
                .printExpenseCost(0)
                .postageCost(0)
                .totalExpense(0)
                .build();

        assertEquals(0, zeroDto.getId());
        assertEquals(0, zeroDto.getImageCount());
        assertEquals(0, zeroDto.getEnvelopCount());

        // Test with negative values (which might be invalid in real use but should still work in the DTO)
        PrintingCostDto negativeDto = PrintingCostDto.builder()
                .imageCount(-1.5)
                .envelopCount(-2.0)
                .printExpenseCost(-100.0)
                .build();

        assertEquals(-1.5, negativeDto.getImageCount());
        assertEquals(-2.0, negativeDto.getEnvelopCount());
        assertEquals(-100.0, negativeDto.getPrintExpenseCost());

        // Test with null string values
        PrintingCostDto nullStringsDto = PrintingCostDto.builder()
                .trailName(null)
                .month(null)
                .bob(null)
                .userId(null)
                .build();

        assertNull(nullStringsDto.getTrailName());
        assertNull(nullStringsDto.getMonth());
        assertNull(nullStringsDto.getBob());
        assertNull(nullStringsDto.getUserId());
    }
}
