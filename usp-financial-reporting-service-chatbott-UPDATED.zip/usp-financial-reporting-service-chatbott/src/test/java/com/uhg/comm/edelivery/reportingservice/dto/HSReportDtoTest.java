package com.uhg.comm.edelivery.reportingservice.dto;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class HSReportDtoTest {

    @InjectMocks
    private HSReportDto hsReportDto;

    @Test
    void testGettersAndSetters() {
        // Arrange
        String date = "2023-07-31";
        String trailNumber = "TR12345";
        List<HSReportItemsDto> items = new ArrayList<>();
        HSReportItemsDto item = new HSReportItemsDto();
        item.setBob("BOB123");
        items.add(item);

        // Act
        hsReportDto.setDate(date);
        hsReportDto.setTrailNumber(trailNumber);
        hsReportDto.setItems(items);

        // Assert
        assertEquals(date, hsReportDto.getDate());
        assertEquals(trailNumber, hsReportDto.getTrailNumber());
        assertEquals(items, hsReportDto.getItems());
        assertEquals(1, hsReportDto.getItems().size());
        assertEquals("BOB123", hsReportDto.getItems().get(0).getBob());
    }

    @Test
    void testEqualsAndHashCode() {
        // Arrange
        HSReportDto dto1 = new HSReportDto();
        dto1.setDate("2023-07-31");
        dto1.setTrailNumber("TR12345");

        HSReportDto dto2 = new HSReportDto();
        dto2.setDate("2023-07-31");
        dto2.setTrailNumber("TR12345");

        HSReportDto dto3 = new HSReportDto();
        dto3.setDate("2023-08-01");
        dto3.setTrailNumber("TR67890");

        // Act & Assert
        assertEquals(dto1, dto2);
        assertEquals(dto1.hashCode(), dto2.hashCode());

        assertNotEquals(dto1, dto3);
        assertNotEquals(dto1.hashCode(), dto3.hashCode());

        assertNotEquals(dto1, null);
        assertNotEquals(dto1, new Object());
    }

    @Test
    void testToString() {
        // Arrange
        HSReportDto dto = new HSReportDto();
        dto.setDate("2023-07-31");
        dto.setTrailNumber("TR12345");

        // Act
        String result = dto.toString();

        // Assert
        assertTrue(result.contains("date=2023-07-31"));
        assertTrue(result.contains("trailNumber=TR12345"));
    }

    @Test
    void testItemsListManipulation() {
        // Arrange
        HSReportDto dto = new HSReportDto();
        List<HSReportItemsDto> items = new ArrayList<>();

        // Act & Assert - Empty list
        dto.setItems(items);
        assertEquals(0, dto.getItems().size());

        // Act & Assert - Add items
        HSReportItemsDto item1 = new HSReportItemsDto();
        item1.setBob("BOB123");
        item1.setTotalHsGenerated(100);

        HSReportItemsDto item2 = new HSReportItemsDto();
        item2.setBob("BOB456");
        item2.setTotalHsGenerated(200);

        items.add(item1);
        items.add(item2);
        assertEquals(2, dto.getItems().size());
        assertEquals("BOB123", dto.getItems().get(0).getBob());
        assertEquals(100, dto.getItems().get(0).getTotalHsGenerated());
        assertEquals("BOB456", dto.getItems().get(1).getBob());
        assertEquals(200, dto.getItems().get(1).getTotalHsGenerated());

        // Act & Assert - Replace list
        List<HSReportItemsDto> newItems = new ArrayList<>();
        HSReportItemsDto item3 = new HSReportItemsDto();
        item3.setBob("BOB789");
        newItems.add(item3);

        dto.setItems(newItems);
        assertEquals(1, dto.getItems().size());
        assertEquals("BOB789", dto.getItems().get(0).getBob());
    }

    @Test
    void testNullValues() {
        // Arrange
        HSReportDto dto = new HSReportDto();

        // Act & Assert - Default values
        assertNull(dto.getDate());
        assertNull(dto.getTrailNumber());
        assertNull(dto.getItems());

        // Act & Assert - Set and unset
        dto.setDate("2023-07-31");
        dto.setTrailNumber("TR12345");
        List<HSReportItemsDto> items = new ArrayList<>();
        dto.setItems(items);

        assertEquals("2023-07-31", dto.getDate());
        assertEquals("TR12345", dto.getTrailNumber());
        assertNotNull(dto.getItems());

        dto.setDate(null);
        dto.setTrailNumber(null);
        dto.setItems(null);

        assertNull(dto.getDate());
        assertNull(dto.getTrailNumber());
        assertNull(dto.getItems());
    }

    @Test
    void testItemsWithComplexValues() {
        // Arrange
        HSReportDto dto = new HSReportDto();
        List<HSReportItemsDto> items = new ArrayList<>();

        HSReportItemsDto item = new HSReportItemsDto();
        item.setBob("BOB123");
        item.setTotalHsGenerated(1000);
        item.setTotalHsSuppressed(200);
        item.setTotalHsSuppressedSubscriberElection(150);
        item.setTotalHsSuppressedPolicySetting(50);
        item.setTotalHsPrinted(800);
        item.setHsSuppressedPercent(20.0);

        items.add(item);
        dto.setItems(items);

        // Act & Assert
        HSReportItemsDto retrievedItem = dto.getItems().get(0);
        assertEquals("BOB123", retrievedItem.getBob());
        assertEquals(1000, retrievedItem.getTotalHsGenerated());
        assertEquals(200, retrievedItem.getTotalHsSuppressed());
        assertEquals(150, retrievedItem.getTotalHsSuppressedSubscriberElection());
        assertEquals(50, retrievedItem.getTotalHsSuppressedPolicySetting());
        assertEquals(800, retrievedItem.getTotalHsPrinted());
        assertEquals(20.0, retrievedItem.getHsSuppressedPercent());
    }

    @Test
    void testWithEdgeCases() {
        // Arrange
        HSReportDto dto = new HSReportDto();

        // Act & Assert - Empty strings
        dto.setDate("");
        dto.setTrailNumber("");
        assertEquals("", dto.getDate());
        assertEquals("", dto.getTrailNumber());

        // Act & Assert - Special characters
        dto.setDate("2023/07-31 #@!");
        dto.setTrailNumber("TR-12345_TEST*");
        assertEquals("2023/07-31 #@!", dto.getDate());
        assertEquals("TR-12345_TEST*", dto.getTrailNumber());

        // Act & Assert - Zero values in items
        List<HSReportItemsDto> items = new ArrayList<>();
        HSReportItemsDto item = new HSReportItemsDto();
        item.setBob("ZERO_TEST");
        item.setTotalHsGenerated(0);
        item.setTotalHsSuppressed(0);
        item.setTotalHsSuppressedSubscriberElection(0);
        item.setTotalHsSuppressedPolicySetting(0);
        item.setTotalHsPrinted(0);
        item.setHsSuppressedPercent(0);

        items.add(item);
        dto.setItems(items);

        HSReportItemsDto retrievedItem = dto.getItems().get(0);
        assertEquals("ZERO_TEST", retrievedItem.getBob());
        assertEquals(0, retrievedItem.getTotalHsGenerated());
        assertEquals(0, retrievedItem.getTotalHsSuppressed());
        assertEquals(0, retrievedItem.getTotalHsSuppressedSubscriberElection());
        assertEquals(0, retrievedItem.getTotalHsSuppressedPolicySetting());
        assertEquals(0, retrievedItem.getTotalHsPrinted());
        assertEquals(0, retrievedItem.getHsSuppressedPercent());

        // Act & Assert - Negative values in items
        HSReportItemsDto negativeItem = new HSReportItemsDto();
        negativeItem.setBob("NEGATIVE_TEST");
        negativeItem.setTotalHsGenerated(-100);
        negativeItem.setTotalHsSuppressed(-20);
        negativeItem.setTotalHsSuppressedSubscriberElection(-15);
        negativeItem.setTotalHsSuppressedPolicySetting(-5);
        negativeItem.setTotalHsPrinted(-80);
        negativeItem.setHsSuppressedPercent(-20.0);

        items.clear();
        items.add(negativeItem);
        dto.setItems(items);

        HSReportItemsDto retrievedNegativeItem = dto.getItems().get(0);
        assertEquals("NEGATIVE_TEST", retrievedNegativeItem.getBob());
        assertEquals(-100, retrievedNegativeItem.getTotalHsGenerated());
        assertEquals(-20, retrievedNegativeItem.getTotalHsSuppressed());
        assertEquals(-15, retrievedNegativeItem.getTotalHsSuppressedSubscriberElection());
        assertEquals(-5, retrievedNegativeItem.getTotalHsSuppressedPolicySetting());
        assertEquals(-80, retrievedNegativeItem.getTotalHsPrinted());
        assertEquals(-20.0, retrievedNegativeItem.getHsSuppressedPercent());
    }
}
