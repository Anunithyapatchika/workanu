package com.uhg.comm.edelivery.reportingservice.dto;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class HsSuppCostItemsDtoTest {

    @InjectMocks
    private HsSuppCostItemsDto hsSuppCostItemsDto;

    // Add your test cases here
    @Test
    void testGetBob() {
        hsSuppCostItemsDto.setBob("bob");
        hsSuppCostItemsDto.getBob();
        assertEquals("bob", hsSuppCostItemsDto.getBob());
    }

    @Test
    void testGetPostageCost() {
        hsSuppCostItemsDto.setPostageCost(1.0);
        hsSuppCostItemsDto.getPostageCost();
        assertEquals(1.0, hsSuppCostItemsDto.getPostageCost());
    }

    @Test
    void testGetPrintCost() {
        hsSuppCostItemsDto.setPrintCost(1.0);
        hsSuppCostItemsDto.getPrintCost();
        assertEquals(1.0, hsSuppCostItemsDto.getPrintCost());
    }

    @Test
    void testGetStmtPrinted() {
        hsSuppCostItemsDto.setStmtPrinted(1.0);
        hsSuppCostItemsDto.getStmtPrinted();
        assertEquals(1.0, hsSuppCostItemsDto.getStmtPrinted());
    }

    @Test
    void testGetHsSuppMemberElection() {
        hsSuppCostItemsDto.setHsSuppMemberElection(1.0);
        hsSuppCostItemsDto.getHsSuppMemberElection();
        assertEquals(1.0, hsSuppCostItemsDto.getHsSuppMemberElection());
    }

    @Test
    void testGetHsSuppPolicySetting() {
        hsSuppCostItemsDto.setHsSuppPolicySetting(1.0);
        hsSuppCostItemsDto.getHsSuppPolicySetting();
        assertEquals(1.0, hsSuppCostItemsDto.getHsSuppPolicySetting());
    }

    @Test
    void testGetTotalStmtSupp() {
        hsSuppCostItemsDto.setTotalStmtSupp(1.0);
        hsSuppCostItemsDto.getTotalStmtSupp();
        assertEquals(1.0, hsSuppCostItemsDto.getTotalStmtSupp());
    }

    @Test
    void testGetTotalStmtGenerated() {
        hsSuppCostItemsDto.setTotalStmtGenerated(1.0);
        hsSuppCostItemsDto.getTotalStmtGenerated();
        assertEquals(1.0, hsSuppCostItemsDto.getTotalStmtGenerated());
    }

    @Test
    void testGetTotalPrintPostCost() {
        hsSuppCostItemsDto.setTotalPrintPostCost(1.0);
        hsSuppCostItemsDto.getTotalPrintPostCost();
        assertEquals(1.0, hsSuppCostItemsDto.getTotalPrintPostCost());
    }
}
