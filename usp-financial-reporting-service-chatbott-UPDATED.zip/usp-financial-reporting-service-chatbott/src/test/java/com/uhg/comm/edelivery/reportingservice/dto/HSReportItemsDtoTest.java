package com.uhg.comm.edelivery.reportingservice.dto;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class HSReportItemsDtoTest {

    @InjectMocks
    private HSReportItemsDto hsReportItemsDto;

    @Test
    void testGettersAndSetters() {
        // Arrange & Act
        hsReportItemsDto.setBob("TestBOB");
        hsReportItemsDto.setTotalHsGenerated(1000.0);
        hsReportItemsDto.setTotalHsSuppressed(200.0);
        hsReportItemsDto.setTotalHsSuppressedSubscriberElection(150.0);
        hsReportItemsDto.setTotalHsSuppressedPolicySetting(50.0);
        hsReportItemsDto.setTotalHsPrinted(800.0);
        hsReportItemsDto.setHsSuppressedPercent(20.0);

        // Assert
        assertEquals("TestBOB", hsReportItemsDto.getBob());
        assertEquals(1000.0, hsReportItemsDto.getTotalHsGenerated());
        assertEquals(200.0, hsReportItemsDto.getTotalHsSuppressed());
        assertEquals(150.0, hsReportItemsDto.getTotalHsSuppressedSubscriberElection());
        assertEquals(50.0, hsReportItemsDto.getTotalHsSuppressedPolicySetting());
        assertEquals(800.0, hsReportItemsDto.getTotalHsPrinted());
        assertEquals(20.0, hsReportItemsDto.getHsSuppressedPercent());
    }

    @Test
    void testEqualsAndHashCode() {
        // Arrange - Create two identical objects
        HSReportItemsDto item1 = new HSReportItemsDto();
        item1.setBob("BOB123");
        item1.setTotalHsGenerated(1000.0);
        item1.setTotalHsSuppressed(200.0);
        item1.setTotalHsSuppressedSubscriberElection(150.0);
        item1.setTotalHsSuppressedPolicySetting(50.0);
        item1.setTotalHsPrinted(800.0);
        item1.setHsSuppressedPercent(20.0);

        HSReportItemsDto item2 = new HSReportItemsDto();
        item2.setBob("BOB123");
        item2.setTotalHsGenerated(1000.0);
        item2.setTotalHsSuppressed(200.0);
        item2.setTotalHsSuppressedSubscriberElection(150.0);
        item2.setTotalHsSuppressedPolicySetting(50.0);
        item2.setTotalHsPrinted(800.0);
        item2.setHsSuppressedPercent(20.0);

        // Arrange - Create a different object
        HSReportItemsDto item3 = new HSReportItemsDto();
        item3.setBob("BOB456");
        item3.setTotalHsGenerated(2000.0);
        item3.setTotalHsSuppressed(400.0);
        item3.setTotalHsSuppressedSubscriberElection(300.0);
        item3.setTotalHsSuppressedPolicySetting(100.0);
        item3.setTotalHsPrinted(1600.0);
        item3.setHsSuppressedPercent(20.0);

        // Act & Assert - Test equals
        assertEquals(item1, item2);
        assertNotEquals(item1, item3);
        assertNotEquals(item1, null);
        assertNotEquals(item1, new Object());

        // Act & Assert - Test hashCode
        assertEquals(item1.hashCode(), item2.hashCode());
        assertNotEquals(item1.hashCode(), item3.hashCode());

        // Test with just one field different
        HSReportItemsDto item4 = new HSReportItemsDto();
        item4.setBob("BOB123");
        item4.setTotalHsGenerated(1000.0);
        item4.setTotalHsSuppressed(200.0);
        item4.setTotalHsSuppressedSubscriberElection(150.0);
        item4.setTotalHsSuppressedPolicySetting(50.0);
        item4.setTotalHsPrinted(800.0);
        item4.setHsSuppressedPercent(21.0); // Different percent

        assertNotEquals(item1, item4);
        assertNotEquals(item1.hashCode(), item4.hashCode());
    }

    @Test
    void testToString() {
        // Arrange
        hsReportItemsDto.setBob("BOB123");
        hsReportItemsDto.setTotalHsGenerated(1000.0);
        hsReportItemsDto.setTotalHsSuppressed(200.0);
        hsReportItemsDto.setTotalHsSuppressedSubscriberElection(150.0);
        hsReportItemsDto.setTotalHsSuppressedPolicySetting(50.0);
        hsReportItemsDto.setTotalHsPrinted(800.0);
        hsReportItemsDto.setHsSuppressedPercent(20.0);

        // Act
        String result = hsReportItemsDto.toString();

        // Assert - Verify toString contains all field values
        assertTrue(result.contains("bob=BOB123"));
        assertTrue(result.contains("totalHsGenerated=1000.0"));
        assertTrue(result.contains("totalHsSuppressed=200.0"));
        assertTrue(result.contains("totalHsSuppressedSubscriberElection=150.0"));
        assertTrue(result.contains("totalHsSuppressedPolicySetting=50.0"));
        assertTrue(result.contains("totalHsPrinted=800.0"));
        assertTrue(result.contains("hsSuppressedPercent=20.0"));
    }

    @Test
    void testDefaultValues() {
        // Arrange
        HSReportItemsDto dto = new HSReportItemsDto();

        // Assert - Check default values
        assertNull(dto.getBob());
        assertEquals(0.0, dto.getTotalHsGenerated());
        assertEquals(0.0, dto.getTotalHsSuppressed());
        assertEquals(0.0, dto.getTotalHsSuppressedSubscriberElection());
        assertEquals(0.0, dto.getTotalHsSuppressedPolicySetting());
        assertEquals(0.0, dto.getTotalHsPrinted());
        assertEquals(0.0, dto.getHsSuppressedPercent());
    }

    @Test
    void testNullHandling() {
        // Arrange & Act
        hsReportItemsDto.setBob(null);

        // Assert
        assertNull(hsReportItemsDto.getBob());

        // Test setting and then unsetting
        hsReportItemsDto.setBob("TestBOB");
        assertEquals("TestBOB", hsReportItemsDto.getBob());
        hsReportItemsDto.setBob(null);
        assertNull(hsReportItemsDto.getBob());
    }

    @Test
    void testEdgeCases() {
        // Test with empty string
        hsReportItemsDto.setBob("");
        assertEquals("", hsReportItemsDto.getBob());

        // Test with special characters
        hsReportItemsDto.setBob("BOB-123_TEST*&^%$#@!");
        assertEquals("BOB-123_TEST*&^%$#@!", hsReportItemsDto.getBob());

        // Test with zero values
        hsReportItemsDto.setTotalHsGenerated(0);
        hsReportItemsDto.setTotalHsSuppressed(0);
        hsReportItemsDto.setTotalHsSuppressedSubscriberElection(0);
        hsReportItemsDto.setTotalHsSuppressedPolicySetting(0);
        hsReportItemsDto.setTotalHsPrinted(0);
        hsReportItemsDto.setHsSuppressedPercent(0);

        assertEquals(0, hsReportItemsDto.getTotalHsGenerated());
        assertEquals(0, hsReportItemsDto.getTotalHsSuppressed());
        assertEquals(0, hsReportItemsDto.getTotalHsSuppressedSubscriberElection());
        assertEquals(0, hsReportItemsDto.getTotalHsSuppressedPolicySetting());
        assertEquals(0, hsReportItemsDto.getTotalHsPrinted());
        assertEquals(0, hsReportItemsDto.getHsSuppressedPercent());

        // Test with negative values
        hsReportItemsDto.setTotalHsGenerated(-1000);
        hsReportItemsDto.setTotalHsSuppressed(-200);
        hsReportItemsDto.setTotalHsSuppressedSubscriberElection(-150);
        hsReportItemsDto.setTotalHsSuppressedPolicySetting(-50);
        hsReportItemsDto.setTotalHsPrinted(-800);
        hsReportItemsDto.setHsSuppressedPercent(-20);

        assertEquals(-1000, hsReportItemsDto.getTotalHsGenerated());
        assertEquals(-200, hsReportItemsDto.getTotalHsSuppressed());
        assertEquals(-150, hsReportItemsDto.getTotalHsSuppressedSubscriberElection());
        assertEquals(-50, hsReportItemsDto.getTotalHsSuppressedPolicySetting());
        assertEquals(-800, hsReportItemsDto.getTotalHsPrinted());
        assertEquals(-20, hsReportItemsDto.getHsSuppressedPercent());
    }

    @Test
    void testBoundaryValues() {
        // Test with minimum and maximum double values
        hsReportItemsDto.setTotalHsGenerated(Double.MIN_VALUE);
        hsReportItemsDto.setTotalHsSuppressed(Double.MAX_VALUE);

        assertEquals(Double.MIN_VALUE, hsReportItemsDto.getTotalHsGenerated());
        assertEquals(Double.MAX_VALUE, hsReportItemsDto.getTotalHsSuppressed());

        // Test with infinity and NaN
        hsReportItemsDto.setTotalHsSuppressedSubscriberElection(Double.POSITIVE_INFINITY);
        hsReportItemsDto.setTotalHsSuppressedPolicySetting(Double.NEGATIVE_INFINITY);
        hsReportItemsDto.setTotalHsPrinted(Double.NaN);

        assertEquals(Double.POSITIVE_INFINITY, hsReportItemsDto.getTotalHsSuppressedSubscriberElection());
        assertEquals(Double.NEGATIVE_INFINITY, hsReportItemsDto.getTotalHsSuppressedPolicySetting());
        assertTrue(Double.isNaN(hsReportItemsDto.getTotalHsPrinted()));

        // Test with very large string
        StringBuilder largeString = new StringBuilder();
        for (int i = 0; i < 1000; i++) {
            largeString.append("test");
        }
        hsReportItemsDto.setBob(largeString.toString());
        assertEquals(largeString.toString(), hsReportItemsDto.getBob());
    }

    @Test
    void testFloatingPointPrecision() {
        // Test precision with floating point values
        double value = 0.1 + 0.2; // Known to not equal exactly 0.3 in binary floating point
        hsReportItemsDto.setHsSuppressedPercent(value);

        // The test should handle floating point precision issues
        assertEquals(0.30000000000000004, hsReportItemsDto.getHsSuppressedPercent());

        // Test with very small difference
        hsReportItemsDto.setTotalHsGenerated(1.0);
        hsReportItemsDto.setTotalHsSuppressed(1.0 + Double.MIN_VALUE);

    }

    @Test
    void testSequentialUpdates() {
        // Test updating values multiple times
        hsReportItemsDto.setBob("BOB1");
        assertEquals("BOB1", hsReportItemsDto.getBob());

        hsReportItemsDto.setBob("BOB2");
        assertEquals("BOB2", hsReportItemsDto.getBob());

        hsReportItemsDto.setTotalHsGenerated(100);
        assertEquals(100, hsReportItemsDto.getTotalHsGenerated());

        hsReportItemsDto.setTotalHsGenerated(200);
        assertEquals(200, hsReportItemsDto.getTotalHsGenerated());
    }

    @Test
    void testPercentageCalculations() {
        // Test with realistic percentage scenarios
        hsReportItemsDto.setTotalHsGenerated(1000);
        hsReportItemsDto.setTotalHsSuppressed(250);
        hsReportItemsDto.setHsSuppressedPercent(25.0);

        // Verify the percentage matches what would be calculated
        double calculatedPercentage = (hsReportItemsDto.getTotalHsSuppressed() / hsReportItemsDto.getTotalHsGenerated()) * 100;
        assertEquals(25.0, calculatedPercentage);
        assertEquals(hsReportItemsDto.getHsSuppressedPercent(), calculatedPercentage);

        // Edge case with zero generated
        hsReportItemsDto.setTotalHsGenerated(0);
        hsReportItemsDto.setTotalHsSuppressed(0);
        hsReportItemsDto.setHsSuppressedPercent(0);

        // Avoid division by zero in this test
        assertEquals(0, hsReportItemsDto.getHsSuppressedPercent());
    }
}
