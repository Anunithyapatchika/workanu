package com.uhg.comm.edelivery.reportingservice.service;

import com.uhg.comm.edelivery.emailservice.EmailService;
import com.uhg.comm.edelivery.processLog.Processlog;
import com.uhg.comm.edelivery.reportingservice.service.impl.SendEmailServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.commons.util.ReflectionUtils;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.util.ReflectionTestUtils;
import org.thymeleaf.context.Context;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SendEmailServiceImplTest {

    @Mock
    private EmailService emailService;

    @InjectMocks
    private SendEmailServiceImpl sendEmailService;

    @Value("${edelivery.configproperties.properties.edeliveryEmail.distributionEmails}")
    private final String distributionEmails = "test@example.com";

    @Value("${edelivery.configproperties.properties.edeliveryEmail.alertDistributionEmails}")
    private final String alertDistributionEmails = "alert@example.com";

    @Value("${edelivery.configproperties.properties.edeliveryEmail.environment}")
    private final String environment = "ENV_QDEV";

    @Test
    void testSendEmail_Success() throws Exception {
        Processlog processlog = new Processlog();
        processlog.setReqEntryTimestamp(new Timestamp(System.currentTimeMillis()).toString());
        processlog.setStatus("SUCCESS");
        processlog.setTrailNumber("12345");
        ReflectionTestUtils.setField(sendEmailService, "distributionEmails", distributionEmails);
        ReflectionTestUtils.setField(sendEmailService, "alertDistributionEmails", alertDistributionEmails);
        ReflectionTestUtils.setField(sendEmailService, "environment", environment);

        doNothing().when(emailService).sendMessageUsingThymeleafTemplate(anyString(), any(Context.class), anyString(), anyString(), anyList());

        boolean result = sendEmailService.sendEmail(processlog);

        assertTrue(result);
        verify(emailService, times(1)).sendMessageUsingThymeleafTemplate(anyString(), any(Context.class), anyString(), anyString(), anyList());
    }

    @Test
    void testSendEmail_Failed() throws Exception {
        Processlog processlog = new Processlog();
        processlog.setStatus("FAILED");
        processlog.setTrailNumber("12345");
        ReflectionTestUtils.setField(sendEmailService, "distributionEmails", distributionEmails);
        ReflectionTestUtils.setField(sendEmailService, "alertDistributionEmails", alertDistributionEmails);
        ReflectionTestUtils.setField(sendEmailService, "environment", environment);
        processlog.setReqEntryTimestamp(new Timestamp(System.currentTimeMillis()).toString());
        doNothing().when(emailService).sendMessageUsingThymeleafTemplate(anyString(), any(Context.class), anyString(), anyString(), anyList());

        boolean result = sendEmailService.sendEmail(processlog);

        assertTrue(result);
        verify(emailService, times(1)).sendMessageUsingThymeleafTemplate(anyString(), any(Context.class), anyString(), anyString(), anyList());
    }

    @Test
    void testSendEmail_NewBobDetected() throws Exception {
        Processlog processlog = new Processlog();
        processlog.setStatus("NEW BOB DETECTED");
        processlog.setTrailNumber("12345");
        ReflectionTestUtils.setField(sendEmailService, "distributionEmails", distributionEmails);
        ReflectionTestUtils.setField(sendEmailService, "alertDistributionEmails", alertDistributionEmails);
        ReflectionTestUtils.setField(sendEmailService, "environment", environment);
        processlog.setReqEntryTimestamp(new Timestamp(System.currentTimeMillis()).toString());
        doNothing().when(emailService).sendMessageUsingThymeleafTemplate(anyString(), any(Context.class), anyString(), anyString(), anyList());

        boolean result = sendEmailService.sendEmail(processlog);

        assertTrue(result);
        verify(emailService, times(1)).sendMessageUsingThymeleafTemplate(anyString(), any(Context.class), anyString(), anyString(), anyList());
    }

    @Test
    void testSendEmail_Exception() throws Exception {
        Processlog processlog = new Processlog();
        processlog.setStatus("SUCCESS");
        processlog.setTrailNumber("12345");
        processlog.setReqEntryTimestamp(new Timestamp(System.currentTimeMillis()).toString());
        ReflectionTestUtils.setField(sendEmailService, "distributionEmails", distributionEmails);
        ReflectionTestUtils.setField(sendEmailService, "alertDistributionEmails", alertDistributionEmails);
        ReflectionTestUtils.setField(sendEmailService, "environment", environment);
        doThrow(new RuntimeException("Email error")).when(emailService).sendMessageUsingThymeleafTemplate(anyString(), any(Context.class), anyString(), anyString(), anyList());

        boolean result = sendEmailService.sendEmail(processlog);

        assertFalse(result);
        verify(emailService, times(1)).sendMessageUsingThymeleafTemplate(anyString(), any(Context.class), anyString(), anyString(), anyList());
    }

    @Test
    void testCreateContextForMail_BasicData() {
        // Arrange
        Context context = new Context();
        Processlog processlog = new Processlog();
        processlog.setStatus("SUCCESS");
        processlog.setServiceName("TestService");
        processlog.setApiName("TestAPI");
        processlog.setTrailNumber("12345");
        processlog.setReqEntryTimestamp(new Timestamp(System.currentTimeMillis()).toString());

        ReflectionTestUtils.setField(sendEmailService, "environment", "ENV_QDEV");

        // Act
        sendEmailService.createContextForMail(context, processlog);

        // Assert
        assertEquals("SUCCESS", context.getVariable("status"));
        assertEquals("ENV_QDEV", context.getVariable("environment"));
        assertEquals("TestService - TestAPI", context.getVariable("source"));
        assertEquals("12345", context.getVariable("trailnum"));
        assertEquals("NO DATA", context.getVariable("data"));
    }

    @Test
    void testCreateContextForMail_FailedStatus() {
        // Arrange
        Context context = new Context();
        Processlog processlog = new Processlog();
        processlog.setStatus("FAILED");
        processlog.setErrorMessage("Test error message");

        ReflectionTestUtils.setField(sendEmailService, "environment", "ENV_QDEV");

        // Act
        sendEmailService.createContextForMail(context, processlog);

        // Assert
        assertEquals("FAILED", context.getVariable("status"));
        assertEquals("Test error message", context.getVariable("errorMessage"));
    }

    @Test
    void testCreateContextForMail_WithAdditionalProperties() {
        // Arrange
        Context context = new Context();
        Processlog processlog = new Processlog();
        processlog.setStatus("SUCCESS");

        processlog.setAdditionalProperty("fetchedDate", "2023-01-01");
        processlog.setAdditionalProperty("newBob", "Bob123");
        processlog.setAdditionalProperty("newBobDate", "2023-02-01");


        ReflectionTestUtils.setField(sendEmailService, "environment", "ENV_QDEV");

        // Act
        sendEmailService.createContextForMail(context, processlog);

        // Assert
        assertEquals("2023-01-01", context.getVariable("fetchedDate"));
        assertEquals("Bob123", context.getVariable("newBob"));
        assertEquals("2023-02-01", context.getVariable("newBobDate"));
    }

    @Test
    void testCreateContextForMail_WithListData() {
        // Arrange
        Context context = new Context();
        Processlog processlog = new Processlog();
        processlog.setStatus("SUCCESS");

        // Create a test class that mimics what might be in the list
        class TestReport {
            private String name = "Test Report";
            private int count = 123;

            public String getName() { return name; }
            public int getCount() { return count; }
        }

        List<TestReport> reportList = Collections.singletonList(new TestReport());

        processlog.setAdditionalProperty("list", reportList);

        ReflectionTestUtils.setField(sendEmailService, "environment", "ENV_QDEV");

        // Act
        sendEmailService.createContextForMail(context, processlog);

        // Assert
        assertEquals(reportList, context.getVariable("data"));
        assertNotNull(context.getVariable("reportData"));
        List<Map<String, Object>> reportData = (List<Map<String, Object>>) context.getVariable("reportData");
        assertEquals(1, reportData.size());
        assertEquals("Test Report", reportData.get(0).get("name"));
        assertEquals(123, reportData.get(0).get("count"));
    }
}