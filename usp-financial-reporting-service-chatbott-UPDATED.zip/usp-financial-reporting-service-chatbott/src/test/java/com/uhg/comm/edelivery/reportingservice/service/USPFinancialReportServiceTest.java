package com.uhg.comm.edelivery.reportingservice.service;

import com.uhg.comm.edelivery.reportingservice.bean.GetFieldValues;
import com.uhg.comm.edelivery.reportingservice.dto.*;
import com.uhg.comm.edelivery.reportingservice.model.PrintingCostReport;
import com.uhg.comm.edelivery.reportingservice.model.USPFinancialReport;
import com.uhg.comm.edelivery.reportingservice.repository.PrintingCostReportRepository;
import com.uhg.comm.edelivery.reportingservice.repository.USPFinancialReportRepository;
import com.uhg.comm.edelivery.reportingservice.util.DateUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class USPFinancialReportServiceTest {

    @Mock
    private USPFinancialReportRepository uspFinancialReportRepository;

    @Mock
    private PrintingCostReportService printingCostReportService;

    @InjectMocks
    private USPFinancialReportService uspFinancialReportService;

    @Mock
    private PrintingCostReportRepository printingCostReportRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetFinancialReport() {
        // Define Test Parameter
        String trailNumber = "12345";
        String startDate = "January 2023";
        String endDate = "February 2023";

        // Initialize mock reports
        USPFinancialReport report1 = new USPFinancialReport();
        report1.setMonthYearStr("January 2023");
        report1.setBob("Bob1");
        report1.setTotalEobGenerated(10);
        report1.setTotalEobSuppressed(5);
        report1.setMemberElectionEob(3);
        report1.setPolicySettingEob(2);
        report1.setTotalEobPrinted(5);
        report1.setEobSuppressPercent(50.0);

        USPFinancialReport report2 = new USPFinancialReport();
        report2.setMonthYearStr("February 2023");
        report2.setBob("Bob2");
        report2.setTotalEobGenerated(20);
        report2.setTotalEobSuppressed(10);
        report2.setMemberElectionEob(6);
        report2.setPolicySettingEob(4);
        report2.setTotalEobPrinted(10);
        report2.setEobSuppressPercent(60.0);

        List<USPFinancialReport> mockReports = Arrays.asList(report1, report2);

        // Mock the repository method to return the mock list
        when(uspFinancialReportRepository.findByTrailNumberAndBetweenMonthYearStr(
                anyString(), any(LocalDate.class), any(LocalDate.class)))
                .thenReturn(mockReports);

        // Mock the printing cost report service method
        PrintCostResponse printCostResponse = new PrintCostResponse();
        printCostResponse.setDate("January 2023");
        printCostResponse.setTrailNumber(trailNumber);
        PrintCostResponseItems items = new PrintCostResponseItems();
        items.setBob("Tufts");
        items.setPaperLabourCost(5);
        items.setEnvelopeCount(10);

        printCostResponse.setItems(List.of(items));
        when(printingCostReportService.getPrintCostReportResponse(
                anyString(), any(LocalDate.class), any(LocalDate.class), anyList()))
                .thenReturn(List.of(printCostResponse));

        // Call the service method
        FinancialReportResponseDto response = uspFinancialReportService.getFinancialReport(
                trailNumber, startDate, endDate);

        // Assert the response
        assertNotNull(response);
        assertEquals(3, response.getEobPrintSuppressCountReport().size());
        assertEquals(3, response.getCaePrintSuppressCountReport().size());
        assertEquals(3, response.getHsPrintSuppressCountReport().size());
        assertEquals(1, response.getPrintCostReport().size());
    }

    @Test
    void testFetchIsCompletedValuesSuccess() {
        // Define test parameters
        String trailName = "trail1";
        String startDate = "January 2023";
        String endDate = "February 2023";

        // Mock data
        Object[] report1 = new Object[]{"Bob1", "2023-01", 1, 1};
        Object[] report2 = new Object[]{"Bob2", "2023-01", 0, 1};
        List<Object[]> mockReports = Arrays.asList(report1, report2);

        // Mock repository method
        when(uspFinancialReportRepository.getDetailsFromDB(anyString(), any(LocalDate.class), any(LocalDate.class)))
                .thenReturn(mockReports);

        // Call the method
        HashMap<String, List<GetFieldValues>> result = uspFinancialReportService.fetchIsCompletedValues(trailName, startDate, endDate);

        // Assert the result
        assertNotNull(result);
        assertEquals(1, result.size());
        assertTrue(result.containsKey("2023-01"));
        assertEquals(2, result.get("2023-01").size());

        GetFieldValues fieldValue1 = result.get("2023-01").get(0);
        assertEquals("Bob1", fieldValue1.getBob());
        assertEquals(1, fieldValue1.getIsCompleted());
        assertEquals(1, fieldValue1.getIsTxCompleted());

        GetFieldValues fieldValue2 = result.get("2023-01").get(1);
        assertEquals("Bob2", fieldValue2.getBob());
        assertEquals(0, fieldValue2.getIsCompleted());
        assertEquals(1, fieldValue2.getIsTxCompleted());
    }

    @Test
    void testFetchIsCompletedValuesNoRecords() {
        // Define test parameters
        String trailName = "trail1";
        String startDate = "January 2023";
        String endDate = "February 2023";

        // Mock repository method to return an empty list
        when(uspFinancialReportRepository.getDetailsFromDB(anyString(), any(LocalDate.class), any(LocalDate.class)))
                .thenReturn(Collections.emptyList());

        // Call the method
        HashMap<String, List<GetFieldValues>> result = uspFinancialReportService.fetchIsCompletedValues(trailName, startDate, endDate);

        // Assert the result
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testSaveHsSuppDataFromPrintCostReportForPT3231_ExistingReport() {
        // Mock data
        PrintingCostReport printingCostReport = new PrintingCostReport();
        printingCostReport.setTrailName("trail1");
        printingCostReport.setMonth("January 2023");
        printingCostReport.setBob("Bob1");

        USPFinancialReport uspFinancialReport = new USPFinancialReport();
        uspFinancialReport.setIsCompleted(0);

        when(printingCostReportRepository.findByTrailNameAndBobAndMonth(anyString(), anyString(), anyString()))
                .thenReturn(Optional.of(printingCostReport));
        when(uspFinancialReportRepository.findByMonthYearStrAndBobAndTrailName(anyString(), anyString(), anyString()))
                .thenReturn(Optional.of(uspFinancialReport));

        // Call the method
        uspFinancialReportService.saveHsSuppDataFromPrintCostReportForPT3231(printingCostReport);

        // Verify the interactions
        verify(uspFinancialReportRepository, times(1)).save(any(USPFinancialReport.class));
    }

    @Test
    void testSaveHsSuppDataFromPrintCostReportForPT3231_NewReport() {
        // Mock data
        PrintingCostReport printingCostReport = new PrintingCostReport();
        printingCostReport.setTrailName("trail1");
        printingCostReport.setMonth("January 2023");
        printingCostReport.setBob("Bob1");

        when(printingCostReportRepository.findByTrailNameAndBobAndMonth(anyString(), anyString(), anyString()))
                .thenReturn(Optional.of(printingCostReport));
        when(uspFinancialReportRepository.findByMonthYearStrAndBobAndTrailName(anyString(), anyString(), anyString()))
                .thenReturn(Optional.empty());

        // Call the method
        uspFinancialReportService.saveHsSuppDataFromPrintCostReportForPT3231(printingCostReport);

        // Verify the interactions
        verify(uspFinancialReportRepository, times(1)).save(any(USPFinancialReport.class));
    }

    @Test
    void testSaveHsSuppDataFromPrintCostReportForPT3231_NoPrintingCostReport() {
        // Mock data
        PrintingCostReport printingCostReport = new PrintingCostReport();
        printingCostReport.setTrailName("trail1");
        printingCostReport.setMonth("January 2023");
        printingCostReport.setBob("Bob1");

        when(printingCostReportRepository.findByTrailNameAndBobAndMonth(anyString(), anyString(), anyString()))
                .thenReturn(Optional.empty());

        // Call the method
        uspFinancialReportService.saveHsSuppDataFromPrintCostReportForPT3231(printingCostReport);

        // Verify no interactions with uspFinancialReportRepository
        verify(uspFinancialReportRepository, times(0)).save(any(USPFinancialReport.class));
    }

    @Test
    void testGetFinancialReport_WithMultiplePrintCostResponses() {
        // Mock data
        String trailNumber = "12345";
        String startDate = "January 2023";
        String endDate = "February 2023";

        PrintCostResponseItems item1 = new PrintCostResponseItems();
        item1.setBob("Business1");
        item1.setPostageCost(10.0);
        item1.setPaperLabourCost(5.0);
        item1.setCostPerEnvelop(2.0);
        item1.setEnvelopeCount(100.0);

        PrintCostResponseItems item2 = new PrintCostResponseItems();
        item2.setBob("Business2");
        item2.setPostageCost(20.0);
        item2.setPaperLabourCost(10.0);
        item2.setCostPerEnvelop(4.0);
        item2.setEnvelopeCount(200.0);

        PrintCostResponse response1 = new PrintCostResponse();
        response1.setDate("January 2023");
        response1.setTrailNumber(trailNumber);
        response1.setItems(List.of(item1));

        PrintCostResponse response2 = new PrintCostResponse();
        response2.setDate("February 2023");
        response2.setTrailNumber(trailNumber);
        response2.setItems(List.of(item2));

        List<PrintCostResponse> printCostResponseList = Arrays.asList(response1, response2);

        // Call the method
        uspFinancialReportService.getFinancialReport(trailNumber, startDate, endDate);

        // Verify the results
        assertEquals(2, printCostResponseList.size());
    }

    @Test
    void testGetFinancialReport_WithSinglePrintCostResponse() {
        // Mock data
        String trailNumber = "12345";
        String startDate = "January 2023";
        String endDate = "January 2023";

        PrintCostResponseItems item1 = new PrintCostResponseItems();
        item1.setBob("Business1");
        item1.setPostageCost(10.0);
        item1.setPaperLabourCost(5.0);
        item1.setCostPerEnvelop(2.0);
        item1.setEnvelopeCount(100.0);

        PrintCostResponse response1 = new PrintCostResponse();
        response1.setDate("January 2023");
        response1.setTrailNumber(trailNumber);
        response1.setItems(List.of(item1));

        List<PrintCostResponse> printCostResponseList = List.of(response1);

        // Call the method
        uspFinancialReportService.getFinancialReport(trailNumber, startDate, endDate);

        // Verify the results
        assertEquals(1, printCostResponseList.size());
        assertEquals("January 2023", printCostResponseList.get(0).getDate());
        assertEquals(trailNumber, printCostResponseList.get(0).getTrailNumber());
        assertEquals(1, printCostResponseList.get(0).getItems().size());
    }

    @Test
    void testGetFinancialReport_WithMultiplePrintCostResponses1() {
        // Mock data
        String trailNumber = "12345";
        String startDate = "January 2023";
        String endDate = "February 2023";

        PrintCostResponseItems item1 = new PrintCostResponseItems();
        item1.setBob("Business1");
        item1.setPostageCost(10.0);
        item1.setPaperLabourCost(5.0);
        item1.setCostPerEnvelop(2.0);
        item1.setEnvelopeCount(100.0);

        PrintCostResponseItems item2 = new PrintCostResponseItems();
        item2.setBob("Business2");
        item2.setPostageCost(20.0);
        item2.setPaperLabourCost(10.0);
        item2.setCostPerEnvelop(4.0);
        item2.setEnvelopeCount(200.0);

        PrintCostResponse response1 = new PrintCostResponse();
        response1.setDate("January 2023");
        response1.setTrailNumber(trailNumber);
        response1.setItems(List.of(item1));

        PrintCostResponse response2 = new PrintCostResponse();
        response2.setDate("February 2023");
        response2.setTrailNumber(trailNumber);
        response2.setItems(List.of(item2));

        List<PrintCostResponse> printCostResponseList = Arrays.asList(response1, response2);

        when(printingCostReportService.getPrintCostReportResponse(anyString(), any(LocalDate.class), any(LocalDate.class), anyList()))
                .thenReturn(printCostResponseList);

        // Call the method
        uspFinancialReportService.getFinancialReport(trailNumber, startDate, endDate);

        // Verify the results
        assertEquals(2, printCostResponseList.size());
        assertEquals(trailNumber, printCostResponseList.get(0).getTrailNumber());
        assertEquals(1, printCostResponseList.get(0).getItems().size());
    }
}