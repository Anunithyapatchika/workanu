package com.uhg.comm.edelivery.reportingservice.controller;

import com.uhg.comm.edelivery.reportingservice.dto.EHSFinancialReportResponseDto;
import com.uhg.comm.edelivery.reportingservice.dto.HsSuppCostDto;
import com.uhg.comm.edelivery.reportingservice.model.HSSuppCostReport;
import com.uhg.comm.edelivery.reportingservice.service.HSSuppCostReportService;
import com.uhg.comm.edelivery.reportingservice.service.USP3696DataService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class HsSuppCostControllerTest {

    @InjectMocks
    private HsSuppCostController hsSuppCostController;

    @Mock
    private HSSuppCostReportService hsSuppCostReportService;

    @Mock
    private USP3696DataService usp3696DataService;

    @Test
    void testGetHsSuppCostReport() {

        EHSFinancialReportResponseDto ehsFinancialReportResponseDto = new EHSFinancialReportResponseDto();
        when(hsSuppCostReportService.getHSSuppCostReport(anyString(), anyString(), anyString()))
                .thenReturn(ehsFinancialReportResponseDto);
        // Call the method and verify
         hsSuppCostController.getAllFinancialReports("trailName", "bob", "month");
        verify(hsSuppCostReportService, times(1)).getHSSuppCostReport("trailName", "bob", "month");
    }
}