package com.uhg.comm.edelivery.reportingservice.repository;

import com.uhg.comm.edelivery.processLog.Processlog;
import com.uhg.comm.edelivery.reportingservice.model.USP3696Data;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class USP3696DataRepositoryTest {

    @InjectMocks
    private USP3696DataRepository usp3696DataRepository;

    @Mock
    private JdbcTemplate jdbcTemplate;

    @Mock
    private Processlog processlog;

    @BeforeEach
    void setUp() {
        // Setup code if needed
        rowMapper = new USP3696DataRepository.USP3696DataRowMapper();
        resultSet = mock(ResultSet.class);
    }

    @Test
    void testGetUSP3696Data_Success() {
        // Mock data
        String dateFilter = "BETWEEN '2023-01-01' AND '2023-01-31'";
        USP3696Data mockData = new USP3696Data();
        mockData.setId(1);
        mockData.setBookOfBusiness("Business1");
        mockData.setTotal(100);
        mockData.setClaimCount(50);
        mockData.setPrintCount(30);
        mockData.setMemSupp(10);
        mockData.setPolicySupp(5);
        mockData.setSuppress(20);
        mockData.setCreatedDate(Date.valueOf(LocalDate.of(2023, 1, 1)));
        List<USP3696Data> mockDataList = List.of(mockData);

        when(jdbcTemplate.query(anyString(), any(Object[].class), any(RowMapper.class))).thenReturn(mockDataList);
        // Call the method
        List<USP3696Data> result = usp3696DataRepository.getUSP3696Data(dateFilter, processlog);

        // Assert the result
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Business1", result.get(0).getBookOfBusiness());
        assertEquals(100, result.get(0).getTotal());
    }

    @Test
    void testGetUSP3696Data_Exception() {
        // Mock data
        String dateFilter = "BETWEEN '2023-01-01' AND '2023-01-31'";
        when(jdbcTemplate.query(any(), (Object[]) any(),any((RowMapper.class)))).thenThrow(new RuntimeException("Database error"));

        // Call the method and assert exception
        Exception exception = assertThrows(RuntimeException.class, () -> {
            usp3696DataRepository.getUSP3696Data(dateFilter, processlog);
        });

        assertEquals("Database error", exception.getMessage());
        verify(processlog, times(1)).setErrorMessage("Error while fetching USP3696 data");
    }

    private USP3696DataRepository.USP3696DataRowMapper rowMapper;
    private ResultSet resultSet;


    @Test
    void testMapRow_Success() throws SQLException {
        // Mock ResultSet data
        when(resultSet.getInt("id")).thenReturn(1);
        when(resultSet.getDate("created_date")).thenReturn(Date.valueOf(LocalDate.of(2023, 1, 1)));
        when(resultSet.getInt("claim_count")).thenReturn(50);
        when(resultSet.getInt("mem_supp")).thenReturn(10);
        when(resultSet.getInt("policy_supp")).thenReturn(5);
        when(resultSet.getInt("print_count")).thenReturn(30);
        when(resultSet.getInt("suppress")).thenReturn(20);
        when(resultSet.getInt("total")).thenReturn(100);
        when(resultSet.getInt("mem_print")).thenReturn(1);
        when(resultSet.getObject("mem_print")).thenReturn(1);
        when(resultSet.getString("book_of_business")).thenReturn("Business1");

        // Call the method
        USP3696Data result = rowMapper.mapRow(resultSet, 1);

        // Assert the result
        assertNotNull(result);
        assertEquals(1, result.getId());
        assertEquals(Date.valueOf(LocalDate.of(2023, 1, 1)), result.getCreatedDate());
        assertEquals(50, result.getClaimCount());
        assertEquals(10, result.getMemSupp());
        assertEquals(5, result.getPolicySupp());
        assertEquals(30, result.getPrintCount());
        assertEquals(20, result.getSuppress());
        assertEquals(100, result.getTotal());
        assertEquals("Business1", result.getBookOfBusiness());
    }

    @Test
    void testMapRow_Exception() throws SQLException {
        // Mock ResultSet to throw SQLException
        when(resultSet.getInt(anyString())).thenThrow(new SQLException("Database error"));

        // Call the method and assert exception
        assertThrows(SQLException.class, () -> {
            rowMapper.mapRow(resultSet, 1);
        });
    }
}