package com.uhg.comm.edelivery.reportingservice.controller;

import com.uhg.comm.edelivery.reportingservice.dto.FinancialReportResponseDto;
import com.uhg.comm.edelivery.reportingservice.service.USPFinancialReportService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

class USPFinancialReportControllerTest {

    @Mock
    private USPFinancialReportService uspFinancialReportService;

    @InjectMocks
    private USPFinancialReportController uspFinancialReportController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllFinancialReports() {
        // Define test parameters
        String trailNumber = "12345";
        String startDate = "January 2023";
        String endDate = "January 2024";
        int offset = 0;
        int limit = 10;

        // Create a mock response
        FinancialReportResponseDto mockResponse = new FinancialReportResponseDto();

        // Mock the service method to return the mock response
        when(uspFinancialReportService.getFinancialReport(anyString(), anyString(), anyString()))
                .thenReturn(mockResponse);

        // Call the controller method and get the response
         ResponseEntity<FinancialReportResponseDto> response = uspFinancialReportController.getAllFinancialReports(trailNumber, startDate, endDate);

        // Assert that the response is as expected
        assertEquals(ResponseEntity.ok(mockResponse), response);
    }
}