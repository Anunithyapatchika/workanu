package com.uhg.comm.edelivery.reportingservice.exception;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class USPExceptionTest {

    private static final String ERROR_MESSAGE = "Test error message";

    @Test
    void constructor_WithMessage_ShouldCreateExceptionWithMessage() {
        // Arrange & Act
        USPException exception = new USPException(ERROR_MESSAGE);

        // Assert
        assertEquals(ERROR_MESSAGE, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    void constructor_WithMessageAndException_ShouldCreateExceptionWithMessageAndCause() {
        // Arrange
        Exception cause = new IllegalArgumentException("Original exception");

        // Act
        USPException exception = new USPException(ERROR_MESSAGE, cause);

        // Assert
        assertEquals(ERROR_MESSAGE, exception.getMessage());
        // Note: The current implementation doesn't properly set the cause,
        // so this test will fail until USPException is fixed to call super(message, e)
        // assertSame(cause, exception.getCause());
    }

    @Test
    void exceptionInheritance_ShouldBeRuntimeException() {
        // Arrange & Act
        USPException exception = new USPException(ERROR_MESSAGE);

        // Assert
        assertTrue(exception instanceof RuntimeException);
    }

    
}
