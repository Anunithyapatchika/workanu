package com.uhg.comm.edelivery.reportingservice.scheduler;

import com.uhg.comm.edelivery.reportingservice.service.USP3696DataService;
import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.core.SimpleLock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class USP3696SchedulerTest {

    @InjectMocks
    private USP3696Scheduler usp3696Scheduler;

    @Mock
    private USP3696DataService usp3696DataService;

    @Mock
    private LockProvider lockProvider;

    @Mock
    private SimpleLock simpleLock;

    @Test
    void testUpdateTotalRecordCount() {
        // Call the method
        usp3696Scheduler.updateTotalRecordCount();

        // Verify the interactions
        verify(usp3696DataService, times(1)).process();
    }

    @Test
    void testUpdateTotalRecordCountWithLock() {
        // Call the method
        usp3696Scheduler.updateTotalRecordCount();

        // Verify the interactions
        verify(usp3696DataService, times(1)).process();
    }
}