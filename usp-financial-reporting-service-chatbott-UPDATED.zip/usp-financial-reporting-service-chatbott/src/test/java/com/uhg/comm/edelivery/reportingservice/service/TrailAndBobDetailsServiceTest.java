package com.uhg.comm.edelivery.reportingservice.service;

import com.uhg.comm.edelivery.reportingservice.model.TrailAndBobDetails;
import com.uhg.comm.edelivery.reportingservice.repository.TrailAndBobRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Set;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TrailAndBobDetailsServiceTest {

    @InjectMocks
    private TrailAndBobDetailsService trailAndBobDetailsService;

    @Mock
    private TrailAndBobRepository trailAndBobRepository;

    @Test
    void getActiveTrailAndBobDetails() {
        Set<TrailAndBobDetails> a = new ArrayList<TrailAndBobDetails>().stream().collect(Collectors.toSet());
        when(trailAndBobRepository.findByIsActive(1)).thenReturn(a);
        Set<TrailAndBobDetails> result = trailAndBobDetailsService.getActiveTrailAndBobDetails();
        assertNotNull(result);
    }



}