package com.uhg.comm.edelivery.reportingservice.controller;

import com.uhg.comm.edelivery.reportingservice.dto.PrintingCostDto;
import com.uhg.comm.edelivery.reportingservice.repository.PrintingCostReportRepository;
import com.uhg.comm.edelivery.reportingservice.service.HSSuppCostReportService;
import com.uhg.comm.edelivery.reportingservice.service.PrintingCostReportService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PrintingCostReportControllerTest {

    @InjectMocks
    private PrintingCostReportController printingCostReportController;

    @Mock
    private PrintingCostReportService printingCostReportService;

    @Mock
    private PrintingCostReportRepository printingCostReportRepository;

    @Mock
    private HSSuppCostReportService hsSuppCostReportService;

    @Test
    void testGetPrintingCostReport() {
        // Mock data
        PrintingCostDto printingCostDto = PrintingCostDto.builder().bob("PT3696").build();
        when(printingCostReportService.getByTrailBOBAndMonth(anyString(),anyString(),anyString())).thenReturn(printingCostDto);

        // Call the method and verify
        printingCostReportController.checkExistingData("PT3696", "BOB", "3");
        verify(printingCostReportService, times(1)).getByTrailBOBAndMonth("PT3696", "BOB", "3");

    }

    @Test
    void testGetPrintingCostReportNull() {
        // Mock data
        PrintingCostDto printingCostDto = null;
        when(printingCostReportService.getByTrailBOBAndMonth(anyString(),anyString(),anyString())).thenReturn(printingCostDto);

        // Call the method and verify
        printingCostReportController.checkExistingData("PT3696", "BOB", "3");
        verify(printingCostReportService, times(1)).getByTrailBOBAndMonth("PT3696", "BOB", "3");

    }

    @Test
    void testSavePostageCostReport(){
        // Mock data
        PrintingCostDto printingCostDto = PrintingCostDto.builder().bob("PT3696").build();
        when(printingCostReportService.savePostageCostReport(printingCostDto)).thenReturn(true);

        // Call the method and verify
        printingCostReportController.savePostageCostReport(printingCostDto);
        verify(printingCostReportService, times(1)).savePostageCostReport(printingCostDto);
    }

    @Test
    void testSavePostageCostReportSuccess() {
        // Mock data
        PrintingCostDto printingCostDto = PrintingCostDto.builder().bob("PT3696").build();
        when(printingCostReportService.savePostageCostReport(printingCostDto)).thenReturn(true);

        // Call the method and verify
        ResponseEntity<String> response = printingCostReportController.savePostageCostReport(printingCostDto);
        assertEquals("Success", response.getBody());
        assertEquals(200, response.getStatusCodeValue());
        verify(printingCostReportService, times(1)).savePostageCostReport(printingCostDto);
    }

    @Test
    void testSavePostageCostReportFailure() {
        // Mock data
        PrintingCostDto printingCostDto = PrintingCostDto.builder().bob("PT3696").build();
        when(printingCostReportService.savePostageCostReport(printingCostDto)).thenReturn(false);

        // Call the method and verify
        ResponseEntity<String> response = printingCostReportController.savePostageCostReport(printingCostDto);
        assertEquals("Failed", response.getBody());
        assertEquals(400, response.getStatusCodeValue());
        verify(printingCostReportService, times(1)).savePostageCostReport(printingCostDto);
    }

    @Test
    void testCheckExistingDataFound() {
        // Mock data
        PrintingCostDto printingCostDto = PrintingCostDto.builder().bob("PT3696").build();
        when(printingCostReportService.getByTrailBOBAndMonth(anyString(), anyString(), anyString())).thenReturn(printingCostDto);

        // Call the method and verify
        ResponseEntity<PrintingCostDto> response = printingCostReportController.checkExistingData("trailName", "bob", "month");
        assertEquals(printingCostDto, response.getBody());
        assertEquals(200, response.getStatusCodeValue());
        verify(printingCostReportService, times(1)).getByTrailBOBAndMonth("trailName", "bob", "month");
    }

    @Test
    void testCheckExistingDataNotFound() {
        // Mock data
        when(printingCostReportService.getByTrailBOBAndMonth(anyString(), anyString(), anyString())).thenReturn(null);

        // Call the method and verify
        ResponseEntity<PrintingCostDto> response = printingCostReportController.checkExistingData("trailName", "bob", "month");
        assertEquals(400, response.getStatusCodeValue());
        verify(printingCostReportService, times(1)).getByTrailBOBAndMonth("trailName", "bob", "month");
    }
}
