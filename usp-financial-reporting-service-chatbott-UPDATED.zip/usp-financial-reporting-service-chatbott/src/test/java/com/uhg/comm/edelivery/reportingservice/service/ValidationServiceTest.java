package com.uhg.comm.edelivery.reportingservice.service;

import com.uhg.comm.edelivery.reportingservice.dto.PrintingCostDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class ValidationServiceTest {

    @InjectMocks
    private ValidationService validationService;

    // Add test cases here

    @Test
    void validateTest() {
        // Add test code here
        PrintingCostDto printingCostDto = PrintingCostDto.builder().build();
        printingCostDto.setTrailName("Trail Name");
        printingCostDto.setBob("BOB");
        LocalDate now = LocalDate.now();
        String monthName = now.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
        int year = now.getYear();

        String monthYear = monthName + " " + year;
        printingCostDto.setMonth("monthYear");
        printingCostDto.setPostageCost(1.0);
        printingCostDto.setPrintExpenseCost(1.0);
        printingCostDto.setPaperCount(1.0);
        printingCostDto.setImageCount(1.0);
        printingCostDto.setEnvelopCount(1.0);
        assertNotNull( ValidationService.validate(printingCostDto));
    }

    @Test
    void validateTrailBlankTest() {
        // Add test code here
        PrintingCostDto printingCostDto = PrintingCostDto.builder().build();
//        printingCostDto.setTrailName("Trail Name");
//        printingCostDto.setBob("BOB");
        printingCostDto.setMonth("");
        printingCostDto.setPostageCost(-1.0);
        printingCostDto.setPrintExpenseCost(-1.0);
        printingCostDto.setPaperCount(-1.0);
        printingCostDto.setImageCount(-1.0);
        printingCostDto.setEnvelopCount(-1.0);
        assertNotNull( ValidationService.validate(printingCostDto));
    }
}
