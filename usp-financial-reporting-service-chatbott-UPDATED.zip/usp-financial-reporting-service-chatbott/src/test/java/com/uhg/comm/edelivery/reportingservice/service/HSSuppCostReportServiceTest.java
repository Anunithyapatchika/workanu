package com.uhg.comm.edelivery.reportingservice.service;

import com.uhg.comm.edelivery.reportingservice.constants.Constants;
import com.uhg.comm.edelivery.reportingservice.dto.EHSFinancialReportResponseDto;
import com.uhg.comm.edelivery.reportingservice.dto.HsSuppCostDto;
import com.uhg.comm.edelivery.reportingservice.dto.HsSuppCostItemsDto;
import com.uhg.comm.edelivery.reportingservice.model.HSSuppCostReport;
import com.uhg.comm.edelivery.reportingservice.model.PrintingCostReport;
import com.uhg.comm.edelivery.reportingservice.repository.HSSuppCostReportRepository;
import com.uhg.comm.edelivery.reportingservice.util.DateUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class HSSuppCostReportServiceTest {

    @InjectMocks
    private HSSuppCostReportService hsSuppCostReportService;

    @Mock
    private HSSuppCostReportRepository hsSuppCostReportRepository;

    private HSSuppCostReport createHSSuppCostReport(String trailName, String bob, String month, LocalDate monthYear) {
        HSSuppCostReport report = new HSSuppCostReport();
        report.setTrailName(trailName);
        report.setBob(bob);
        report.setMonth(month);
        report.setMonthYear(monthYear);
        report.setPostageCost(100.0);
        report.setPrintingCost(50.0);
        report.setStatementPrinted(1000);
        report.setMemberElectionHSSupp(200);
        report.setPolicySettingHSSupp(50);
        report.setTotalStmtSuppressed(250);
        report.setTotalStmtGenerated(1250);
        report.setTotalPrintPostageCost(150.0);
        report.setHsSuppressPercent(20.0);
        report.setCostPerStmt(0.15);
        report.setTotalSheets(2000);
        report.setSheetsPerPrintedStmt(2.0);
        report.setTotalClaims(5000);
        report.setIsCompleted(1);
        return report;
    }

    @Test
    void getHSSuppCostReport_SingleMonth() {
        // Arrange
        String trailNumber = "TR12345";
        String startDate = "June 2022";
        String endDate = "June 2022";

        List<HSSuppCostReport> hsSuppCostReports = new ArrayList<>();
        HSSuppCostReport report1 = createHSSuppCostReport(trailNumber, "BOB1", "June 2022", LocalDate.of(2022, 6, 1));
        HSSuppCostReport report2 = createHSSuppCostReport(trailNumber, "BOB2", "June 2022", LocalDate.of(2022, 6, 1));
        hsSuppCostReports.add(report1);
        hsSuppCostReports.add(report2);

        when(hsSuppCostReportRepository.findByTrailNumberAndBetweenMonthYearStr(anyString(), any(LocalDate.class), any(LocalDate.class)))
                .thenReturn(hsSuppCostReports);

        EHSFinancialReportResponseDto result = hsSuppCostReportService.getHSSuppCostReport(trailNumber, startDate, endDate);

        // Assert
        assertNotNull(result);
        HsSuppCostDto dto = result.getHsSuppCostReport().get(0);
        assertEquals("June 2022", dto.getDate());
        assertEquals(trailNumber, dto.getTrailName());
        assertEquals(3, dto.getItems().size()); // 2 BOBs + 1 Monthly Total

        // Verify BOB items
        List<HsSuppCostItemsDto> bobItems = dto.getItems().stream()
                .filter(item -> !"MONTHLY TOTAL".equals(item.getBob()))
                .collect(Collectors.toList());

        // Verify Monthly Total
        Optional<HsSuppCostItemsDto> monthlyTotalOpt = dto.getItems().stream()
                .filter(item -> "MONTHLY TOTAL".equals(item.getBob()))
                .findFirst();

    }

    @Test
    void getHSSuppCostReport_MultipleMonths() {
        // Arrange
        String trailNumber = "TR12345";
        String startDate = "June 2022";
        String endDate = "July 2022";

        List<HSSuppCostReport> hsSuppCostReports = new ArrayList<>();
        // June reports
        HSSuppCostReport juneReport1 = createHSSuppCostReport(trailNumber, "BOB1", "June 2022", LocalDate.of(2022, 6, 1));
        HSSuppCostReport juneReport2 = createHSSuppCostReport(trailNumber, "BOB2", "June 2022", LocalDate.of(2022, 6, 1));
        // July reports
        HSSuppCostReport julyReport1 = createHSSuppCostReport(trailNumber, "BOB1", "July 2022", LocalDate.of(2022, 7, 1));
        julyReport1.setPostageCost(150.0); // Different values for July
        julyReport1.setPrintingCost(75.0);
        HSSuppCostReport julyReport2 = createHSSuppCostReport(trailNumber, "BOB2", "July 2022", LocalDate.of(2022, 7, 1));
        julyReport2.setPostageCost(125.0);
        julyReport2.setPrintingCost(60.0);

        hsSuppCostReports.add(juneReport1);
        hsSuppCostReports.add(juneReport2);
        hsSuppCostReports.add(julyReport1);
        hsSuppCostReports.add(julyReport2);

        when(hsSuppCostReportRepository.findByTrailNumberAndBetweenMonthYearStr(anyString(), any(LocalDate.class), any(LocalDate.class)))
                .thenReturn(hsSuppCostReports);
        EHSFinancialReportResponseDto result = hsSuppCostReportService.getHSSuppCostReport(trailNumber, startDate, endDate);

        // Assert
        assertNotNull(result);
        assertEquals(3, result.getHsSuppCostReport().size()); // June + July + Period Total

        // Verify June data
        HsSuppCostDto juneDto = result.getHsSuppCostReport().get(0);
        assertEquals("June 2022", juneDto.getDate());
        assertEquals(3, juneDto.getItems().size()); // 2 BOBs + Monthly Total

        // Verify July data
        HsSuppCostDto julyDto = result.getHsSuppCostReport().get(1);
        assertEquals("July 2022", julyDto.getDate());
        assertEquals(3, julyDto.getItems().size()); // 2 BOBs + Monthly Total

        // Verify Period Total
        HsSuppCostDto periodTotalDto = result.getHsSuppCostReport().get(2);
        assertEquals(Constants.PERIOD_TOTAL, periodTotalDto.getDate());
        assertEquals(3, periodTotalDto.getItems().size()); // 2 BOBs + Total

        // Check Period Total calculations
        Optional<HsSuppCostItemsDto> totalOpt = periodTotalDto.getItems().stream()
                .filter(item -> Constants.TOTAL.equals(item.getBob()))
                .findFirst();
        assertTrue(totalOpt.isPresent());
        HsSuppCostItemsDto total = totalOpt.get();
        assertEquals(475.0, total.getPostageCost()); // Sum of all postage costs
        assertEquals(235.0, total.getPrintCost()); // Sum of all print costs

        verify(hsSuppCostReportRepository).findByTrailNumberAndBetweenMonthYearStr(
                eq(trailNumber),
                eq(LocalDate.of(2022, 6, 1)),
                eq(LocalDate.of(2022, 7, 31)));
    }

    @Test
    void getHSSuppCostReport_EmptyResult() {
        // Arrange
        String trailNumber = "TR12345";
        String startDate = "June 2022";
        String endDate = "July 2022";

        when(hsSuppCostReportRepository.findByTrailNumberAndBetweenMonthYearStr(anyString(), any(LocalDate.class), any(LocalDate.class)))
                .thenReturn(Collections.emptyList());
        EHSFinancialReportResponseDto result = hsSuppCostReportService.getHSSuppCostReport(trailNumber, startDate, endDate);

        // Assert
        assertNotNull(result);
        assertTrue(result.getHsSuppCostReport().isEmpty());

        verify(hsSuppCostReportRepository).findByTrailNumberAndBetweenMonthYearStr(
                eq(trailNumber),
                eq(LocalDate.of(2022, 6, 1)),
                eq(LocalDate.of(2022, 7, 31)));
    }

    @Test
    void saveHsSuppDataFromPrintCostReport_NewRecord() {
        // Arrange
        String trailName = "TR12345";
        String month = "June 2022";
        String bob = "BOB1";

        PrintingCostReport printingCostReport = new PrintingCostReport();
        printingCostReport.setTrailName(trailName);
        printingCostReport.setMonth(month);
        printingCostReport.setBob(bob);
        printingCostReport.setPostageCost(100.0);
        printingCostReport.setPrintExpenseCost(50.0);
        printingCostReport.setPaperCount(2000);

        when(hsSuppCostReportRepository.findByTrailNameBobAndMonth(trailName, bob, month))
                .thenReturn(Optional.empty());

        ArgumentCaptor<HSSuppCostReport> reportCaptor = ArgumentCaptor.forClass(HSSuppCostReport.class);
        when(hsSuppCostReportRepository.save(reportCaptor.capture())).thenReturn(new HSSuppCostReport());

        // Act
        hsSuppCostReportService.saveHsSuppDataFromPrintCostReport(printingCostReport);

        // Assert
        verify(hsSuppCostReportRepository).findByTrailNameBobAndMonth(trailName, bob, month);
        verify(hsSuppCostReportRepository).save(any(HSSuppCostReport.class));

        HSSuppCostReport savedReport = reportCaptor.getValue();
        assertEquals(trailName, savedReport.getTrailName());
        assertEquals(month, savedReport.getMonth());
        assertEquals(bob, savedReport.getBob());
        assertEquals(100.0, savedReport.getPostageCost());
        assertEquals(50.0, savedReport.getPrintingCost());
        assertEquals(2000, savedReport.getTotalSheets());
        assertEquals(0, savedReport.getIsCompleted());
    }

    @Test
    void saveHsSuppDataFromPrintCostReport_UpdateExistingCompletedRecord() {
        // Arrange
        String trailName = "TR12345";
        String month = "June 2022";
        String bob = "BOB1";

        PrintingCostReport printingCostReport = new PrintingCostReport();
        printingCostReport.setTrailName(trailName);
        printingCostReport.setMonth(month);
        printingCostReport.setBob(bob);
        printingCostReport.setPostageCost(120.0);
        printingCostReport.setPrintExpenseCost(60.0);
        printingCostReport.setPaperCount(2200);

        HSSuppCostReport existingReport = new HSSuppCostReport();
        existingReport.setTrailName(trailName);
        existingReport.setMonth(month);
        existingReport.setBob(bob);
        existingReport.setPostageCost(100.0);
        existingReport.setPrintingCost(50.0);
        existingReport.setTotalSheets(2000);
        existingReport.setStatementPrinted(1000);
        existingReport.setTotalStmtSuppressed(250);
        existingReport.setIsCompleted(1);

        when(hsSuppCostReportRepository.findByTrailNameBobAndMonth(trailName, bob, month))
                .thenReturn(Optional.of(existingReport));

        ArgumentCaptor<HSSuppCostReport> reportCaptor = ArgumentCaptor.forClass(HSSuppCostReport.class);
        when(hsSuppCostReportRepository.save(reportCaptor.capture())).thenReturn(existingReport);

        // Act
        hsSuppCostReportService.saveHsSuppDataFromPrintCostReport(printingCostReport);

        // Assert
        verify(hsSuppCostReportRepository).findByTrailNameBobAndMonth(trailName, bob, month);
        verify(hsSuppCostReportRepository).save(any(HSSuppCostReport.class));

        HSSuppCostReport savedReport = reportCaptor.getValue();
        assertEquals(trailName, savedReport.getTrailName());
        assertEquals(120.0, savedReport.getPostageCost());
        assertEquals(60.0, savedReport.getPrintingCost());
        assertEquals(2200, savedReport.getTotalSheets());
        assertEquals(180.0, savedReport.getTotalPrintPostageCost());
        assertEquals(1, savedReport.getIsCompleted());
        assertEquals(0.18, savedReport.getCostPerStmt()); // 180.0 / 1000
    }

    @Test
    void saveHsSuppDataFromPrintCostReport_UpdateExistingIncompleteRecord() {
        // Arrange
        String trailName = "TR12345";
        String month = "June 2022";
        String bob = "BOB1";

        PrintingCostReport printingCostReport = new PrintingCostReport();
        printingCostReport.setTrailName(trailName);
        printingCostReport.setMonth(month);
        printingCostReport.setBob(bob);
        printingCostReport.setPostageCost(120.0);
        printingCostReport.setPrintExpenseCost(60.0);
        printingCostReport.setPaperCount(2200);

        HSSuppCostReport existingReport = new HSSuppCostReport();
        existingReport.setTrailName(trailName);
        existingReport.setMonth(month);
        existingReport.setBob(bob);
        existingReport.setPostageCost(100.0);
        existingReport.setPrintingCost(50.0);
        existingReport.setTotalSheets(2000);
        existingReport.setStatementPrinted(0); // Zero statements printed
        existingReport.setTotalStmtSuppressed(0); // Zero statements suppressed
        existingReport.setIsCompleted(0);

        when(hsSuppCostReportRepository.findByTrailNameBobAndMonth(trailName, bob, month))
                .thenReturn(Optional.of(existingReport));

        ArgumentCaptor<HSSuppCostReport> reportCaptor = ArgumentCaptor.forClass(HSSuppCostReport.class);
        when(hsSuppCostReportRepository.save(reportCaptor.capture())).thenReturn(existingReport);

        // Act
        hsSuppCostReportService.saveHsSuppDataFromPrintCostReport(printingCostReport);

        // Assert
        verify(hsSuppCostReportRepository).findByTrailNameBobAndMonth(trailName, bob, month);
        verify(hsSuppCostReportRepository).save(any(HSSuppCostReport.class));

        HSSuppCostReport savedReport = reportCaptor.getValue();
        assertEquals(trailName, savedReport.getTrailName());
        assertEquals(120.0, savedReport.getPostageCost());
        assertEquals(60.0, savedReport.getPrintingCost());
        assertEquals(2200, savedReport.getTotalSheets());
        assertEquals(180.0, savedReport.getTotalPrintPostageCost());
        assertEquals(0, savedReport.getIsCompleted()); // Still incomplete
    }

    @Test
    void getHSSuppCostReport_InvalidDateFormat() {
        // Arrange
        String trailNumber = "TR12345";
        String startDate = "Invalid Date";
        String endDate = "June 2022";

        // Act & Assert
        assertThrows(Exception.class, () ->
            hsSuppCostReportService.getHSSuppCostReport(trailNumber, startDate, endDate)
        );

        verify(hsSuppCostReportRepository, never()).findByTrailNumberAndBetweenMonthYearStr(any(), any(), any());
    }

    @Test
    void getHSSuppCostReport_WithSpecialCharacters() {
        // Arrange
        String trailNumber = "TR-12345_TEST";
        String startDate = "June 2022";
        String endDate = "June 2022";

        List<HSSuppCostReport> hsSuppCostReports = new ArrayList<>();
        HSSuppCostReport report = createHSSuppCostReport(trailNumber, "BOB-1", "June 2022", LocalDate.of(2022, 6, 1));
        hsSuppCostReports.add(report);

        when(hsSuppCostReportRepository.findByTrailNumberAndBetweenMonthYearStr(anyString(), any(LocalDate.class), any(LocalDate.class)))
                .thenReturn(hsSuppCostReports);
        EHSFinancialReportResponseDto result = hsSuppCostReportService.getHSSuppCostReport(trailNumber, startDate, endDate);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.getHsSuppCostReport().size());
        assertEquals(trailNumber, result.getHsSuppCostReport().get(0).getTrailName());
    }
}
