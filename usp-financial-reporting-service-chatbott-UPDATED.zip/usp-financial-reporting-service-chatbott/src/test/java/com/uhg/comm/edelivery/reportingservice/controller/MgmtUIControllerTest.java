package com.uhg.comm.edelivery.reportingservice.controller;

import com.uhg.comm.edelivery.reportingservice.service.MgmtUIService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
class MgmtUIControllerTest {

    @InjectMocks
    private MgmtUIController mgmtUIController;

    @Mock
    private MgmtUIService mgmtUIService;

    @Test
    void testDownLoadFile_Success() {
        // Arrange
        String fileName = "testFile.pdf";
        String inputFilePath = "testInputFilePath";
        Resource mockResource = new ByteArrayResource("Dummy content".getBytes());
        ResponseEntity<Resource> mockResponse = new ResponseEntity<>(mockResource, HttpStatus.OK);

        when(mgmtUIService.downloadPdf(fileName, inputFilePath)).thenReturn(mockResponse);

        // Act
        ResponseEntity<Resource> response = mgmtUIController.downLoadFile(fileName, inputFilePath);

        // Assert
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(mockResource, response.getBody());
    }

    @Test
    void testDownLoadFile_Failure() {
        // Arrange
        String fileName = "testFile.pdf";
        String inputFilePath = "testInputFilePath";

        when(mgmtUIService.downloadPdf(fileName, inputFilePath)).thenReturn(
                new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR)
        );

        // Act
        ResponseEntity<Resource> response = mgmtUIController.downLoadFile(fileName, inputFilePath);

        // Assert
        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNull(response.getBody());
    }

    @Test
    void testDownloadZips_Success() {
        // Arrange
        String fileName = "testFile.zip";
        String inputFilePath = "testInputFilePath";
        Resource mockResource = new ByteArrayResource("Dummy content".getBytes());
        ResponseEntity<Resource> mockResponse = new ResponseEntity<>(mockResource, HttpStatus.OK);

        when(mgmtUIService.downloadzips(fileName, inputFilePath)).thenReturn(mockResponse);

        // Act
        ResponseEntity<Resource> response = mgmtUIController.downloadZips(fileName, inputFilePath);

        // Assert
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(mockResource, response.getBody());
    }

    @Test
    void testDownloadZips_Failure() {
        // Arrange
        String fileName = "testFile.zip";
        String inputFilePath = "testInputFilePath";

        when(mgmtUIService.downloadzips(fileName, inputFilePath)).thenReturn(
                new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR)
        );

        // Act
        ResponseEntity<Resource> response = mgmtUIController.downloadZips(fileName, inputFilePath);

        // Assert
        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNull(response.getBody());
    }
}