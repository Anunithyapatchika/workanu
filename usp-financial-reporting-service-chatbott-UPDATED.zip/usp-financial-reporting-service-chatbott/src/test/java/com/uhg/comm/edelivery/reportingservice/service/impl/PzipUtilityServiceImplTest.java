package com.uhg.comm.edelivery.reportingservice.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uhg.comm.edelivery.reportingservice.auth.OauthTokenUtil;
import com.uhg.comm.edelivery.reportingservice.bean.*;
import com.uhg.comm.edelivery.reportingservice.util.BlobUtils;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PzipUtilityServiceImplTest {

    @InjectMocks
    private PzipUtilityServiceImpl pzipUtilityServiceImpl;

    @Mock
    private OauthTokenUtil oauthTokenUtil;

    @Mock
    private WebClient webClient;

    @Mock
    private BlobUtils blobUtils;

    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Mock
    private WebClient.ResponseSpec responseSpecBodySpec;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(pzipUtilityServiceImpl, "orxOnDemandUrl", "http://test-ondemand-url");
        ReflectionTestUtils.setField(pzipUtilityServiceImpl, "orxBatchApiUri", "http://test-batch-api-url");
        ReflectionTestUtils.setField(pzipUtilityServiceImpl, "orxBatchDeliveryApiUri", "http://test-batch-delivery-url");
        ReflectionTestUtils.setField(pzipUtilityServiceImpl, "objectMapper", objectMapper);
    }

    @Test
    void callOnDemandApi_Success() throws JsonProcessingException {
        // Arrange
        String token = "test-token";
        String jobId = "job123";
        String suppressIndicator = "N";
        String trailType = "TEST";
        String tnoId = "tno123";

        OnDemandApiRequest request = OnDemandApiRequest.builder().build();

        OnDemandOptumRxAPIResponse apiResponse = new OnDemandOptumRxAPIResponse();
        apiResponse.setStatus("SUCCESS");
        apiResponse.setMessage("ACCEPTED");

        String responseBody = objectMapper.writeValueAsString(apiResponse);
        ResponseEntity<String> responseEntity = ResponseEntity.ok(responseBody);

        // Mock chain
        when(oauthTokenUtil.callSecurityToken()).thenReturn(token);
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.header(anyString(), anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(Mono.class), eq(OnDemandApiRequest.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(String.class)).thenReturn(Mono.just(responseEntity));

        // Act
        ApiResponse result = pzipUtilityServiceImpl.callOnDemandApi(request, jobId, suppressIndicator, trailType, tnoId);

        // Assert
        assertTrue(result.isResult());
        assertEquals("Ondemand called successfully", result.getMessage());
        verify(oauthTokenUtil).callSecurityToken();
    }

    @Test
    void callOnDemandApi_TokenFailure() {
        // Arrange
        when(oauthTokenUtil.callSecurityToken()).thenReturn(null);
        OnDemandApiRequest request = OnDemandApiRequest.builder().build();

        // Act
        ApiResponse result = pzipUtilityServiceImpl.callOnDemandApi(OnDemandApiRequest.builder().build() , "jobId", "N", "TEST", "tnoId");

        // Assert
        assertFalse(result.isResult());
        assertEquals("Failed to retrieve token", result.getMessage());
        verify(oauthTokenUtil).callSecurityToken();
        verifyNoInteractions(webClient);
    }

    @Test
    void callOnDemandApi_DuplicateError() throws JsonProcessingException {
        // Arrange
        String token = "test-token";

        OnDemandOptumRxAPIResponse apiResponse = new OnDemandOptumRxAPIResponse();
        apiResponse.setStatus("FAILED");
        apiResponse.setMessage("DUPLICATE job request");

        String responseBody = objectMapper.writeValueAsString(apiResponse);
        ResponseEntity<String> responseEntity = ResponseEntity.ok(responseBody);

        // Mock chain
        when(oauthTokenUtil.callSecurityToken()).thenReturn(token);
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.header(anyString(), anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(Mono.class), eq(OnDemandApiRequest.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(String.class)).thenReturn(Mono.just(responseEntity));

        // Act
        assertDoesNotThrow(()->pzipUtilityServiceImpl.callOnDemandApi(OnDemandApiRequest.builder().build(), "jobId", "N", "TEST", "tnoId"));

        // Assert
    }

    @Test
    void callOnDemandApi_Exception() {
        // Arrange
        String token = "test-token";

        when(oauthTokenUtil.callSecurityToken()).thenReturn(token);
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.header(anyString(), anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(Mono.class), eq(OnDemandApiRequest.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(String.class)).thenThrow(new RuntimeException("API error"));

        // Act
        ApiResponse result = pzipUtilityServiceImpl.callOnDemandApi(OnDemandApiRequest.builder().build(), "jobId", "N", "TEST", "tnoId");

        // Assert
        assertFalse(result.isResult());
        assertEquals("API error", result.getMessage());
    }

    @Test
    void callBatchConsolidationApi_Success() throws JsonProcessingException {
        // Arrange
        String token = "test-token";
        String jobId = "job123";
        String trailType = "TEST";
        String tnoId = "tno123";

        BatchFile batchFile = new BatchFile();

        BatchApiResponse apiResponse = new BatchApiResponse();
        apiResponse.setStatus("SUCCESS");

        String responseBody = objectMapper.writeValueAsString(apiResponse);
        ResponseEntity<String> responseEntity = ResponseEntity.ok(responseBody);

        // Mock chain
        when(oauthTokenUtil.callSecurityToken()).thenReturn(token);
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.header(anyString(), anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(Mono.class), eq(BatchFile.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(String.class)).thenReturn(Mono.just(responseEntity));

        // Act
        ApiResponse result = pzipUtilityServiceImpl.callBatchConsolidationApi(jobId, batchFile, trailType, tnoId);

        // Assert
        assertTrue(result.isResult());
        assertEquals("Batch Consolidation API call was successful", result.getMessage());
    }

    @Test
    void callBatchConsolidationApi_TokenFailure() {
        // Arrange
        when(oauthTokenUtil.callSecurityToken()).thenReturn(null);

        // Act
        ApiResponse result = pzipUtilityServiceImpl.callBatchConsolidationApi("jobId", new BatchFile(), "TEST", "tnoId");

        // Assert
        assertFalse(result.isResult());
        assertEquals("Failed to retrieve token", result.getMessage());
    }

    @Test
    void callBatchConsolidationApi_Exception() {
        // Arrange
        String token = "test-token";

        when(oauthTokenUtil.callSecurityToken()).thenReturn(token);
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.header(anyString(), anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(Mono.class), eq(BatchFile.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenThrow(new RuntimeException("API error"));

        // Act
        ApiResponse result = pzipUtilityServiceImpl.callBatchConsolidationApi("jobId", new BatchFile(), "TEST", "tnoId");

        // Assert
        assertFalse(result.isResult());
        assertEquals("API error", result.getMessage());
    }

    @Test
    void callBatchDeliveryApi_Success() throws JsonProcessingException {
        // Arrange
        String token = "test-token";
        String jobId = "job123";
        String trailType = "TEST";
        String inputFileName = "test-file.txt";

        BatchDeliveryRequest request = BatchDeliveryRequest.builder().build();

        BatchApiResponse apiResponse = new BatchApiResponse();
        apiResponse.setStatus("SUCCESS");

        String responseBody = objectMapper.writeValueAsString(apiResponse);
        ResponseEntity<String> responseEntity = ResponseEntity.ok(responseBody);

        // Mock chain
        when(oauthTokenUtil.callSecurityToken()).thenReturn(token);
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.header(anyString(), anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(Mono.class), eq(BatchDeliveryRequest.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(String.class)).thenReturn(Mono.just(responseEntity));

        // Act
        ApiResponse result = pzipUtilityServiceImpl.callBatchDeliveryApi(jobId, trailType, inputFileName, request);

        // Assert
        assertTrue(result.isResult());
        assertEquals("Batch Delivery API call was successful", result.getMessage());
    }

    @Test
    void callBatchDeliveryApi_TokenFailure() {
        // Arrange
        when(oauthTokenUtil.callSecurityToken()).thenReturn(null);

        // Act
        ApiResponse result = pzipUtilityServiceImpl.callBatchDeliveryApi("jobId", "TEST", "file.txt", BatchDeliveryRequest.builder().build());

        // Assert
        assertFalse(result.isResult());
        assertEquals("Failed to retrieve token", result.getMessage());
    }

    @Test
    void callBatchDeliveryApi_Exception() {
        // Arrange
        String token = "test-token";

        when(oauthTokenUtil.callSecurityToken()).thenReturn(token);
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.header(anyString(), anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(Mono.class), eq(BatchDeliveryRequest.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenThrow(new RuntimeException("API error"));

        // Act
        ApiResponse result = pzipUtilityServiceImpl.callBatchDeliveryApi("jobId", "TEST", "file.txt", BatchDeliveryRequest.builder().build());

        // Assert
        assertEquals("API error", result.getMessage());
    }

    @Test
    void getListOfFilesFromBlob_Success() {
        // Arrange
        String inputFileName = "test-file.txt";
        List<String> expectedFiles = List.of("file1.txt", "file2.txt");

        when(blobUtils.getBlobItemsList(inputFileName)).thenReturn(expectedFiles);

        // Act
        List<String> result = pzipUtilityServiceImpl.getListOfFilesFromBlob(inputFileName);

        // Assert
        assertEquals(expectedFiles, result);
        verify(blobUtils).getBlobItemsList(inputFileName);
    }

    @Test
    void getListOfFilesFromBlob_Exception() {
        // Arrange
        String inputFileName = "test-file.txt";
        RuntimeException expectedException = new RuntimeException("Blob error");

        when(blobUtils.getBlobItemsList(inputFileName)).thenThrow(expectedException);

        // Act & Assert
        Exception exception = assertThrows(RuntimeException.class, () ->
            pzipUtilityServiceImpl.getListOfFilesFromBlob(inputFileName)
        );

        assertEquals("Blob error", exception.getMessage());
        verify(blobUtils).getBlobItemsList(inputFileName);
    }
}
