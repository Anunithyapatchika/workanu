package com.uhg.comm.edelivery.reportingservice.repository;

import com.uhg.comm.edelivery.processLog.Processlog;
import com.uhg.comm.edelivery.reportingservice.model.USPFinancialReport;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class USP3231DataRepositoryTest {

    @InjectMocks
    private USP3231DataRepository usp3231DataRepository;

    @Mock
    private JdbcTemplate jdbcTemplate;

    @Mock
    private Processlog processlog;

    @Test
    void testGetUSP3231Data_Success() {
        // Mock data
        String dateFilter = "BETWEEN '2023-01-01' AND '2023-01-31'";
        USPFinancialReport mockReport = new USPFinancialReport();
        mockReport.setId(1);
        mockReport.setBob("Bob1");
        mockReport.setTotalEobGenerated(100);
        mockReport.setCreatedDate(LocalDate.of(2023, 1, 1).atStartOfDay());
        List<USPFinancialReport> mockReports = List.of(mockReport);

        when(jdbcTemplate.query(anyString(),  any((RowMapper.class)))).thenReturn(mockReports);

        // Call the method
        List<USPFinancialReport> result = usp3231DataRepository.getUSP3231Data(dateFilter, processlog);

        // Assert the result
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Bob1", result.get(0).getBob());
        assertEquals(100, result.get(0).getTotalEobGenerated());
    }

    @Test
    void testGetUSP3231Data_Exception() {
        // Mock data
        String dateFilter = "BETWEEN '2023-01-01' AND '2023-01-31'";
        when(jdbcTemplate.query(anyString(),any((RowMapper.class)))).thenThrow(new RuntimeException("Database error"));

        // Call the method and assert exception
        Exception exception = assertThrows(RuntimeException.class, () -> {
            usp3231DataRepository.getUSP3231Data(dateFilter, processlog);
        });

        assertEquals("Database error", exception.getMessage());
        verify(processlog, times(1)).setErrorMessage("Error while fetching USP3231 data from database");
    }

    private USP3231DataRepository.USPFinancialReportRowMapper rowMapper;
    private ResultSet resultSet;

    @BeforeEach
    void setUp() {
        rowMapper = new USP3231DataRepository.USPFinancialReportRowMapper();
        resultSet = mock(ResultSet.class);
    }

    @Test
    void testMapRow_Success() throws SQLException {
        // Mock ResultSet data
        when(resultSet.getInt("id")).thenReturn(1);
        when(resultSet.getString("bob")).thenReturn("Business1");
        when(resultSet.getInt("total")).thenReturn(100);
        when(resultSet.getInt("suppr")).thenReturn(50);
        when(resultSet.getInt("mem_supp")).thenReturn(20);
        when(resultSet.getInt("policy_supp")).thenReturn(10);
        when(resultSet.getInt("print_supp")).thenReturn(30);
        when(resultSet.getInt("hs_total")).thenReturn(40);
        when(resultSet.getInt("hs_suppr")).thenReturn(15);
        when(resultSet.getInt("hs_mem_supp")).thenReturn(5);
        when(resultSet.getInt("hs_policy_supp")).thenReturn(10);
        when(resultSet.getInt("hs_print_supp")).thenReturn(20);
        when(resultSet.getInt("cae_total")).thenReturn(25);
        when(resultSet.getInt("cae_email")).thenReturn(10);
        when(resultSet.getInt("cae_no_email")).thenReturn(15);
        when(resultSet.getObject("hs_mem_print")).thenReturn(1);
        when(resultSet.getInt("hs_mem_print")).thenReturn(15);
        when(resultSet.getDate("created_date")).thenReturn(Date.valueOf(LocalDate.of(2023, 1, 1)));

        // Call the method
        USPFinancialReport result = rowMapper.mapRow(resultSet, 1);

        // Assert the result
        assertNotNull(result);
        assertEquals(1, result.getId());
        assertEquals("Business1", result.getBob());
        assertEquals(100, result.getTotalEobGenerated());
        assertEquals(50, result.getTotalEobSuppressed());
        assertEquals(20, result.getMemberElectionEob());
        assertEquals(10, result.getPolicySettingEob());
        assertEquals(30, result.getTotalEobPrinted());
        assertEquals(40, result.getTotalHsGenerated());
        assertEquals(15, result.getTotalHsSuppressed());
        assertEquals(5, result.getMemberElectionHs());
        assertEquals(10, result.getPolicySettingHs());
        assertEquals(20, result.getTotalHsPrinted());
        assertEquals(25, result.getTotalCaeEobCount());
        assertEquals(10, result.getCaeEobMailCount());
        assertEquals(15, result.getCaeEobNoEmailCount());
        assertEquals(LocalDate.of(2023, 1, 1).atStartOfDay(), result.getCreatedDate());
        assertEquals(LocalDate.of(2023, 1, 1), result.getMonthYear());
    }

    @Test
    void testMapRow_Exception() throws SQLException {
        // Mock ResultSet to throw SQLException
        when(resultSet.getInt(anyString())).thenThrow(new SQLException("Database error"));

        // Call the method and assert exception
        assertThrows(SQLException.class, () -> {
            rowMapper.mapRow(resultSet, 1);
        });
    }
}