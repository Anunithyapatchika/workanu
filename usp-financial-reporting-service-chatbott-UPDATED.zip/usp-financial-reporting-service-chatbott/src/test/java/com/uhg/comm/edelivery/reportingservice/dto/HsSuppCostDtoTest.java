package com.uhg.comm.edelivery.reportingservice.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class HsSuppCostDtoTest {

    @InjectMocks
    private HsSuppCostDto hsSuppCostDto;

    private HsSuppCostItemsDto createTestItem(String bob, double postageCost, double printCost) {
        HsSuppCostItemsDto item = new HsSuppCostItemsDto();
        item.setBob(bob);
        item.setPostageCost(postageCost);
        item.setPrintCost(printCost);
        item.setStmtPrinted(1000);
        item.setHsSuppMemberElection(200);
        item.setHsSuppPolicySetting(50);
        item.setTotalStmtSupp(250);
        item.setTotalStmtGenerated(1250);
        item.setTotalPrintPostCost(postageCost + printCost);
        item.setHsSuppressedPercent(20.0);
        item.setCostPerPrintedStmt(postageCost / 1000);
        item.setTotalSheets(2000);
        item.setSheetsPerPrintedStmt(2.0);
        item.setNumberOfClaims(5000);
        return item;
    }

    @Test
    void testGetDate() {
        hsSuppCostDto.setDate("date");
        assertEquals("date", hsSuppCostDto.getDate());
    }

    @Test
    void testGettrailName() {
        hsSuppCostDto.setTrailName("date");
        assertEquals("date", hsSuppCostDto.getTrailName());
    }

    @Test
    void testGetitems() {
        hsSuppCostDto.setItems(List.of(new HsSuppCostItemsDto()));
        assertEquals(List.of(new HsSuppCostItemsDto()), hsSuppCostDto.getItems());
    }

    @Test
    void testCompleteObjectConstruction() {
        // Arrange
        String date = "2023-07-31";
        String trailName = "TR12345";
        List<HsSuppCostItemsDto> items = new ArrayList<>();
        items.add(createTestItem("BOB123", 500.0, 300.0));
        items.add(createTestItem("BOB456", 600.0, 400.0));

        // Act
        hsSuppCostDto.setDate(date);
        hsSuppCostDto.setTrailName(trailName);
        hsSuppCostDto.setItems(items);

        // Assert
        assertEquals(date, hsSuppCostDto.getDate());
        assertEquals(trailName, hsSuppCostDto.getTrailName());
        assertEquals(2, hsSuppCostDto.getItems().size());
        assertEquals("BOB123", hsSuppCostDto.getItems().get(0).getBob());
        assertEquals(500.0, hsSuppCostDto.getItems().get(0).getPostageCost());
        assertEquals("BOB456", hsSuppCostDto.getItems().get(1).getBob());
        assertEquals(600.0, hsSuppCostDto.getItems().get(1).getPostageCost());
    }

    @Test
    void testEqualsAndHashCode() {
        // Arrange
        HsSuppCostDto dto1 = new HsSuppCostDto();
        dto1.setDate("2023-07-31");
        dto1.setTrailName("TR12345");

        HsSuppCostDto dto2 = new HsSuppCostDto();
        dto2.setDate("2023-07-31");
        dto2.setTrailName("TR12345");

        HsSuppCostDto dto3 = new HsSuppCostDto();
        dto3.setDate("2023-08-01");
        dto3.setTrailName("TR67890");

        // Act & Assert
        assertEquals(dto1, dto2);
        assertEquals(dto1.hashCode(), dto2.hashCode());

        assertNotEquals(dto1, dto3);
        assertNotEquals(dto1.hashCode(), dto3.hashCode());

        assertNotEquals(dto1, null);
        assertNotEquals(dto1, new Object());
    }

    @Test
    void testToString() {
        // Arrange
        hsSuppCostDto.setDate("2023-07-31");
        hsSuppCostDto.setTrailName("TR12345");

        // Act
        String result = hsSuppCostDto.toString();

        // Assert
        assertTrue(result.contains("date=2023-07-31"));
        assertTrue(result.contains("trailName=TR12345"));
    }

    @Test
    void testItemsListManipulation() {
        // Arrange
        List<HsSuppCostItemsDto> items = new ArrayList<>();

        // Act & Assert - Empty list
        hsSuppCostDto.setItems(items);
        assertEquals(0, hsSuppCostDto.getItems().size());

        // Act & Assert - Add items
        HsSuppCostItemsDto item1 = createTestItem("BOB123", 500.0, 300.0);
        HsSuppCostItemsDto item2 = createTestItem("BOB456", 600.0, 400.0);

        items.add(item1);
        items.add(item2);
        assertEquals(2, hsSuppCostDto.getItems().size());
        assertEquals("BOB123", hsSuppCostDto.getItems().get(0).getBob());
        assertEquals(500.0, hsSuppCostDto.getItems().get(0).getPostageCost());
        assertEquals("BOB456", hsSuppCostDto.getItems().get(1).getBob());
        assertEquals(600.0, hsSuppCostDto.getItems().get(1).getPostageCost());

        // Act & Assert - Replace list
        List<HsSuppCostItemsDto> newItems = new ArrayList<>();
        HsSuppCostItemsDto item3 = createTestItem("BOB789", 700.0, 500.0);
        newItems.add(item3);

        hsSuppCostDto.setItems(newItems);
        assertEquals(1, hsSuppCostDto.getItems().size());
        assertEquals("BOB789", hsSuppCostDto.getItems().get(0).getBob());
    }

    @Test
    void testNullValues() {
        // Arrange & Act - Default values
        HsSuppCostDto dto = new HsSuppCostDto();

        // Assert
        assertNull(dto.getDate());
        assertNull(dto.getTrailName());
        assertNull(dto.getItems());

        // Act & Assert - Set and unset
        dto.setDate("2023-07-31");
        dto.setTrailName("TR12345");
        List<HsSuppCostItemsDto> items = new ArrayList<>();
        dto.setItems(items);

        assertEquals("2023-07-31", dto.getDate());
        assertEquals("TR12345", dto.getTrailName());
        assertNotNull(dto.getItems());

        dto.setDate(null);
        dto.setTrailName(null);
        dto.setItems(null);

        assertNull(dto.getDate());
        assertNull(dto.getTrailName());
        assertNull(dto.getItems());
    }

    @Test
    void testItemsWithComplexValues() {
        // Arrange
        HsSuppCostDto dto = new HsSuppCostDto();
        List<HsSuppCostItemsDto> items = new ArrayList<>();

        HsSuppCostItemsDto item = new HsSuppCostItemsDto();
        item.setBob("BOB123");
        item.setPostageCost(500.0);
        item.setPrintCost(300.0);
        item.setStmtPrinted(1000);
        item.setHsSuppMemberElection(200);
        item.setHsSuppPolicySetting(50);
        item.setTotalStmtSupp(250);
        item.setTotalStmtGenerated(1250);
        item.setTotalPrintPostCost(800.0);
        item.setHsSuppressedPercent(20.0);
        item.setCostPerPrintedStmt(0.5);
        item.setTotalSheets(2000);
        item.setSheetsPerPrintedStmt(2.0);
        item.setNumberOfClaims(5000);

        items.add(item);
        dto.setItems(items);

        // Act & Assert
        HsSuppCostItemsDto retrievedItem = dto.getItems().get(0);
        assertEquals("BOB123", retrievedItem.getBob());
        assertEquals(500.0, retrievedItem.getPostageCost());
        assertEquals(300.0, retrievedItem.getPrintCost());
        assertEquals(1000, retrievedItem.getStmtPrinted());
        assertEquals(200, retrievedItem.getHsSuppMemberElection());
        assertEquals(50, retrievedItem.getHsSuppPolicySetting());
        assertEquals(250, retrievedItem.getTotalStmtSupp());
        assertEquals(1250, retrievedItem.getTotalStmtGenerated());
        assertEquals(800.0, retrievedItem.getTotalPrintPostCost());
        assertEquals(20.0, retrievedItem.getHsSuppressedPercent());
        assertEquals(0.5, retrievedItem.getCostPerPrintedStmt());
        assertEquals(2000, retrievedItem.getTotalSheets());
        assertEquals(2.0, retrievedItem.getSheetsPerPrintedStmt());
        assertEquals(5000, retrievedItem.getNumberOfClaims());
    }

    @Test
    void testWithEdgeCases() {
        // Arrange
        HsSuppCostDto dto = new HsSuppCostDto();

        // Act & Assert - Empty strings
        dto.setDate("");
        dto.setTrailName("");
        assertEquals("", dto.getDate());
        assertEquals("", dto.getTrailName());

        // Act & Assert - Special characters
        dto.setDate("2023/07-31 #@!");
        dto.setTrailName("TR-12345_TEST*");
        assertEquals("2023/07-31 #@!", dto.getDate());
        assertEquals("TR-12345_TEST*", dto.getTrailName());

        // Act & Assert - Zero values in items
        List<HsSuppCostItemsDto> items = new ArrayList<>();
        HsSuppCostItemsDto zeroItem = new HsSuppCostItemsDto();
        zeroItem.setBob("ZERO_TEST");
        zeroItem.setPostageCost(0);
        zeroItem.setPrintCost(0);
        zeroItem.setStmtPrinted(0);
        zeroItem.setHsSuppMemberElection(0);
        zeroItem.setHsSuppPolicySetting(0);
        zeroItem.setTotalStmtSupp(0);
        zeroItem.setTotalStmtGenerated(0);
        zeroItem.setTotalPrintPostCost(0);
        zeroItem.setHsSuppressedPercent(0);
        zeroItem.setCostPerPrintedStmt(0);
        zeroItem.setTotalSheets(0);
        zeroItem.setSheetsPerPrintedStmt(0);
        zeroItem.setNumberOfClaims(0);

        items.add(zeroItem);
        dto.setItems(items);

        HsSuppCostItemsDto retrievedZeroItem = dto.getItems().get(0);
        assertEquals("ZERO_TEST", retrievedZeroItem.getBob());
        assertEquals(0, retrievedZeroItem.getPostageCost());
        assertEquals(0, retrievedZeroItem.getPrintCost());
        assertEquals(0, retrievedZeroItem.getStmtPrinted());

        // Act & Assert - Negative values in items
        HsSuppCostItemsDto negativeItem = new HsSuppCostItemsDto();
        negativeItem.setBob("NEGATIVE_TEST");
        negativeItem.setPostageCost(-500.0);
        negativeItem.setPrintCost(-300.0);
        negativeItem.setStmtPrinted(-1000);
        negativeItem.setHsSuppMemberElection(-200);
        negativeItem.setHsSuppPolicySetting(-50);
        negativeItem.setTotalStmtSupp(-250);
        negativeItem.setTotalStmtGenerated(-1250);
        negativeItem.setTotalPrintPostCost(-800.0);
        negativeItem.setHsSuppressedPercent(-20.0);
        negativeItem.setCostPerPrintedStmt(-0.5);
        negativeItem.setTotalSheets(-2000);
        negativeItem.setSheetsPerPrintedStmt(-2.0);
        negativeItem.setNumberOfClaims(-5000);

        items.clear();
        items.add(negativeItem);
        dto.setItems(items);

        HsSuppCostItemsDto retrievedNegativeItem = dto.getItems().get(0);
        assertEquals("NEGATIVE_TEST", retrievedNegativeItem.getBob());
        assertEquals(-500.0, retrievedNegativeItem.getPostageCost());
        assertEquals(-300.0, retrievedNegativeItem.getPrintCost());
        assertEquals(-1000, retrievedNegativeItem.getStmtPrinted());
        assertEquals(-200, retrievedNegativeItem.getHsSuppMemberElection());
    }

    @Test
    void testBoundaryValues() {
        // Arrange
        HsSuppCostDto dto = new HsSuppCostDto();
        List<HsSuppCostItemsDto> items = new ArrayList<>();

        // Test with minimum and maximum double values
        HsSuppCostItemsDto extremeItem = new HsSuppCostItemsDto();
        extremeItem.setBob("EXTREME_TEST");
        extremeItem.setPostageCost(Double.MIN_VALUE);
        extremeItem.setPrintCost(Double.MAX_VALUE);

        items.add(extremeItem);
        dto.setItems(items);

        // Act & Assert
        assertEquals(Double.MIN_VALUE, dto.getItems().get(0).getPostageCost());
        assertEquals(Double.MAX_VALUE, dto.getItems().get(0).getPrintCost());

        // Test with infinity and NaN
        HsSuppCostItemsDto specialItem = new HsSuppCostItemsDto();
        specialItem.setBob("SPECIAL_TEST");
        specialItem.setPostageCost(Double.POSITIVE_INFINITY);
        specialItem.setPrintCost(Double.NaN);

        items.clear();
        items.add(specialItem);

        assertEquals(Double.POSITIVE_INFINITY, dto.getItems().get(0).getPostageCost());
        assertTrue(Double.isNaN(dto.getItems().get(0).getPrintCost()));
    }
}
