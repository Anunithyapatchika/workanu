package com.uhg.comm.edelivery.reportingservice.service.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.azure.core.util.BinaryData;
import com.azure.storage.blob.BlobClient;

import com.uhg.comm.edelivery.reportingservice.service.MgmtUIService;
import com.uhg.comm.edelivery.reportingservice.util.BlobUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class MgmtUIServiceTest {

    @InjectMocks
    private MgmtUIServiceImpl mgmtUIService;

    @Mock
    private BlobUtils blobUtils;

    @Mock
    private BlobClient blobClient;

    @Mock
    private BinaryData binaryData;


    private final String UCSFile = "ucsFile"; // Replace with actual value or inject if needed

    @Test
    void testDownloadPdf_WithUcsPath() {
        ReflectionTestUtils.setField(mgmtUIService, "ucsPath", "ucsFile");
        // Arrange
        String fileName = "ucsPath_sample.pdf";
        String inputFilePath = "some/ucsFile/";
         byte[] fileBytes = "PDF content".getBytes();


        when(blobUtils.getPdfBlobClient(inputFilePath + fileName, UCSFile)).thenReturn(blobClient);
        when(blobClient.downloadContent()).thenReturn(binaryData);
        when(binaryData.toBytes()).thenReturn(fileBytes);
        ResponseEntity<Resource> response = mgmtUIService.downloadPdf(fileName, inputFilePath);

        // Assert
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());

    }

    @Test
    void testDownloadPdf_WithORXPath() {
        ReflectionTestUtils.setField(mgmtUIService, "ucsPath", "ucsFile1");
        // Arrange
        String fileName = "ucsPath_sample.pdf";
        String inputFilePath = "some/";
        byte[] fileBytes = "PDF content".getBytes();


        when(blobUtils.getPdfBlobClient(inputFilePath + fileName, "")).thenReturn(blobClient);
        when(blobClient.downloadContent()).thenReturn(binaryData);
        when(binaryData.toBytes()).thenReturn(fileBytes);
        ResponseEntity<Resource> response = mgmtUIService.downloadPdf(fileName, inputFilePath);

        // Assert
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());

    }

    @Test
    void testDownloadPdf_ExceptionHandling() {
        // Arrange
        String fileName = "sample.pdf";
        String inputFilePath = "some/path/";

        ResponseEntity<Resource> response = mgmtUIService.downloadPdf(fileName, inputFilePath);

        // Assert
        assertNull(response);
    }

    @Test
    void testDownloadZips_Success() {
        // Arrange
        String fileName = "sample.zip";
        String inputFilePath = "some/path/";
        byte[] fileBytes = "ZIP content".getBytes();

        when(blobUtils.getBlobClient(inputFilePath + fileName)).thenReturn(blobClient);
        when(blobClient.downloadContent()).thenReturn(binaryData);
        when(binaryData.toBytes()).thenReturn(fileBytes);

        // Act
        ResponseEntity<Resource> response = mgmtUIService.downloadzips(fileName, inputFilePath);

        // Assert
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(MediaType.APPLICATION_OCTET_STREAM, response.getHeaders().getContentType());
        assertTrue(response.getHeaders().getContentDisposition().toString().contains("attachment"));

        Resource resource = response.getBody();
        assertNotNull(resource);
        verify(blobUtils).getBlobClient(inputFilePath + fileName);
    }

    @Test
    void testDownloadZips_ExceptionHandling() {
        // Arrange
        String fileName = "sample.zip";
        String inputFilePath = "some/path/";

        when(blobUtils.getBlobClient(inputFilePath + fileName))
                .thenThrow(new RuntimeException("Error accessing blob"));

        // Act
        ResponseEntity<Resource> response = mgmtUIService.downloadzips(fileName, inputFilePath);

        // Assert
        assertNull(response);
        verify(blobUtils).getBlobClient(inputFilePath + fileName);
    }

    @Test
    void testDownloadZips_ValidInputValidation() {
        // Arrange
        String fileName = "valid-file.zip";
        String inputFilePath = "valid/path/";
        byte[] fileBytes = "ZIP content".getBytes();

        when(blobUtils.getBlobClient(inputFilePath + fileName)).thenReturn(blobClient);
        when(blobClient.downloadContent()).thenReturn(binaryData);
        when(binaryData.toBytes()).thenReturn(fileBytes);

        // Act
        ResponseEntity<Resource> response = mgmtUIService.downloadzips(fileName, inputFilePath);

        // Assert
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }
}
