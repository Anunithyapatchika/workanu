package com.uhg.comm.edelivery.reportingservice.scheduler;

import com.uhg.comm.edelivery.reportingservice.service.USP3231DataService;
import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.core.SimpleLock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class USP3231SchedulerTest {

    @InjectMocks
    private USP3231Scheduler usp3231Scheduler;

    @Mock
    private USP3231DataService usp3231DataService;

    @Mock
    private LockProvider lockProvider;

    @Mock
    private SimpleLock simpleLock;


    @Test
    void testUpdateTotalRecordCount() {
        // Call the method
        usp3231Scheduler.updateTotalRecordCount();

        // Verify the interactions
        verify(usp3231DataService, times(1)).process();
    }

    @Test
    void testUpdateTotalRecordCountWithLock() {
        // Call the method
        usp3231Scheduler.updateTotalRecordCount();

        // Verify the interactions
        verify(usp3231DataService, times(1)).process();
    }
}