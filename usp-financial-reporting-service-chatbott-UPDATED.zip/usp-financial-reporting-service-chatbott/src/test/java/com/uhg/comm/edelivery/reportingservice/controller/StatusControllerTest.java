package com.uhg.comm.edelivery.reportingservice.controller;

import com.uhg.comm.edelivery.reportingservice.bean.GetFieldValues;
import com.uhg.comm.edelivery.reportingservice.service.HSSuppCostReportService;
import com.uhg.comm.edelivery.reportingservice.service.USPFinancialReportService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class StatusControllerTest {

    @InjectMocks
    private StatusController statusController;

    @Mock
    private USPFinancialReportService uspFinancialReportService;

    @Mock
    private HSSuppCostReportService hsSuppCostReportService;

    private HashMap<String, List<GetFieldValues>> mockFieldMap;

    @BeforeEach
    void setUp() {
        mockFieldMap = new HashMap<>();
    }

    @Test
    void testFetchFieldValuesForEOB() {
        String trailName = "trail1";
        String startDate = "2023-01-01";
        String endDate = "2023-01-31";

        when(uspFinancialReportService.fetchIsCompletedValues(trailName, startDate, endDate)).thenReturn(mockFieldMap);

        ResponseEntity<HashMap<String, List<GetFieldValues>>> response = statusController.fetchFieldValuesForEOB(trailName, startDate, endDate);

        assertEquals(mockFieldMap, response.getBody());
        assertEquals(200, response.getStatusCodeValue());
    }

    @Test
    void testFetchFieldValuesForHS() {
        String trailName = "trail2";
        String startDate = "2023-02-01";
        String endDate = "2023-02-28";

        when(hsSuppCostReportService.fetchIsCompletedValues(trailName, startDate, endDate)).thenReturn(mockFieldMap);

        ResponseEntity<HashMap<String, List<GetFieldValues>>> response = statusController.fetchFieldValuesForHS(trailName, startDate, endDate);

        assertEquals(mockFieldMap, response.getBody());
        assertEquals(200, response.getStatusCodeValue());
    }

    @Test
    void testFetchFieldValuesForEOB_InvalidParams() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            statusController.fetchFieldValuesForEOB("", "2023-01-01", "2023-01-31");
        });
        assertEquals("Trail Name, Start Date and End Date are mandatory fields. Please provide valid values.", exception.getMessage());
    }

    @Test
    void testFetchFieldValuesForHS_InvalidParams() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            statusController.fetchFieldValuesForHS("trail2", "", "2023-02-28");
        });
        assertEquals("Trail Name, Start Date and End Date are mandatory fields. Please provide valid values.", exception.getMessage());
    }


}