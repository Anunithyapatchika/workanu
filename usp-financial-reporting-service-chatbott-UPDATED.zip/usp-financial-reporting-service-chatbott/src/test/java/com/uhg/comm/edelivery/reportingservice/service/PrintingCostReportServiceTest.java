package com.uhg.comm.edelivery.reportingservice.service;

import com.uhg.comm.edelivery.reportingservice.dto.PrintCostResponseItems;
import com.uhg.comm.edelivery.reportingservice.dto.PrintingCostDto;
import com.uhg.comm.edelivery.reportingservice.model.PrintingCostReport;
import com.uhg.comm.edelivery.reportingservice.model.USPFinancialReport;
import com.uhg.comm.edelivery.reportingservice.repository.PrintingCostReportRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PrintingCostReportServiceTest {

    @InjectMocks
    private PrintingCostReportService printingCostReportService;

    @Mock
    private PrintingCostReportRepository printingCostReportRepository;

    @Mock
    private HSSuppCostReportService hsSuppCostReportService;

    @Test
    void getByTrailBOBAndMonthTest() {
        PrintingCostReport printingCostReport = new PrintingCostReport();
        printingCostReport.setTrailName("trailName");
        printingCostReport.setBob("bob");
        printingCostReport.setMonthYear(LocalDate.of(2022, 6, 1));
        printingCostReport.setMonth("June 2022");
        printingCostReport.setId(1);

        when(printingCostReportRepository.findByTrailNameAndBobAndMonth(anyString(), anyString(), anyString()))
                .thenReturn(Optional.of(printingCostReport));
        printingCostReportService.getByTrailBOBAndMonth("trailNumber", "June 2022", "June 2023");
        verify(printingCostReportRepository).findByTrailNameAndBobAndMonth(anyString(), anyString(), anyString());
    }

    @Test
    void getPrintCostReportResponseTest(){

        PrintingCostReport printingCostReport = new PrintingCostReport();
        printingCostReport.setTrailName("trailName");
        printingCostReport.setBob("bob");
        printingCostReport.setMonthYear(LocalDate.of(2022, 6, 1));
        printingCostReport.setMonth("June 2022");
        printingCostReport.setId(1);

        when(printingCostReportRepository.findByTrailNameAndDateBetween(anyString(), any(LocalDate.class), any(LocalDate.class)))
                .thenReturn(Collections.singletonList(printingCostReport));
        USPFinancialReport u = new USPFinancialReport();
        u.setBob("bob");
        u.setMonthYearStr("June 2022");
        printingCostReportService.getPrintCostReportResponse("trailNumber", LocalDate.of(2022, 6, 1), LocalDate.of(2023, 6, 1), List.of(u));
        verify(printingCostReportRepository).findByTrailNameAndDateBetween(anyString(), any(LocalDate.class), any(LocalDate.class));
    }

    @Test
    void savePostageCostReportTest(){
        PrintingCostDto printingCostDto = PrintingCostDto.builder().build();
        printingCostDto.setTrailName("PT3696-USP HS");
        printingCostDto.setBob("BOB");
        LocalDate now = LocalDate.now();
        String monthName = now.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
        int year = now.getYear();

        String monthYear = monthName + " " + year;
        printingCostDto.setMonth("June 2022");
        printingCostDto.setPostageCost(1.0);
        printingCostDto.setPrintExpenseCost(1.0);
        printingCostDto.setPaperCount(1.0);
        printingCostDto.setImageCount(1.0);
        printingCostDto.setEnvelopCount(1.0);


        doNothing().when(hsSuppCostReportService).saveHsSuppDataFromPrintCostReport(any());
        boolean result = printingCostReportService.savePostageCostReport(printingCostDto);
        verify(hsSuppCostReportService).saveHsSuppDataFromPrintCostReport(any());

    }

    @Test
    void savePostageCostReportElseTest(){
        PrintingCostDto printingCostDto = PrintingCostDto.builder().build();
        printingCostDto.setTrailName("PT3696-USP HS");
        printingCostDto.setBob("BOB");
        LocalDate now = LocalDate.now();
        printingCostDto.setId(1);
        String monthName = now.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
        int year = now.getYear();

        String monthYear = monthName + " " + year;
        printingCostDto.setMonth("June 2022");
        printingCostDto.setPostageCost(1.0);
        printingCostDto.setPrintExpenseCost(1.0);
        printingCostDto.setPaperCount(1.0);
        printingCostDto.setImageCount(1.0);
        printingCostDto.setEnvelopCount(1.0);

        PrintingCostReport printingCostReport = PrintingCostReport.builder().build();
        when(printingCostReportRepository.findById(anyInt())).thenReturn(Optional.of(printingCostReport));
        doNothing().when(hsSuppCostReportService).saveHsSuppDataFromPrintCostReport(any());
        boolean result = printingCostReportService.savePostageCostReport(printingCostDto);
        verify(hsSuppCostReportService).saveHsSuppDataFromPrintCostReport(any());

    }

    @Test
    void testGetPrintCostResponseItems_Success() {
        PrintCostResponseItems item1 = new PrintCostResponseItems();
        item1.setPostageCost(10.0);
        item1.setPaperLabourCost(5.0);
        item1.setCostPerEnvelop(2.0);
        item1.setEnvelopeCount(100.0);

        PrintCostResponseItems item2 = new PrintCostResponseItems();
        item2.setPostageCost(20.0);
        item2.setPaperLabourCost(10.0);
        item2.setCostPerEnvelop(4.0);
        item2.setEnvelopeCount(200.0);

        List<PrintCostResponseItems> items = List.of(item1, item2);

        PrintCostResponseItems result = PrintingCostReportService.getPrintCostResponseItems("Business1", items);

        assertEquals("Business1", result.getBob());
        assertEquals(30.0, result.getPostageCost());
        assertEquals(15.0, result.getPaperLabourCost());
        assertEquals(6.0, result.getCostPerEnvelop());
        assertEquals(300.0, result.getEnvelopeCount());
    }

    @Test
    void testGetPrintCostResponseItems_EmptyList() {
        List<PrintCostResponseItems> items = List.of();

        PrintCostResponseItems result = PrintingCostReportService.getPrintCostResponseItems("Business1", items);

        assertEquals("Business1", result.getBob());
        assertEquals(0.0, result.getPostageCost());
        assertEquals(0.0, result.getPaperLabourCost());
        assertEquals(0.0, result.getCostPerEnvelop());
        assertEquals(0.0, result.getEnvelopeCount());
    }

    @Test
    void testGetPrintCostResponseItems_MonthlyTotal() {
        PrintCostResponseItems item1 = new PrintCostResponseItems();
        item1.setPostageCost(10.0);
        item1.setPaperLabourCost(5.0);
        item1.setCostPerEnvelop(2.0);
        item1.setEnvelopeCount(100.0);

        PrintCostResponseItems item2 = new PrintCostResponseItems();
        item2.setPostageCost(20.0);
        item2.setPaperLabourCost(10.0);
        item2.setCostPerEnvelop(4.0);
        item2.setEnvelopeCount(200.0);

        List<PrintCostResponseItems> items = List.of(item1, item2);

        PrintCostResponseItems result = PrintingCostReportService.getPrintCostResponseItems("Monthly Total", items);

        assertEquals("Total", result.getBob());
        assertEquals(30.0, result.getPostageCost());
        assertEquals(15.0, result.getPaperLabourCost());
        assertEquals(6.0, result.getCostPerEnvelop());
        assertEquals(300.0, result.getEnvelopeCount());
    }


}
