package com.uhg.comm.edelivery.reportingservice.nesslogger;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Properties;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class NessLoggerServiceTest {

	@Mock
	private NessLoggerConfig nessLoggerConfig;

	@Mock
	Properties properties;

	@InjectMocks
	private NessLoggerService nessloggerService;

	@BeforeEach
	void setup() {
		ReflectionTestUtils.setField(nessloggerService, "connectionString",
				"Endpoint=sb://lp-cl-centralus-eventhub-edf00763.servicebus.windows.net/;SharedAccessKeyName=lp-cl-auth-rule;SharedAccessKey=ZNdQ3CwO1xx4kOtr3R5kHgimA5CNOFpRYpl/nx0Nupg=;EntityPath=application-logs");

	}

	@Disabled
	@Test
	void publishnessLogsTest() throws Exception {
		Mockito.when(nessLoggerConfig.loadRequiredFields(Mockito.any())).thenReturn(properties);
		nessloggerService.publishNesslogsToSplunk("nesslogs");
		assertNotNull(properties);
	}

}
