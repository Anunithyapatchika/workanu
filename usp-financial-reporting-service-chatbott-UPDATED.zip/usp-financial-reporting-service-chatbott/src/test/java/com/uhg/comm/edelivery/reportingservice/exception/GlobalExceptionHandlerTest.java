package com.uhg.comm.edelivery.reportingservice.exception;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.WebRequest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GlobalExceptionHandlerTest {

    @InjectMocks
    private GlobalExceptionHandler globalExceptionHandler;

    @Mock
    private WebRequest webRequest;

    private String contextPath = "/api";

    @BeforeEach
    void setUp() {
        when(webRequest.getContextPath()).thenReturn(contextPath);
    }

    @Test
    void handleException_ShouldReturnInternalServerError() {
        // Arrange
        Exception exception = new Exception("Test general exception");

        // Act
        ResponseEntity<?> responseEntity = globalExceptionHandler.handleException(exception, webRequest);

        // Assert
        assertNotNull(responseEntity);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        String responseBody = (String) responseEntity.getBody();
        assertNotNull(responseBody);
        // The response should contain error code -1 as defined in the handler
        assertEquals(true, responseBody.contains("-1"));
        // The response should contain the exception message
        assertEquals(true, responseBody.contains("Test general exception"));
    }

    @Test
    void handleException_WithNullMessage_ShouldHandleGracefully() {
        // Arrange
        Exception exception = new Exception();

        // Act
        ResponseEntity<?> responseEntity = globalExceptionHandler.handleException(exception, webRequest);

        // Assert
        assertNotNull(responseEntity);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        assertNotNull(responseEntity.getBody());
    }

    // Additional test for USPException handling
    // Note: This test assumes that GlobalExceptionHandler will be enhanced to handle USPException specifically
    @Test
    void handleUSPException_WhenImplemented_ShouldReturnAppropriateResponse() {
        // Arrange
        USPException uspException = new USPException("Custom business exception");

        // Act
        // This currently goes through the general exception handler
        // In the future, you might want to add a specific handler for USPException
        ResponseEntity<?> responseEntity = globalExceptionHandler.handleException(uspException, webRequest);

        // Assert
        assertNotNull(responseEntity);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        String responseBody = (String) responseEntity.getBody();
        assertNotNull(responseBody);
        assertEquals(true, responseBody.contains("Custom business exception"));
    }
}
