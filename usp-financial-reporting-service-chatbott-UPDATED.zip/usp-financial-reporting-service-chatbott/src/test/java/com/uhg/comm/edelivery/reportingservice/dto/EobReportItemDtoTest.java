package com.uhg.comm.edelivery.reportingservice.dto;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EobReportItemDtoTest {

    @Test
    void testGettersAndSetters() {
        EobReportItemDto eobReportItem = new EobReportItemDto();
        eobReportItem.setBob("bob");
        eobReportItem.setTotalEobsGenerated(1.0);
        eobReportItem.setTotalEobsSuppressed(2.0);
        eobReportItem.setTotalEobsSuppressedSubscriberElection(3.0);
        eobReportItem.setTotalEobsSuppressedPolicySetting(4.0);
        eobReportItem.setTotalEobsPrinted(5.0);
        eobReportItem.setEobSuppressedPercent(6.0);

        assertEquals("bob", eobReportItem.getBob());
        assertEquals(1.0, eobReportItem.getTotalEobsGenerated());
        assertEquals(2.0, eobReportItem.getTotalEobsSuppressed());
        assertEquals(3.0, eobReportItem.getTotalEobsSuppressedSubscriberElection());
        assertEquals(4.0, eobReportItem.getTotalEobsSuppressedPolicySetting());
        assertEquals(5.0, eobReportItem.getTotalEobsPrinted());
        assertEquals(6.0, eobReportItem.getEobSuppressedPercent());
    }

    @Test
    void testEqualsAndHashCode() {
        // Create two identical objects
        EobReportItemDto item1 = new EobReportItemDto();
        item1.setBob("BOB123");
        item1.setTotalEobsGenerated(1000.0);
        item1.setTotalEobsSuppressed(200.0);
        item1.setTotalEobsSuppressedSubscriberElection(150.0);
        item1.setTotalEobsSuppressedPolicySetting(50.0);
        item1.setTotalEobsPrinted(800.0);
        item1.setEobSuppressedPercent(20.0);

        EobReportItemDto item2 = new EobReportItemDto();
        item2.setBob("BOB123");
        item2.setTotalEobsGenerated(1000.0);
        item2.setTotalEobsSuppressed(200.0);
        item2.setTotalEobsSuppressedSubscriberElection(150.0);
        item2.setTotalEobsSuppressedPolicySetting(50.0);
        item2.setTotalEobsPrinted(800.0);
        item2.setEobSuppressedPercent(20.0);

        // Create a different object
        EobReportItemDto item3 = new EobReportItemDto();
        item3.setBob("BOB456");
        item3.setTotalEobsGenerated(2000.0);
        item3.setTotalEobsSuppressed(400.0);
        item3.setTotalEobsSuppressedSubscriberElection(300.0);
        item3.setTotalEobsSuppressedPolicySetting(100.0);
        item3.setTotalEobsPrinted(1600.0);
        item3.setEobSuppressedPercent(20.0);

        // Test equals
        assertEquals(item1, item2);
        assertNotEquals(item1, item3);
        assertNotEquals(item1, null);
        assertNotEquals(item1, new Object());

        // Test hashCode
        assertEquals(item1.hashCode(), item2.hashCode());
        assertNotEquals(item1.hashCode(), item3.hashCode());

        // Test equality with just one field different
        EobReportItemDto item4 = new EobReportItemDto();
        item4.setBob("BOB123");
        item4.setTotalEobsGenerated(1000.0);
        item4.setTotalEobsSuppressed(200.0);
        item4.setTotalEobsSuppressedSubscriberElection(150.0);
        item4.setTotalEobsSuppressedPolicySetting(50.0);
        item4.setTotalEobsPrinted(800.0);
        item4.setEobSuppressedPercent(21.0); // Different percent

        assertNotEquals(item1, item4);
        assertNotEquals(item1.hashCode(), item4.hashCode());
    }

    @Test
    void testToString() {
        EobReportItemDto item = new EobReportItemDto();
        item.setBob("BOB123");
        item.setTotalEobsGenerated(1000.0);
        item.setTotalEobsSuppressed(200.0);
        item.setTotalEobsSuppressedSubscriberElection(150.0);
        item.setTotalEobsSuppressedPolicySetting(50.0);
        item.setTotalEobsPrinted(800.0);
        item.setEobSuppressedPercent(20.0);

        String toString = item.toString();

        // Verify toString contains all field values
        assertTrue(toString.contains("bob=BOB123"));
        assertTrue(toString.contains("totalEobsGenerated=1000.0"));
        assertTrue(toString.contains("totalEobsSuppressed=200.0"));
        assertTrue(toString.contains("totalEobsSuppressedSubscriberElection=150.0"));
        assertTrue(toString.contains("totalEobsSuppressedPolicySetting=50.0"));
        assertTrue(toString.contains("totalEobsPrinted=800.0"));
        assertTrue(toString.contains("eobSuppressedPercent=20.0"));
    }

    @Test
    void testNullValues() {
        EobReportItemDto item = new EobReportItemDto();

        // Default values
        assertNull(item.getBob());
        assertEquals(0.0, item.getTotalEobsGenerated());
        assertEquals(0.0, item.getTotalEobsSuppressed());
        assertEquals(0.0, item.getTotalEobsSuppressedSubscriberElection());
        assertEquals(0.0, item.getTotalEobsSuppressedPolicySetting());
        assertEquals(0.0, item.getTotalEobsPrinted());
        assertEquals(0.0, item.getEobSuppressedPercent());

        // Set and unset string value
        item.setBob("test");
        assertEquals("test", item.getBob());
        item.setBob(null);
        assertNull(item.getBob());
    }

    @Test
    void testEdgeCases() {
        EobReportItemDto item = new EobReportItemDto();

        // Test with empty string
        item.setBob("");
        assertEquals("", item.getBob());

        // Test with special characters
        item.setBob("BOB-123_TEST*&^%$#@!");
        assertEquals("BOB-123_TEST*&^%$#@!", item.getBob());

        // Test with zero values
        item.setTotalEobsGenerated(0);
        item.setTotalEobsSuppressed(0);
        item.setTotalEobsSuppressedSubscriberElection(0);
        item.setTotalEobsSuppressedPolicySetting(0);
        item.setTotalEobsPrinted(0);
        item.setEobSuppressedPercent(0);

        assertEquals(0, item.getTotalEobsGenerated());
        assertEquals(0, item.getTotalEobsSuppressed());
        assertEquals(0, item.getTotalEobsSuppressedSubscriberElection());
        assertEquals(0, item.getTotalEobsSuppressedPolicySetting());
        assertEquals(0, item.getTotalEobsPrinted());
        assertEquals(0, item.getEobSuppressedPercent());

        // Test with negative values
        item.setTotalEobsGenerated(-1000);
        item.setTotalEobsSuppressed(-200);
        item.setTotalEobsSuppressedSubscriberElection(-150);
        item.setTotalEobsSuppressedPolicySetting(-50);
        item.setTotalEobsPrinted(-800);
        item.setEobSuppressedPercent(-20);

        assertEquals(-1000, item.getTotalEobsGenerated());
        assertEquals(-200, item.getTotalEobsSuppressed());
        assertEquals(-150, item.getTotalEobsSuppressedSubscriberElection());
        assertEquals(-50, item.getTotalEobsSuppressedPolicySetting());
        assertEquals(-800, item.getTotalEobsPrinted());
        assertEquals(-20, item.getEobSuppressedPercent());
    }

    @Test
    void testBoundaryValues() {
        EobReportItemDto item = new EobReportItemDto();

        // Test with minimum and maximum double values
        item.setTotalEobsGenerated(Double.MIN_VALUE);
        item.setTotalEobsSuppressed(Double.MAX_VALUE);

        assertEquals(Double.MIN_VALUE, item.getTotalEobsGenerated());
        assertEquals(Double.MAX_VALUE, item.getTotalEobsSuppressed());

        // Test with infinity and NaN
        item.setTotalEobsSuppressedSubscriberElection(Double.POSITIVE_INFINITY);
        item.setTotalEobsSuppressedPolicySetting(Double.NEGATIVE_INFINITY);
        item.setTotalEobsPrinted(Double.NaN);

        assertEquals(Double.POSITIVE_INFINITY, item.getTotalEobsSuppressedSubscriberElection());
        assertEquals(Double.NEGATIVE_INFINITY, item.getTotalEobsSuppressedPolicySetting());
        assertTrue(Double.isNaN(item.getTotalEobsPrinted()));

        // Test with very large string
        StringBuilder largeString = new StringBuilder();
        for (int i = 0; i < 1000; i++) {
            largeString.append("test");
        }
        item.setBob(largeString.toString());
        assertEquals(largeString.toString(), item.getBob());
    }

    @Test
    void testChainedSetters() {
        // Lombok @Data doesn't provide chained setters by default, but if it did:
        EobReportItemDto item = new EobReportItemDto();

        // Set values in sequence
        item.setBob("BOB123");
        item.setTotalEobsGenerated(1000.0);
        item.setTotalEobsSuppressed(200.0);
        item.setTotalEobsSuppressedSubscriberElection(150.0);
        item.setTotalEobsSuppressedPolicySetting(50.0);
        item.setTotalEobsPrinted(800.0);
        item.setEobSuppressedPercent(20.0);

        // Verify all values were set correctly
        assertEquals("BOB123", item.getBob());
        assertEquals(1000.0, item.getTotalEobsGenerated());
        assertEquals(200.0, item.getTotalEobsSuppressed());
        assertEquals(150.0, item.getTotalEobsSuppressedSubscriberElection());
        assertEquals(50.0, item.getTotalEobsSuppressedPolicySetting());
        assertEquals(800.0, item.getTotalEobsPrinted());
        assertEquals(20.0, item.getEobSuppressedPercent());
    }

    @Test
    void testPrecisionIssues() {
        EobReportItemDto item = new EobReportItemDto();

        // Test precision with floating point values
        double value = 0.1 + 0.2; // Known to not equal exactly 0.3 in binary floating point
        item.setEobSuppressedPercent(value);

        // The test should handle floating point precision issues
        assertEquals(0.30000000000000004, item.getEobSuppressedPercent());

        // Test with very small difference
        item.setTotalEobsGenerated(1.0);
        item.setTotalEobsSuppressed(1.0 + Double.MIN_VALUE);

    }
}