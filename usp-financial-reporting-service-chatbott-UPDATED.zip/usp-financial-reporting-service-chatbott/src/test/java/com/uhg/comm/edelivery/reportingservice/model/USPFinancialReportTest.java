package com.uhg.comm.edelivery.reportingservice.model;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
class USPFinancialReportTest {
    @Test
    public void testGetterAndSetters() {
        USPFinancialReport report = new USPFinancialReport();
        report.setId(1);
        report.setTrailName("12345");
        report.setMonthYear(LocalDate.parse("2023-10-01", DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        report.setMonthYearStr("October 2024");
        report.setBob("BOB1");
        report.setTotalEobGenerated(100.0);
        report.setTotalEobSuppressed(50.0);
        report.setMemberElectionEob(10.0);
        report.setPolicySettingEob(5.0);
        report.setTotalEobPrinted(35.0);
        report.setEobSuppressPercent(50.0);
        report.setTotalHsGenerated(200.0);
        report.setTotalHsSuppressed(100.0);
        report.setMemberElectionHs(20.0);
        report.setPolicySettingHs(10.0);
        report.setTotalHsPrinted(70.0);
        report.setHsSuppressPercent(50.0);
        report.setCaeEobMailCount(30.0);
        report.setCaeEobNoEmailCount(20.0);
        report.setTotalCaeEobCount(50.0);
        report.setCreatedBy("user1");
        report.setCreatedDate(LocalDateTime.now());
        report.setModifiedBy("user2");
        report.setModifiedDate(LocalDateTime.now());
        report.setIsTxCompleted(0);

        assertEquals(1, report.getId());
        assertEquals("12345", report.getTrailName());
        assertEquals("2023-10", report.getMonthYear().format(DateTimeFormatter.ofPattern("yyyy-MM")));
        assertEquals("October 2024", report.getMonthYearStr());
        assertEquals("BOB1", report.getBob());
        assertEquals(100.0, report.getTotalEobGenerated());
        assertEquals(50.0, report.getTotalEobSuppressed());
        assertEquals(10.0, report.getMemberElectionEob());
        assertEquals(5.0, report.getPolicySettingEob());
        assertEquals(35.0, report.getTotalEobPrinted());
        assertEquals(50.0, report.getEobSuppressPercent());
        assertEquals(200.0, report.getTotalHsGenerated());
        assertEquals(100.0, report.getTotalHsSuppressed());
        assertEquals(20.0, report.getMemberElectionHs());
        assertEquals(10.0, report.getPolicySettingHs());
        assertEquals(70.0, report.getTotalHsPrinted());
        assertEquals(50.0, report.getHsSuppressPercent());
        assertEquals(30.0, report.getCaeEobMailCount());
        assertEquals(20.0, report.getCaeEobNoEmailCount());
        assertEquals(50.0, report.getTotalCaeEobCount());
        assertEquals("user1", report.getCreatedBy());


    }

    @Test
    public void testEqualsAndHashCode() {
        USPFinancialReport report1 = new USPFinancialReport();
        report1.setId(1);
        report1.setTrailName("12345");

        USPFinancialReport report2 = new USPFinancialReport();
        report2.setId(1);
        report2.setTrailName("12345");

        assertEquals(report1, report2);
        assertEquals(report1.hashCode(), report2.hashCode());
    }

    @Test
    public void testToString() {
        USPFinancialReport report = new USPFinancialReport();
        report.setId(1);
        report.setTrailName("12345");

        assertNotNull(report);
    }

}