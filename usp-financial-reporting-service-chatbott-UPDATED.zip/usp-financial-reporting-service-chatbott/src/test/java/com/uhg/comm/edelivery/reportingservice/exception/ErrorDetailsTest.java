package com.uhg.comm.edelivery.reportingservice.exception;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import net.minidev.json.JSONObject;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ErrorDetailsTest {

    @Test
    void testConstructorAndGetters() {
        ErrorDetails errorDetails = new ErrorDetails(404, "Not Found", "The requested resource was not found");

        assertEquals(404, errorDetails.getCode());
        assertEquals("Not Found", errorDetails.getMessage());
        assertEquals("The requested resource was not found", errorDetails.getDetails());
    }

    @Test
    void testToJsonString() {
        ErrorDetails errorDetails = new ErrorDetails(500, "Internal Server Error", "An unexpected error occurred");
        ObjectNode json = errorDetails.toJsonString();

        assertNotNull(json);
        assertEquals(500, json.get("code").asInt());
        assertEquals("Internal Server Error", json.get("message").asText());
        assertEquals("An unexpected error occurred", json.get("details").asText());
    }

    @Test
    void testJsonString() {
        ErrorDetails errorDetails = new ErrorDetails(400, "Bad Request", "Invalid input provided");
        String jsonString = errorDetails.jsonString();

        JSONObject expectedJson = new JSONObject();
        expectedJson.put("code", 400);
        expectedJson.put("message", "Bad Request");

        assertNotNull(jsonString);
        assertEquals(expectedJson.toString(), jsonString);
    }

    @Test
    void testNoArgsConstructor() {
        ErrorDetails errorDetails = new ErrorDetails();
        errorDetails.setCode(200);
        errorDetails.setMessage("OK");
        errorDetails.setDetails("Request was successful");

        assertEquals(200, errorDetails.getCode());
        assertEquals("OK", errorDetails.getMessage());
        assertEquals("Request was successful", errorDetails.getDetails());
    }

    @Test
    void testEqualsAndHashCode() {
        // Same values
        ErrorDetails errorDetails1 = new ErrorDetails(400, "Bad Request", "Invalid input");
        ErrorDetails errorDetails2 = new ErrorDetails(400, "Bad Request", "Invalid input");

        // Different values
        ErrorDetails errorDetails3 = new ErrorDetails(500, "Server Error", "System failure");

        // Test equals
        assertNotEquals(errorDetails1, errorDetails3);
        assertNotEquals(errorDetails1, null);
        assertNotEquals(errorDetails1, new Object());
    }

    @Test
    void testToString() {
        ErrorDetails errorDetails = new ErrorDetails(404, "Not Found", "Resource not available");
        String toStringResult = errorDetails.toString();

        assertTrue(toStringResult.contains("code=404"));
        assertTrue(toStringResult.contains("message=Not Found"));
        assertTrue(toStringResult.contains("details=Resource not available"));
    }

    @Test
    void testSettersAndGetters() {
        ErrorDetails errorDetails = new ErrorDetails();

        // Test code
        errorDetails.setCode(403);
        assertEquals(403, errorDetails.getCode());

        // Test message
        errorDetails.setMessage("Forbidden");
        assertEquals("Forbidden", errorDetails.getMessage());

        // Test details
        errorDetails.setDetails("Access denied");
        assertEquals("Access denied", errorDetails.getDetails());

        // Test changing values
        errorDetails.setCode(503);
        errorDetails.setMessage("Service Unavailable");
        errorDetails.setDetails("The service is temporarily unavailable");

        assertEquals(503, errorDetails.getCode());
        assertEquals("Service Unavailable", errorDetails.getMessage());
        assertEquals("The service is temporarily unavailable", errorDetails.getDetails());
    }

    @Test
    void testEdgeCases() {
        // Test with zero value for code
        ErrorDetails zeroCodeError = new ErrorDetails(0, "Zero Code", "Testing with zero code");
        assertEquals(0, zeroCodeError.getCode());

        // Test with negative value for code
        ErrorDetails negativeCodeError = new ErrorDetails(-1, "Negative Code", "Testing with negative code");
        assertEquals(-1, negativeCodeError.getCode());

        // Test with empty strings
        ErrorDetails emptyStringsError = new ErrorDetails(418, "", "");
        assertEquals(418, emptyStringsError.getCode());
        assertEquals("", emptyStringsError.getMessage());
        assertEquals("", emptyStringsError.getDetails());

        // Test toJsonString with empty values
        ObjectNode emptyJsonNode = emptyStringsError.toJsonString();
        assertEquals(418, emptyJsonNode.get("code").asInt());
        assertEquals("", emptyJsonNode.get("message").asText());
        assertEquals("", emptyJsonNode.get("details").asText());

        // Test jsonString with empty message
        String emptyJsonString = emptyStringsError.jsonString();
        assertTrue(emptyJsonString.contains("\"code\":418"));
        assertTrue(emptyJsonString.contains("\"message\":\"\""));
    }

    @Test
    void testNullHandling() {
        // Test with null strings
        ErrorDetails nullStringsError = new ErrorDetails(422, null, null);
        assertEquals(422, nullStringsError.getCode());
        assertNull(nullStringsError.getMessage());
        assertNull(nullStringsError.getDetails());

        // Test toJsonString with null values
        ObjectNode nullJsonNode = nullStringsError.toJsonString();
        assertEquals(422, nullJsonNode.get("code").asInt());
        assertTrue(nullJsonNode.get("message").isNull());
        assertTrue(nullJsonNode.get("details").isNull());

        // Test jsonString with null message
        String nullJsonString = nullStringsError.jsonString();
        assertTrue(nullJsonString.contains("\"code\":422"));
        // JSONObject converts null to string "null" in some implementations
        assertTrue(nullJsonString.contains("\"message\":null") || nullJsonString.contains("\"message\":\"null\""));
    }

    @Test
    void testObjectMapperInstance() {
        ErrorDetails errorDetails1 = new ErrorDetails();
        ErrorDetails errorDetails2 = new ErrorDetails();

        // Each instance should have its own ObjectMapper
        assertNotNull(errorDetails1.om);
        assertNotNull(errorDetails2.om);

        // ObjectMapper instances should be separate
        assertNotSame(errorDetails1.om, errorDetails2.om);
    }

    @Test
    void testSpecialCharactersHandling() {
        // Test with special characters in strings
        ErrorDetails specialCharsError = new ErrorDetails(
            400,
            "Error: \"Quotes\" and 'Apostrophes'",
            "Details with <HTML> & JSON {\"key\": \"value\"}"
        );

        // Test toJsonString properly escapes special characters
        ObjectNode specialCharsJsonNode = specialCharsError.toJsonString();
        assertEquals("Error: \"Quotes\" and 'Apostrophes'", specialCharsJsonNode.get("message").asText());
        assertEquals("Details with <HTML> & JSON {\"key\": \"value\"}", specialCharsJsonNode.get("details").asText());

        // Test jsonString properly escapes special characters
        String specialCharsJsonString = specialCharsError.jsonString();
        assertTrue(specialCharsJsonString.contains("\"message\":\"Error: \\\"Quotes\\\" and 'Apostrophes'\"") ||
                   specialCharsJsonString.contains("\"message\":\"Error: \\\"Quotes\\\" and \\'Apostrophes\\'\""));
    }
}