package com.uhg.comm.edelivery.reportingservice.dto;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class EobReportDtoTest {

    @Test
    void testGettersAndSetters() {
        EobReportDto eobReport = new EobReportDto();
        eobReport.setDate("2023-10");
        eobReport.setTrailNumber("12345");
        List<EobReportItemDto> items = new ArrayList<>();
        eobReport.setItems(items);

        assertEquals("2023-10", eobReport.getDate());
        assertEquals("12345", eobReport.getTrailNumber());
        assertEquals(items, eobReport.getItems());
    }

    @Test
    void testEqualsAndHashCode() {
        EobReportDto eobReport1 = new EobReportDto();
        eobReport1.setDate("2023-10");
        eobReport1.setTrailNumber("12345");

        EobReportDto eobReport2 = new EobReportDto();
        eobReport2.setDate("2023-10");
        eobReport2.setTrailNumber("12345");

        assertEquals(eobReport1, eobReport2);
        assertEquals(eobReport1.hashCode(), eobReport2.hashCode());
    }

    @Test
    void testToString() {
        EobReportDto eobReport = new EobReportDto();
        eobReport.setDate("2023-10");
        eobReport.setTrailNumber("12345");

        String expected = "EobReportDto(date=2023-10, trailNumber=12345, items=null)";
        assertEquals(expected, eobReport.toString());
    }

}