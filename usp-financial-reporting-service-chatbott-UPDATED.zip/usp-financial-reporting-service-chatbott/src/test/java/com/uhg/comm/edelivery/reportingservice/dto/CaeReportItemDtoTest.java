package com.uhg.comm.edelivery.reportingservice.dto;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CaeReportItemDtoTest {

    @Test
    void testGettersAndSetters() {
        CaeReportItemDto caeReportItem = new CaeReportItemDto();
        caeReportItem.setBob("bob");
        caeReportItem.setCaeSuppressionEobsWithEmail(1.0);
        caeReportItem.setCaeSuppressionEobsNoEmail(2.0);
        caeReportItem.setTotalCaeSuppressionEobsGenerated(3.0);

        assertEquals("bob", caeReportItem.getBob());
        assertEquals(1.0, caeReportItem.getCaeSuppressionEobsWithEmail());
        assertEquals(2.0, caeReportItem.getCaeSuppressionEobsNoEmail());
        assertEquals(3.0, caeReportItem.getTotalCaeSuppressionEobsGenerated());
    }

}