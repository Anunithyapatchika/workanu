package com.uhg.comm.edelivery.reportingservice.dto;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class PrintCostResponseTest {

    @InjectMocks
    private PrintCostResponse printCostResponse;

    /**
     * Helper method to create a test PrintCostResponseItems object
     */
    private PrintCostResponseItems createTestItem(String bob, double postageCost,
            double paperLabourCost, double costPerEnvelop, double envelopeCount) {
        PrintCostResponseItems item = new PrintCostResponseItems();
        item.setBob(bob);
        item.setPostageCost(postageCost);
        item.setPaperLabourCost(paperLabourCost);
        item.setCostPerEnvelop(costPerEnvelop);
        item.setEnvelopeCount(envelopeCount);
        return item;
    }

    @Test
    void testGettersAndSetters() {
        // Arrange
        String date = "July 2023";
        String trailNumber = "TR12345";
        List<PrintCostResponseItems> items = new ArrayList<>();
        PrintCostResponseItems item = createTestItem("BOB123", 100.0, 50.0, 1.5, 100.0);
        items.add(item);

        // Act
        printCostResponse.setDate(date);
        printCostResponse.setTrailNumber(trailNumber);
        printCostResponse.setItems(items);

        // Assert
        assertEquals(date, printCostResponse.getDate());
        assertEquals(trailNumber, printCostResponse.getTrailNumber());
        assertEquals(items, printCostResponse.getItems());
        assertEquals(1, printCostResponse.getItems().size());
        assertEquals("BOB123", printCostResponse.getItems().get(0).getBob());
        assertEquals(100.0, printCostResponse.getItems().get(0).getPostageCost());
        assertEquals(50.0, printCostResponse.getItems().get(0).getPaperLabourCost());
        assertEquals(1.5, printCostResponse.getItems().get(0).getCostPerEnvelop());
        assertEquals(100.0, printCostResponse.getItems().get(0).getEnvelopeCount());
    }

    @Test
    void testEqualsAndHashCode() {
        // Arrange - Create two identical objects
        PrintCostResponse response1 = new PrintCostResponse();
        response1.setDate("July 2023");
        response1.setTrailNumber("TR12345");
        List<PrintCostResponseItems> items1 = new ArrayList<>();
        items1.add(createTestItem("BOB123", 100.0, 50.0, 1.5, 100.0));
        response1.setItems(items1);

        PrintCostResponse response2 = new PrintCostResponse();
        response2.setDate("July 2023");
        response2.setTrailNumber("TR12345");
        List<PrintCostResponseItems> items2 = new ArrayList<>();
        items2.add(createTestItem("BOB123", 100.0, 50.0, 1.5, 100.0));
        response2.setItems(items2);

        // Arrange - Create a different object
        PrintCostResponse response3 = new PrintCostResponse();
        response3.setDate("August 2023");
        response3.setTrailNumber("TR67890");
        List<PrintCostResponseItems> items3 = new ArrayList<>();
        items3.add(createTestItem("BOB456", 200.0, 100.0, 3.0, 200.0));
        response3.setItems(items3);

        // Act & Assert - Test equals
        assertEquals(response1, response2);
        assertNotEquals(response1, response3);
        assertNotEquals(response1, null);
        assertNotEquals(response1, new Object());

        // Act & Assert - Test hashCode
        assertEquals(response1.hashCode(), response2.hashCode());
        assertNotEquals(response1.hashCode(), response3.hashCode());
    }

    @Test
    void testToString() {
        // Arrange
        PrintCostResponse response = new PrintCostResponse();
        response.setDate("July 2023");
        response.setTrailNumber("TR12345");
        List<PrintCostResponseItems> items = new ArrayList<>();
        items.add(createTestItem("BOB123", 100.0, 50.0, 1.5, 100.0));
        response.setItems(items);

        // Act
        String result = response.toString();

        // Assert
        assertTrue(result.contains("date=July 2023"));
        assertTrue(result.contains("trailNumber=TR12345"));
        assertTrue(result.contains("items="));
        assertTrue(result.contains("bob=BOB123"));
    }

    @Test
    void testItemsListManipulation() {
        // Arrange
        PrintCostResponse response = new PrintCostResponse();
        List<PrintCostResponseItems> items = new ArrayList<>();

        // Act & Assert - Empty list
        response.setItems(items);
        assertEquals(0, response.getItems().size());

        // Act & Assert - Add items
        PrintCostResponseItems item1 = createTestItem("BOB123", 100.0, 50.0, 1.5, 100.0);
        PrintCostResponseItems item2 = createTestItem("BOB456", 200.0, 100.0, 3.0, 200.0);

        items.add(item1);
        items.add(item2);
        assertEquals(2, response.getItems().size());
        assertEquals("BOB123", response.getItems().get(0).getBob());
        assertEquals(100.0, response.getItems().get(0).getPostageCost());
        assertEquals("BOB456", response.getItems().get(1).getBob());
        assertEquals(200.0, response.getItems().get(1).getPostageCost());

        // Act & Assert - Replace list
        List<PrintCostResponseItems> newItems = new ArrayList<>();
        PrintCostResponseItems item3 = createTestItem("BOB789", 300.0, 150.0, 4.5, 300.0);
        newItems.add(item3);

        response.setItems(newItems);
        assertEquals(1, response.getItems().size());
        assertEquals("BOB789", response.getItems().get(0).getBob());
        assertEquals(300.0, response.getItems().get(0).getPostageCost());
    }

    @Test
    void testNullValues() {
        // Arrange
        PrintCostResponse response = new PrintCostResponse();

        // Act & Assert - Default values
        assertNull(response.getDate());
        assertNull(response.getTrailNumber());
        assertNull(response.getItems());

        // Act & Assert - Set and unset
        response.setDate("July 2023");
        response.setTrailNumber("TR12345");
        List<PrintCostResponseItems> items = new ArrayList<>();
        response.setItems(items);

        assertEquals("July 2023", response.getDate());
        assertEquals("TR12345", response.getTrailNumber());
        assertNotNull(response.getItems());

        response.setDate(null);
        response.setTrailNumber(null);
        response.setItems(null);

        assertNull(response.getDate());
        assertNull(response.getTrailNumber());
        assertNull(response.getItems());
    }

    @Test
    void testWithEdgeCases() {
        // Arrange
        PrintCostResponse response = new PrintCostResponse();

        // Act & Assert - Empty strings
        response.setDate("");
        response.setTrailNumber("");
        assertEquals("", response.getDate());
        assertEquals("", response.getTrailNumber());

        // Act & Assert - Special characters
        response.setDate("2023/07-31 #@!");
        response.setTrailNumber("TR-12345_TEST*");
        assertEquals("2023/07-31 #@!", response.getDate());
        assertEquals("TR-12345_TEST*", response.getTrailNumber());

        // Act & Assert - Very large strings
        StringBuilder largeString = new StringBuilder();
        for (int i = 0; i < 1000; i++) {
            largeString.append("test");
        }
        response.setTrailNumber(largeString.toString());
        assertEquals(largeString.toString(), response.getTrailNumber());
    }

    @Test
    void testPrintCostResponseItems() {
        // Test individual PrintCostResponseItems
        PrintCostResponseItems item = new PrintCostResponseItems();

        // Test with basic values
        item.setBob("BOB123");
        item.setPostageCost(100.0);
        item.setPaperLabourCost(50.0);
        item.setCostPerEnvelop(1.5);
        item.setEnvelopeCount(100.0);

        assertEquals("BOB123", item.getBob());
        assertEquals(100.0, item.getPostageCost());
        assertEquals(50.0, item.getPaperLabourCost());
        assertEquals(1.5, item.getCostPerEnvelop());
        assertEquals(100.0, item.getEnvelopeCount());

        // Test with zero values
        item.setPostageCost(0);
        item.setPaperLabourCost(0);
        item.setCostPerEnvelop(0);
        item.setEnvelopeCount(0);

        assertEquals(0, item.getPostageCost());
        assertEquals(0, item.getPaperLabourCost());
        assertEquals(0, item.getCostPerEnvelop());
        assertEquals(0, item.getEnvelopeCount());

        // Test with negative values
        item.setPostageCost(-100.0);
        item.setPaperLabourCost(-50.0);
        item.setCostPerEnvelop(-1.5);
        item.setEnvelopeCount(-100.0);

        assertEquals(-100.0, item.getPostageCost());
        assertEquals(-50.0, item.getPaperLabourCost());
        assertEquals(-1.5, item.getCostPerEnvelop());
        assertEquals(-100.0, item.getEnvelopeCount());

        // Test with extreme values
        item.setPostageCost(Double.MAX_VALUE);
        item.setPaperLabourCost(Double.MIN_VALUE);
        item.setCostPerEnvelop(Double.POSITIVE_INFINITY);
        item.setEnvelopeCount(Double.NaN);

        assertEquals(Double.MAX_VALUE, item.getPostageCost());
        assertEquals(Double.MIN_VALUE, item.getPaperLabourCost());
        assertEquals(Double.POSITIVE_INFINITY, item.getCostPerEnvelop());
        assertTrue(Double.isNaN(item.getEnvelopeCount()));
    }

    @Test
    void testDeepEquality() {
        // Test that changes to items in the list affect equality
        PrintCostResponse response1 = new PrintCostResponse();
        response1.setDate("July 2023");
        response1.setTrailNumber("TR12345");
        List<PrintCostResponseItems> items1 = new ArrayList<>();
        items1.add(createTestItem("BOB123", 100.0, 50.0, 1.5, 100.0));
        response1.setItems(items1);

        PrintCostResponse response2 = new PrintCostResponse();
        response2.setDate("July 2023");
        response2.setTrailNumber("TR12345");
        List<PrintCostResponseItems> items2 = new ArrayList<>();
        items2.add(createTestItem("BOB123", 100.0, 50.0, 1.5, 100.0));
        response2.setItems(items2);

        // Initially equal
        assertEquals(response1, response2);

        // Change a value in the list
        response2.getItems().get(0).setPostageCost(200.0);

        // Now they should be unequal
        assertNotEquals(response1, response2);
    }

    @Test
    void testListEquality() {
        // Test that the order of items in the list matters for equality
        PrintCostResponse response1 = new PrintCostResponse();
        List<PrintCostResponseItems> items1 = new ArrayList<>();
        items1.add(createTestItem("BOB123", 100.0, 50.0, 1.5, 100.0));
        items1.add(createTestItem("BOB456", 200.0, 100.0, 3.0, 200.0));
        response1.setItems(items1);

        PrintCostResponse response2 = new PrintCostResponse();
        List<PrintCostResponseItems> items2 = new ArrayList<>();
        items2.add(createTestItem("BOB456", 200.0, 100.0, 3.0, 200.0));
        items2.add(createTestItem("BOB123", 100.0, 50.0, 1.5, 100.0));
        response2.setItems(items2);

        // Different order, should be unequal
        assertNotEquals(response1, response2);
    }

    @Test
    void testEmptyAndNullLists() {
        // Test with empty list vs null list
        PrintCostResponse response1 = new PrintCostResponse();
        response1.setItems(new ArrayList<>());

        PrintCostResponse response2 = new PrintCostResponse();
        response2.setItems(null);

        // Empty list is not equal to null
        assertNotEquals(response1, response2);

        // Two empty lists should be equal
        PrintCostResponse response3 = new PrintCostResponse();
        response3.setItems(new ArrayList<>());
        assertEquals(response1, response3);

        // Two null lists should be equal
        PrintCostResponse response4 = new PrintCostResponse();
        response4.setItems(null);
        assertEquals(response2, response4);
    }

    @Test
    void testImmutabilityOfItems() {
        // Test that modifying the original list doesn't affect the DTO
        List<PrintCostResponseItems> originalItems = new ArrayList<>();
        originalItems.add(createTestItem("BOB123", 100.0, 50.0, 1.5, 100.0));

        PrintCostResponse response = new PrintCostResponse();
        response.setItems(originalItems);

        // Modify original list
        originalItems.add(createTestItem("BOB456", 200.0, 100.0, 3.0, 200.0));

        // The change should be reflected in the DTO because Java passes references
        // This tests that the implementation doesn't create defensive copies
        assertEquals(2, response.getItems().size());

        // Get a reference to the list from the DTO and modify it
        List<PrintCostResponseItems> retrievedItems = response.getItems();
        retrievedItems.add(createTestItem("BOB789", 300.0, 150.0, 4.5, 300.0));

        // The change should be reflected in the DTO
        assertEquals(3, response.getItems().size());
    }
}
