package com.uhg.comm.edelivery.reportingservice.dto;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class FinancialReportResponseDtoTest {

    @Test
    void testGettersAndSetters() {
        FinancialReportResponseDto responseDto = new FinancialReportResponseDto();

        List<EobReportDto> eobReports = new ArrayList<>();
        List<CaeReportDto> caeReports = new ArrayList<>();

        responseDto.setEobPrintSuppressCountReport(eobReports);
        responseDto.setCaePrintSuppressCountReport(caeReports);

        assertEquals(eobReports, responseDto.getEobPrintSuppressCountReport());
        assertEquals(caeReports, responseDto.getCaePrintSuppressCountReport());
    }

    @Test
    void testEqualsAndHashCode() {
        FinancialReportResponseDto responseDto1 = new FinancialReportResponseDto();
        FinancialReportResponseDto responseDto2 = new FinancialReportResponseDto();

        List<EobReportDto> eobReports = new ArrayList<>();
        List<CaeReportDto> caeReports = new ArrayList<>();

        responseDto1.setEobPrintSuppressCountReport(eobReports);
        responseDto1.setCaePrintSuppressCountReport(caeReports);

        responseDto2.setEobPrintSuppressCountReport(eobReports);
        responseDto2.setCaePrintSuppressCountReport(caeReports);

        assertEquals(responseDto1, responseDto2);
        assertEquals(responseDto1.hashCode(), responseDto2.hashCode());
    }

    @Test
    void testToString() {
        FinancialReportResponseDto responseDto = new FinancialReportResponseDto();

        List<EobReportDto> eobReports = new ArrayList<>();
        List<CaeReportDto> caeReports = new ArrayList<>();

        responseDto.setEobPrintSuppressCountReport(eobReports);
        responseDto.setCaePrintSuppressCountReport(caeReports);

        String expected = "FinancialReportResponseDto(eobPrintSuppressCountReport=[], caePrintSuppressCountReport=[])";
        assertNotNull(expected);
    }
}