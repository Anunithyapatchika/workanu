-- Table: edelivery.trail_and_bob_details

-- DROP TABLE edelivery.trail_and_bob_details;

CREATE TABLE edelivery.trail_and_bob_details
(
    id integer NOT NULL DEFAULT nextval('edelivery.trail_bob_details_id_seq'::regclass),
    trail_number character varying(20) COLLATE pg_catalog."default",
    bob_name character varying(20) COLLATE pg_catalog."default",
    is_active integer DEFAULT 1,
    CONSTRAINT trail_bob_details_pkey PRIMARY KEY (id)
)

TABLESPACE pg_default;

ALTER TABLE edelivery.trail_and_bob_details
    OWNER to postgres;


-- SEQUENCE: edelivery.trail_bob_details_id_seq
-- DROP SEQUENCE edelivery.trail_bob_details_id_seq;
CREATE SEQUENCE edelivery.trail_bob_details_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 2147483647
    CACHE 1;
ALTER SEQUENCE edelivery.trail_bob_details_id_seq
    OWNER TO postgres;
---- Reporting tables

drop table if exists edelivery.usp_printing_cost_report;

drop table if exists edelivery.usp_eob_hs_financial_report;

DROP SEQUENCE IF EXISTS edelivery.printing_cost_report_id_seq;

CREATE SEQUENCE IF NOT EXISTS edelivery.printing_cost_report_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;


DROP SEQUENCE IF EXISTS edelivery.eob_hs_financial_report_id_seq;

CREATE SEQUENCE IF NOT EXISTS edelivery.eob_hs_financial_report_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;


create table if not exists edelivery.usp_printing_cost_report
(
	id bigint NOT NULL DEFAULT nextval('edelivery.printing_cost_report_id_seq'::regclass),
	bob VARCHAR(255) not null,
	trail_name VARCHAR(255) not null,
	month_year DATE not null,
	month_year_str VARCHAR(255) not null,
	image_count numeric,
	envelop_count numeric,
	paper_count numeric,
	print_expense_cost numeric,
	postage_cost numeric,
	total_expense numeric,
	image_per_envelop numeric,
	print_exp_per_image numeric,
	print_exp_per_envelop numeric,
	postage_exp_per_envelop numeric,
	total_exp_envelop numeric,
	created_by VARCHAR(255) not null,
	created_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
	modified_by VARCHAR(255) not null,
	modified_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT printing_cost_report_id_pkey PRIMARY KEY (id)
);


create table if not exists edelivery.usp_eob_hs_financial_report
(
	id bigint NOT NULL DEFAULT nextval('edelivery.eob_hs_financial_report_id_seq'::regclass),
	bob VARCHAR(255) not null,
	trail_name VARCHAR(255) not null,
    month_year DATE not null,
    month_year_str VARCHAR(255) not null,
	total_eob_generated numeric,
	total_eob_suppressed numeric,
	member_election_eob numeric,
	policy_setting_eob numeric,
	total_eob_printed numeric,
	eob_suppress_percent numeric,
	total_hs_generated numeric,
	total_hs_suppressed numeric,
	member_election_hs numeric,
	policy_setting_hs numeric,
	total_hs_printed numeric,
	hs_suppress_percent numeric,
	cae_eob_mail_count numeric,
	cae_eob_no_email_count numeric,
	total_cae_eob_count numeric,
	created_by VARCHAR(255) not null,
	created_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
	modified_by VARCHAR(255) not null,
	modified_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT usp_eob_hs_financial_report_id_pkey PRIMARY KEY (id)
);

--add column 	is_tx_completed  to usp_eob_hs_financial_report

ALTER TABLE edelivery.usp_eob_hs_financial_report ADD COLUMN is_tx_completed integer default 0;


-- HS Suppression and Cost report

DROP SEQUENCE IF EXISTS edelivery.hs_suppr_cost_report_id_seq;

CREATE SEQUENCE IF NOT EXISTS edelivery.hs_suppr_cost_report_id_seq
    INCREMENT 1
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

DROP table if exists edelivery.hs_suppr_cost_report;

create table if not exists edelivery.hs_suppr_cost_report
(
	id bigint NOT NULL DEFAULT nextval('edelivery.hs_suppr_cost_report_id_seq'::regclass),
	bob VARCHAR(255) not null,
	trail_name VARCHAR(255) not null,
	month_year DATE not null,
	month_year_str VARCHAR(255) not null,
	postage_cost numeric,
	print_cost numeric,
	stmt_printed numeric,
	member_election_hs_supp numeric,
	policy_setting_hs_supp numeric,
	total_stmt_suppressed numeric,
	total_stmt_generated numeric,
	total_print_postage_cost numeric,
	hs_suppress_percent numeric,
	cost_per_stmt numeric,
	total_sheets numeric,
	sheets_per_printed_stmt numeric,
	total_claims numeric,
	created_by VARCHAR(255) not null,
	created_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
	modified_by VARCHAR(255),
	modified_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
	is_completed integer default 0,
	is_tx_completed integer default 0,
	CONSTRAINT hs_suppr_cost_report_id_pkey PRIMARY KEY (id)
);


DROP table if exists edelivery.bob_mapping;

create table if not exists edelivery.bob_mapping (
    id SERIAL primary key,
    bob_name varchar(255),
    parent_bob_name varchar(255)
);

insert into edelivery.bob_mapping (bob_name, parent_bob_name) values ('Tufts', 'Oxford');
insert into edelivery.bob_mapping (bob_name, parent_bob_name) values ('River Vally', 'Oxford');
insert into edelivery.bob_mapping (bob_name, parent_bob_name) values ('Optum', 'UHC');


------------------------------------------------------------
---new columns for usp_eob_hs_financial_report
ALTER TABLE edelivery.usp_eob_hs_financial_report
ADD COLUMN hs_mem_print numeric default 0;

----new columns for hs_suppr_cost_report
ALTER TABLE edelivery.hs_suppr_cost_report
ADD COLUMN mem_print numeric default 0;